// ============================================================================
// ACTIONFLOW HUB — APP PRINCIPALE
// Flusso Completo:
// 1. EntryView Neon (#000000) con video intro.mp4, 12 bandiere e durata sessione (10 / 20 / 30 min)
// 2. ProductTypeView Neon (#000000) con selezione genere (Uomo/Donna) e categoria prodotto
// 3. Avvio Sessione Server (POST /api/session/start - timer 10 min non saltabile)
// 4. Home con 34 Loghi Ufficiali e accredito netto per azione
// ============================================================================

import React, { useState, useCallback, useEffect } from 'react';
import {
  UserProfile,
  Transaction,
  AdminSettings,
  DEFAULT_ADMIN_SETTINGS,
} from './types';
import { Header } from './components/Header';
import { OfficialBanner } from './components/OfficialBanner';
import { CyberNav, CyberTab } from './components/CyberNav';
import { EntryVideoView } from './views/EntryVideoView';
import { EntryView } from './views/EntryView';
import { ProductTypeView } from './views/ProductTypeView';
import { HomeView } from './views/HomeView';
import { GamesView } from './views/GamesView';
import { MicroDramaView } from './views/MicroDramaView';
import { MusicAudioView } from './views/MusicAudioView';
import { AiWorkView } from './views/AiWorkView';
import { UxQaView } from './views/UxQaView';
import { ReceiptOcrView } from './views/ReceiptOcrView';
import { DepinNodesView } from './views/DepinNodesView';
import { ShoppingView } from './views/ShoppingView';
import { AirdropHubView } from './views/AirdropHubView';
import { WithdrawView } from './views/WithdrawView';
import { ProfileView } from './views/ProfileView';
import { AdminView } from './views/AdminView';
import { LanguageProvider, useTranslation, SupportedLang } from './lib/i18n';
import {
  EntryCategoryId,
  SessionMinutes,
  resolveSessionMinutes,
} from './lib/entryProfile';
import { RealReward, recordRealReward } from './lib/affiliate';
import {
  getTelegramUser,
  initUserProfile,
  saveUserLocally,
  generateTxHash,
  purgeLegacyAppMemory,
} from './services/api';

type OnboardingStep = 'video' | 'entry' | 'productType' | 'app';

const PRODUCT_TYPE_TO_CATEGORIES: Record<string, EntryCategoryId[]> = {
  games_mobile: ['games', 'interactions'],
  games_pc: ['games', 'interactions'],
  gaming: ['games', 'interactions'],
  soap: ['videos', 'interactions'],
  video_clips: ['videos', 'interactions'],
  drama: ['videos', 'interactions'],
  music: ['videos', 'interactions'],
  ai_voice: ['ai_tasks', 'interactions'],
  ai_photo: ['ai_tasks', 'interactions'],
  ai: ['ai_tasks', 'interactions'],
  ocr: ['receipts', 'interactions'],
  ux_sites: ['interactions'],
  ux_apps: ['games', 'interactions'],
  surveys: ['surveys', 'interactions'],
  audio: ['audio', 'videos'],
};

const ActionFlowInner: React.FC = () => {
  const { lang, setLang } = useTranslation();
  const [user, setUser] = useState<UserProfile>(() => {
    purgeLegacyAppMemory(false);
    // Rimosso: la chiamata a /api/system/purge-memory svuotava le mappe in-memory
    // del server per TUTTI gli utenti a ogni avvio. La pulizia locale è sufficiente.
    const tg = getTelegramUser();
    return initUserProfile(
      tg || {
        id: 0,
        first_name: 'Utente Ospite / Test',
        last_name: '',
        username: 'guest_test_user',
        language_code: 'it',
        is_premium: false,
        photo_url: '',
      }
    );
  });

  const [currentTab, setCurrentTab] = useState<CyberTab>('home');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(DEFAULT_ADMIN_SETTINGS);

  // Flusso in ingresso: 'video' (EntryVideoView non saltabile) -> 'entry' (EntryView lingue) -> 'productType' (ProductTypeView) -> 'app' (HomeView)
  const [onboardingStep, setOnboardingStep] = useState<OnboardingStep>('video');
  const [autoSessionTriggerKey, setAutoSessionTriggerKey] = useState<number>(1);
  const [selectedCountry] = useState<string>(() => {
    try {
      return localStorage.getItem('af_entry_country') || 'IT';
    } catch {
      return 'IT';
    }
  });
  const [selectedCategories, setSelectedCategories] = useState<EntryCategoryId[]>(() => {
    try {
      const raw = localStorage.getItem('af_entry_categories');
      const parsed = raw ? JSON.parse(raw) : null;
      return Array.isArray(parsed) && parsed.length > 0
        ? parsed
        : ['videos', 'games', 'interactions'];
    } catch {
      return ['videos', 'games', 'interactions'];
    }
  });
  const [selectedMinutes, setSelectedMinutes] = useState<SessionMinutes>(() => {
    try {
      return resolveSessionMinutes(localStorage.getItem('af_entry_minutes') || 20);
    } catch {
      return 20;
    }
  });

  // Step 1: Avvio da EntryView -> passa a ProductTypeView
  const handleStartFromEntryView = useCallback(
    (chosenLang: SupportedLang, chosenMinutes: SessionMinutes = 20) => {
      setLang(chosenLang);
      setSelectedMinutes(chosenMinutes);
      setOnboardingStep('productType');

      try {
        localStorage.setItem('af_entry_lang', chosenLang);
        localStorage.setItem('af_entry_minutes', String(chosenMinutes));
      } catch {
        // ignore storage errors
      }
    },
    [setLang]
  );

  // Step 2: Selezione profilo e tipi prodotto (multi-scelta) da ProductTypeView -> entra nella Home e avvia sessione
  const handleSelectProductType = useCallback(
    (productType: string, gender?: 'uomo' | 'donna', selectedIds?: string[]) => {
      const ids =
        selectedIds && selectedIds.length > 0
          ? selectedIds
          : productType
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean);

      const categorySet = new Set<EntryCategoryId>();
      ids.forEach((id) => {
        const mapped = PRODUCT_TYPE_TO_CATEGORIES[id];
        if (mapped) {
          mapped.forEach((c) => categorySet.add(c));
        }
      });

      const mappedCategories: EntryCategoryId[] =
        categorySet.size > 0
          ? Array.from(categorySet)
          : ['videos', 'games', 'interactions'];

      setSelectedCategories(mappedCategories);
      setOnboardingStep('app');
      setAutoSessionTriggerKey((k) => k + 1);

      try {
        localStorage.setItem('af_product_type', productType);
        localStorage.setItem('af_product_types_multi', JSON.stringify(ids));
        if (gender) {
          localStorage.setItem('af_user_gender', gender);
        }
        localStorage.setItem('af_entry_categories', JSON.stringify(mappedCategories));
        localStorage.setItem('af_entry_completed', '1');
      } catch {
        // ignore storage errors
      }

      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
      void fetch('/api/session/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telegramUserId: user.telegramId,
          sessionMinutes: selectedMinutes,
          categories: mappedCategories,
          productType,
          selectedProductTypes: ids,
          gender: gender || 'uomo',
          countryCode: selectedCountry,
          lang,
          timeZone: tz,
        }),
      }).catch(() => {});
    },
    [user.telegramId, selectedMinutes, selectedCountry, lang]
  );

  const handleChargeRobot = useCallback(() => {
    setUser((prev) => {
      const updated: UserProfile = {
        ...prev,
        energyCharges: Math.min(3, prev.energyCharges + 1),
      };
      saveUserLocally(updated);
      return updated;
    });
  }, []);

  const handleEarnFlowPoints = useCallback(
    (fpEarned: number, sourceTitle: string, _suppressModal?: boolean) => {
      const project = (sourceTitle || 'Project partner').slice(0, 80);
      const rawPts = Math.max(0, Number(fpEarned) || 0);
      const earnedPts = rawPts >= 100 ? Math.round(rawPts / 10) : rawPts;
      const reward: RealReward = {
        id: `rw_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
        kind: 'AIRDROP',
        project,
        tokenSymbol: 'TON',
        amount: earnedPts > 0 ? Number((earnedPts * 0.002).toFixed(4)) : null,
        network: 'TON',
        status: 'PENDING',
        source: project,
        earnedAt: Date.now(),
        txHash: null,
      };
      void recordRealReward({
        kind: reward.kind,
        project: reward.project,
        tokenSymbol: reward.tokenSymbol,
        amount: reward.amount,
        network: reward.network,
        status: reward.status,
        source: reward.source,
        txHash: reward.txHash,
      });

      setUser((prev) => {
        const updated: UserProfile = {
          ...prev,
          points: prev.points + earnedPts,
          completedTasksCount: prev.completedTasksCount + 1,
        };
        saveUserLocally(updated);
        return updated;
      });

      const newTx: Transaction = {
        id: `tx_earn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: user.id,
        type: 'TASK_CLAIM',
        amountPoints: earnedPts,
        amountGram: 0,
        amountTon: Number((earnedPts * 0.002).toFixed(4)),
        timestamp: new Date().toISOString(),
        status: 'COMPLETED',
        hash: generateTxHash(),
        details: `Ricompensa ${project} (+${earnedPts} PT)`,
      };

      setTransactions((prev) => [newTx, ...prev]);
    },
    [user.id]
  );

  const handleRequestWithdrawal = useCallback(
    async (points: number, wallet: string, asset: string = 'TON'): Promise<boolean> => {
      try {
        const res = await fetch('/api/payout/request', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            telegram_user_id: user.telegramId,
            points,
            wallet_address: wallet,
            crypto_asset: asset,
          }),
        });
        if (!res.ok) {
          return false;
        }
        const responseData = await res.json().catch(() => ({}));
        if (!responseData?.ok) {
          return false;
        }
        const usdStr = (points * 0.01).toFixed(2);
        const newTx: Transaction = {
          id: `tx_wd_${Date.now()}`,
          userId: user.id,
          type: 'WITHDRAWAL',
          amountPoints: points,
          amountGram: 0,
          amountTon: Number((points * 0.002).toFixed(4)),
          recipientWallet: wallet,
          timestamp: new Date().toISOString(),
          status: 'PENDING',
          hash: generateTxHash(),
          details: `${asset} ($${usdStr}) -> ${wallet}`,
        };
        setTransactions((prev) => [newTx, ...prev]);
        // I punti vengono scalati SOLO dopo conferma esplicita del server (responseData.ok)
        setUser((prev) => {
          const updated = { ...prev, points: Math.max(0, prev.points - points) };
          saveUserLocally(updated);
          return updated;
        });
        return true;
      } catch {
        return false;
      }
    },
    [user.id, user.telegramId]
  );

  const handleUpdateTransactionStatus = useCallback(
    async (txId: string, newStatus: 'APPROVED' | 'COMPLETED' | 'REJECTED', txHash?: string) => {
      try {
        await fetch('/api/payout/disburse', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            requestId: txId,
            status: newStatus,
            txHash,
          }),
        });
      } catch (e) {
        console.warn('Errore sincronizzazione backend status prelievo:', e);
      }

      setTransactions((prev) =>
        prev.map((t) => {
          if (t.id === txId) {
            return {
              ...t,
              status: newStatus === 'APPROVED' ? 'PROCESSING' : newStatus === 'REJECTED' ? 'CANCELLED' : 'COMPLETED',
              hash: txHash || t.hash,
            };
          }
          return t;
        })
      );

      if (newStatus === 'REJECTED') {
        const tx = transactions.find((t) => t.id === txId);
        if (tx && tx.amountPoints > 0) {
          setUser((prev) => {
            const updated = { ...prev, points: prev.points + tx.amountPoints };
            saveUserLocally(updated);
            return updated;
          });
        }
      }
    },
    [transactions]
  );

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  // 1. PRIMA SCHERMATA: EntryVideoView (#000000, video intro.mp4 automatico non saltabile + postback S2S a fine video)
  if (onboardingStep === 'video') {
    return (
      <EntryVideoView
        telegramUserId={user.telegramId}
        onComplete={() => setOnboardingStep('entry')}
      />
    );
  }

  // 2. SECONDA SCHERMATA: EntryView (#000000 neon, bandiere 12 lingue, 10/20/30 min)
  if (onboardingStep === 'entry') {
    return (
      <EntryView
        initialLang={lang}
        initialMinutes={selectedMinutes}
        onStart={handleStartFromEntryView}
      />
    );
  }

  // 3. TERZA SCHERMATA: ProductTypeView (#000000 neon, Uomo/Donna + multi-scelta categorie)
  if (onboardingStep === 'productType') {
    return <ProductTypeView onSelect={handleSelectProductType} />;
  }

  return (
    <div className="min-h-screen bg-[#05080f] text-white flex flex-col">
      <Header
        user={user}
        onOpenAdPlayer={() => setCurrentTab('wallet')}
        overdriveActive={false}
        onOpenProfile={() => setCurrentTab('profile')}
        onNavigateTab={(tab) => setCurrentTab(tab)}
        onSecretAdminUnlock={async () => {
          try {
            const res = await fetch('/api/admin/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ telegramUserId: user.telegramId }),
            });
            if (!res.ok) return;
            const data = await res.json().catch(() => ({}));
            if (!data?.isAdmin) return;
            setUser((prev) => ({ ...prev, role: 'admin' }));
            setCurrentTab('admin');
          } catch {
            // ignora
          }
        }}
      />

      {/* BARRA DELLE PAGINE SCORREVOLE CON ROTAZIONE AUTOMATICA */}
      <CyberNav
        current={currentTab}
        onSelect={(tab) => setCurrentTab(tab)}
        isAdmin={user.role === 'admin'}
      />

      <main className="flex-1 w-full max-w-2xl mx-auto px-2 pt-2 pb-8">
        {/* BANNER UFFICIALE VISIBILE SUBITO SULLO SCHERMO */}
        <OfficialBanner />

        {/* HOME */}
        {currentTab === 'home' && (
          <HomeView
            user={user}
            onChargeRobot={handleChargeRobot}
            onOpenAdPlayer={() => setCurrentTab('wallet')}
            onOpenPartnerModal={() => setOnboardingStep('productType')}
            onNavigateTab={(tab) => setCurrentTab(tab as CyberTab)}
            onOpenTonkeeperGuide={() => setCurrentTab('wallet')}
            onEarnFlowPoints={handleEarnFlowPoints}
            autoSessionTriggerKey={autoSessionTriggerKey}
            selectedCategories={selectedCategories}
            sessionMinutes={selectedMinutes}
          />
        )}

        {/* PAGINA DEDICATA: GIOCHI TELEFONO */}
        {currentTab === 'games_mobile' && (
          <GamesView
            user={user}
            lang={lang}
            subCategory="mobile"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Gioco Telefono');
            }}
          />
        )}

        {/* PAGINA DEDICATA: GIOCHI PC & WEB */}
        {currentTab === 'games_pc' && (
          <GamesView
            user={user}
            lang={lang}
            subCategory="pc"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Gioco PC & Web');
            }}
          />
        )}

        {/* COMPATIBILITÀ GIOCHI TUTTI */}
        {currentTab === 'games' && (
          <GamesView
            user={user}
            lang={lang}
            subCategory="all"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Gioco');
            }}
          />
        )}

        {/* PAGINA DEDICATA: SERIE TV BREVI */}
        {currentTab === 'soap' && (
          <MicroDramaView
            user={user}
            subCategory="soap"
            activeMultiplier={1}
            autoSessionTriggerKey={autoSessionTriggerKey}
            onBack={() => setCurrentTab('home')}
            onEarnFlowPoints={handleEarnFlowPoints}
          />
        )}

        {/* PAGINA DEDICATA: VIDEO BREVI */}
        {currentTab === 'video_clips' && (
          <MicroDramaView
            user={user}
            subCategory="video_clips"
            activeMultiplier={1}
            autoSessionTriggerKey={autoSessionTriggerKey}
            onBack={() => setCurrentTab('home')}
            onEarnFlowPoints={handleEarnFlowPoints}
          />
        )}

        {/* PAGINA DEDICATA: ASCOLTO MUSICA */}
        {currentTab === 'music' && (
          <MusicAudioView
            user={user}
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: REGISTRA VOCE */}
        {currentTab === 'ai_voice' && (
          <AiWorkView
            user={user}
            lang={lang}
            subCategory="voice"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Registra Voce');
            }}
          />
        )}

        {/* PAGINA DEDICATA: SCATTA FOTO */}
        {currentTab === 'ai_photo' && (
          <AiWorkView
            user={user}
            lang={lang}
            subCategory="photo"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Scatta Foto');
            }}
          />
        )}

        {/* COMPATIBILITÀ FOTO & VOCE */}
        {currentTab === 'ai' && (
          <AiWorkView
            user={user}
            lang={lang}
            subCategory="all"
            onBack={() => setCurrentTab('home')}
            onSelectProjectAction={(_proj, action) => {
              handleEarnFlowPoints(action.points, action.label.it || 'Foto & Voce');
            }}
          />
        )}

        {/* PAGINA DEDICATA: PROVA SITI WEB */}
        {currentTab === 'ux_sites' && (
          <UxQaView
            user={user}
            userCountry={selectedCountry}
            subCategory="sites"
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: PROVA NUOVE APP */}
        {currentTab === 'ux_apps' && (
          <UxQaView
            user={user}
            userCountry={selectedCountry}
            subCategory="apps"
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: SONDAGGI CERTIFICATI */}
        {currentTab === 'surveys' && (
          <UxQaView
            user={user}
            userCountry={selectedCountry}
            subCategory="surveys"
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* COMPATIBILITÀ UX_QA */}
        {currentTab === 'ux_qa' && (
          <UxQaView
            user={user}
            userCountry={selectedCountry}
            subCategory="all"
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: FOTO SCONTRINI */}
        {currentTab === 'ocr' && (
          <ReceiptOcrView
            user={user}
            userCountry={selectedCountry}
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: NODI E RETI */}
        {currentTab === 'depin' && (
          <DepinNodesView
            user={user}
            onEarnPoints={handleEarnFlowPoints}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: BUONI & CARTE */}
        {currentTab === 'shopping' && <ShoppingView />}


        {/* PAGINA DEDICATA: EXCHANGE & WALLET TON (SERVIZIO 0 PT UTENTE) */}
        {currentTab === 'airdrop' && (
          <AirdropHubView
            user={user}
            onBack={() => setCurrentTab('home')}
          />
        )}

        {/* PAGINA DEDICATA: WALLET */}
        {currentTab === 'wallet' && (
          <WithdrawView
            user={user}
            transactions={transactions}
            onRequestWithdrawal={handleRequestWithdrawal}
            onNavigateHome={() => setCurrentTab('home')}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            user={user}
            transactions={transactions}
            onOpenTonkeeperGuide={() => setCurrentTab('wallet')}
            onNavigateHome={() => setCurrentTab('home')}
          />
        )}

        {currentTab === 'admin' && user.role === 'admin' && (
          <AdminView
            settings={adminSettings}
            onUpdateSettings={setAdminSettings}
            currentUser={user}
            transactions={transactions}
            onNavigateHome={() => setCurrentTab('home')}
            onUpdateTransactionStatus={handleUpdateTransactionStatus}
            onApproveVerifiedTask={(points, label, unlocksHalfStep) => {
              if (unlocksHalfStep) {
                window.dispatchEvent(new Event('gf-trigger-bot-interaction'));
              }
              handleEarnFlowPoints(points, label);
            }}
          />
        )}
      </main>
    </div>
  );
};

export function App() {
  return (
    <LanguageProvider>
      <ActionFlowInner />
    </LanguageProvider>
  );
}

export default App;
