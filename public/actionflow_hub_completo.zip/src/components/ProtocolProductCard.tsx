import React from 'react';
import { ExternalLink, Sparkles } from 'lucide-react';
import { SupportedLang, getCatalogLang, computeBalancedLocalTaskPoints } from '../lib/i18n';
import { ProjectCardData, ProjectActionItem } from '../lib/catalogData';
import { GlassCard } from './Glass';

export interface ProtocolProductCardProps {
  project: ProjectCardData;
  action: ProjectActionItem;
  actionIdx: number;
  fullLang: SupportedLang;
  onSelect: () => void;
}

export const ProtocolProductCard: React.FC<ProtocolProductCardProps> = ({
  project,
  action,
  fullLang,
  onSelect,
}) => {
  const cLang = getCatalogLang(fullLang);
  const titleText = project.title[cLang] || project.title.en || project.title.it;
  const actionLabel = action.label[cLang] || action.label.en || action.label.it;
  const points = computeBalancedLocalTaskPoints(action.points, fullLang);

  return (
    <GlassCard className="p-3.5 flex items-center justify-between gap-3">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold uppercase tracking-wider text-sky-400">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>{project.provider || project.category || 'PARTNER S2S'}</span>
        </div>
        <h4 className="text-sm font-black text-white truncate mt-0.5">{titleText}</h4>
        <p className="text-xs text-slate-300 truncate mt-0.5">{actionLabel}</p>
      </div>
      <button
        type="button"
        onClick={onSelect}
        className="shrink-0 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-400 px-3 py-2 text-xs font-black text-slate-950 shadow-md active:scale-95 transition-all cursor-pointer"
      >
        <span>+{points} PT</span>
        <ExternalLink className="w-3.5 h-3.5" />
      </button>
    </GlassCard>
  );
};

export default ProtocolProductCard;
