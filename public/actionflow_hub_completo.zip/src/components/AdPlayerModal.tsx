// ============================================================================
// AD PLAYER MODAL — Player video interattivo per ads a tutto schermo
// ============================================================================

import React, { useRef, useEffect, useState } from 'react';
import { X, Volume2, VolumeX } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { EXTRA_UI_LOCALIZATION } from '../lib/providerLocalization';

interface AdPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoSrc: string;
  posterImg?: string;
  title: string;
  partnerName: string;
  onComplete?: (points: number) => void;
}

export const AdPlayerModal: React.FC<AdPlayerModalProps> = ({
  isOpen,
  onClose,
  videoSrc,
  posterImg,
  partnerName,
}) => {
  const { lang } = useTranslation();
  const extra = EXTRA_UI_LOCALIZATION[lang] || EXTRA_UI_LOCALIZATION.en;
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [played, setPlayed] = useState(false);
  const [, setCompleted] = useState(false);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  }, [isOpen]);

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (video && video.currentTime > 5 && !played) {
      setPlayed(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[90] bg-[#040812]/95 backdrop-blur-xl flex flex-col">
      <video
        ref={videoRef}
        src={videoSrc}
        poster={posterImg}
        muted={isMuted}
        playsInline
        autoPlay
        onEnded={() => setCompleted(true)}
        onTimeUpdate={handleTimeUpdate}
        className="absolute inset-0 w-full h-full object-cover object-center brightness-95"
      />

      <div className="absolute inset-0 bg-gradient-to-b from-[#040812]/85 via-transparent to-[#040812]/95" />

      {/* Header */}
      <div className="relative z-10 p-4 flex items-center justify-between">
        <button
          type="button"
          onClick={onClose}
          className="p-2 rounded-xl bg-[#0A1220]/70 text-white hover:bg-[#162648] border-0 cursor-pointer active:scale-95 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="flex-1 text-center">
          <p className="text-xs font-black uppercase tracking-wider text-sky-400">{extra.advertisementLabel}</p>
          <p className="text-xs text-slate-400">{partnerName}</p>
        </div>
        <button
          type="button"
          onClick={() => setIsMuted(!isMuted)}
          className="p-2 rounded-xl bg-[#0A1220]/70 text-white hover:bg-[#162648] border-0 cursor-pointer active:scale-95 transition-all"
        >
          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>
      </div>

      {/* Video area */}
      <div className="flex-1 flex items-center justify-center px-4">
        <video
          ref={videoRef}
          src={videoSrc}
          poster={posterImg}
          muted={isMuted}
          playsInline
          autoPlay
          className="w-full max-w-md rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.9)]"
        />
      </div>

      {/* Footer controls */}
      <div className="relative z-10 p-4 space-y-3">
        <div className="flex items-center justify-between gap-3 px-2">
          <div className="flex items-center gap-2 text-sky-300 font-mono text-sm font-black">
            {played ? extra.adPlaying : extra.adLoading}
          </div>
          <span className="text-xs font-mono font-bold text-amber-300">
            ⏱ {Math.floor(videoRef.current?.currentTime || 0)}s
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className="py-3.5 px-4 rounded-xl border border-sky-400/30 bg-[#0a1220]/70 text-sky-300 font-mono text-xs font-black uppercase cursor-pointer active:scale-95"
          >
            {isMuted ? <VolumeX className="w-4 h-4 mr-1" /> : <Volume2 className="w-4 h-4 mr-1" />}
            <span>{isMuted ? extra.audioOn : extra.audioMute}</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="py-3.5 px-4 rounded-xl border border-sky-400/30 bg-[#16233B] text-slate-200 font-mono text-xs font-black uppercase cursor-pointer active:scale-95"
          >
            {extra.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdPlayerModal;
