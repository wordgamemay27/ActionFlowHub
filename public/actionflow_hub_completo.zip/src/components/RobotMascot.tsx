// ============================================================================
// ROBOT MASCOT — DEPRECATO: usa GeoCore.tsx
// ============================================================================

import React from 'react';

export interface RobotMascotProps {
  energyCharges: number;
  onCharge: () => void;
  overdriveActive?: boolean;
  overdriveSeconds?: number;
}

export const RobotMascot: React.FC<RobotMascotProps> = () => null;

export default RobotMascot;
