// ============================================================================
// AUTO INTERACTIVE CYCLE ENGINE — Motore sessione 10/20/30 min con timer server
// Regola Unica: 30% per azione (1,00 USDT compito = 0,30 USDT / 30 PT utente)
// Localizzato integralmente in tutte le 14 lingue supportate.
// ============================================================================

import React, { useState, useEffect, useMemo } from 'react';
import { Play, Pause, CheckCircle2, Sparkles, ShieldCheck, Layers } from 'lucide-react';
import {
  CycleStreamCategory,
  filterStepsByCategories,
  resolveSessionMinutes,
  rewardForBlock,
  SupportedLang,
} from '../lib/entryProfile';
import { useTranslation } from '../lib/i18n';
import { EXTRA_UI_LOCALIZATION } from '../lib/providerLocalization';

export interface AutoInteractiveCycleEngineProps {
  activeMultiplier: number;
  autoStartTriggerKey?: number;
  selectedCategories?: string[];
  sessionMinutes?: number;
  telegramUserId?: number;
  onExitFullScreen?: () => void;
  onEarnFlowPoints?: (points: number, label: string) => void;
  onSyncTimeBar?: (secondsDone: number) => void;
}

interface CycleStepItem {
  id: string;
  titles: Record<SupportedLang, string>;
  category: CycleStreamCategory;
  provider: string;
  durationSec: number;
}

const CYCLE_CATEGORY_LABELS: Record<CycleStreamCategory, Record<SupportedLang, string>> = {
  HIGH_PAY_VIDEO: {
    it: 'Video CPM Diretto',
    en: 'Direct CPM Video',
    es: 'Video CPM Directo',
    fr: 'Vidéo CPM Directe',
    de: 'Direktes CPM-Video',
    pt: 'Vídeo CPM Direto',
    ru: 'Прямое CPM-видео',
    zh: '高单价直连视频',
    ja: 'ダイレクトCPM動画',
    ko: '직접 CPM 비디오',
    ar: 'فيديو CPM مباشر',
    hi: 'डायरेक्ट CPM वीडियो',
    tr: 'Doğrudan CPM Video',
    id: 'Video CPM Langsung',
  },
  SOAP_DRAMA: {
    it: 'Serie TV Breve',
    en: 'Short Drama Series',
    es: 'Serie Corta',
    fr: 'Mini-Série TV',
    de: 'Kurz-Dramaserie',
    pt: 'Minissérie',
    ru: 'Мини-сериал',
    zh: '精选短剧剧集',
    ja: 'ショートドラマ',
    ko: '숏폼 드라마 시리즈',
    ar: 'مسلسل قصير',
    hi: 'शॉर्ट ड्रामा सीरीज़',
    tr: 'Kısa Dizi Bölümü',
    id: 'Serial Drama Pendek',
  },
  TIKTOK_VIRAL: {
    it: 'Clip Breve Virale',
    en: 'Viral Short Clip',
    es: 'Clip Corto Viral',
    fr: 'Clip Court Viral',
    de: 'Viraler Kurzclip',
    pt: 'Clipe Curto Viral',
    ru: 'Короткий вирусный клип',
    zh: '热门短视频片段',
    ja: 'バイラルショート動画',
    ko: '바이럴 숏클립',
    ar: 'مقطع فيديو قصير',
    hi: 'वायरल शॉर्ट क्लिप',
    tr: 'Viral Kısa Klip',
    id: 'Klip Pendek Viral',
  },
  CINEMA_TRAILER: {
    it: 'Trailer Ufficiale',
    en: 'Official Trailer',
    es: 'Tráiler Oficial',
    fr: 'Bande-Annonce Officielle',
    de: 'Offizieller Trailer',
    pt: 'Trailer Oficial',
    ru: 'Официальный трейлер',
    zh: '官方影视预告片',
    ja: '公式映画トレーラー',
    ko: '공식 시네마 예고편',
    ar: 'إعلان تشويقي رسمي',
    hi: 'आधिकारिक सिनेमा ट्रेलर',
    tr: 'Resmi Sinema Fragmanı',
    id: 'Trailer Sinema Resmi',
  },
  MUSIC_HIT: {
    it: 'Ascolto Audio',
    en: 'Certified Audio Track',
    es: 'Pista de Audio',
    fr: 'Piste Audio Certifiée',
    de: 'Zertifizierter Audiotrack',
    pt: 'Faixa de Áudio',
    ru: 'Сертифицированный трек',
    zh: '认证音乐曲目',
    ja: '認証オーディオトラック',
    ko: '인증 오디오 트랙',
    ar: 'مقطع صوتي معتمد',
    hi: 'प्रमाणित ऑडियो ट्रैक',
    tr: 'Sertifikalı Ses Parçası',
    id: 'Trek Audio Tersertifikasi',
  },
  INTERACTIVE_ACTION: {
    it: 'Azione Interattiva S2S',
    en: 'Interactive S2S Action',
    es: 'Acción Interactiva S2S',
    fr: 'Action Interactive S2S',
    de: 'Interaktive S2S-Aktion',
    pt: 'Ação Interativa S2S',
    ru: 'Интерактивное S2S-задание',
    zh: 'S2S 互动验证任务',
    ja: 'S2Sインタラクティブタスク',
    ko: 'S2S 인터랙티브 액션',
    ar: 'نشاط تفاعلي S2S مباشر',
    hi: 'इंटरैक्टिव S2S टास्क',
    tr: 'Etkileşimli S2S Görevi',
    id: 'Aksi Interaktif S2S',
  },
};

const DEFAULT_CYCLE_STEPS: CycleStepItem[] = [
  {
    id: 'step_vid_1',
    titles: {
      it: 'Spot Alto CPM Partner Diretto',
      en: 'High-CPM Direct Partner Video',
      es: 'Spot de Alto CPM de Socio Directo',
      fr: 'Spot Haut CPM Partenaire Direct',
      de: 'High-CPM Direktpartner-Spot',
      pt: 'Vídeo Alto CPM de Parceiro Direto',
      ru: 'Видео высокого CPM от прямого партнера',
      zh: '直连合作伙伴高单价视频',
      ja: 'ダイレクトパートナー高CPM動画',
      ko: '직접 파트너 고단가 CPM 비디오',
      ar: 'فيديو شريك مباشر عالي العائد CPM',
      hi: 'हाई-CPM डायरेक्ट पार्टनर वीडियो',
      tr: 'Yüksek CPM Doğrudan Ortak Videosu',
      id: 'Video Mitra Langsung CPM Tinggi',
    },
    category: 'HIGH_PAY_VIDEO',
    provider: 'DramaBox',
    durationSec: 120,
  },
  {
    id: 'step_soap_1',
    titles: {
      it: 'Micro-Drama Episodio Pilota',
      en: 'Micro-Drama Pilot Episode',
      es: 'Episodio Piloto de Micro-Drama',
      fr: 'Épisode Pilote de Micro-Drame',
      de: 'Mikro-Drama Pilotfolge',
      pt: 'Episódio Piloto de Micro-Drama',
      ru: 'Пилотный эпизод мини-драмы',
      zh: '精选微短剧首播剧集',
      ja: 'マイクロドラマ第1話エピソード',
      ko: '마이크로 드라마 파일럿 에피소드',
      ar: 'حلقة تجريبية من المسلسل القصير',
      hi: 'माइक्रो-ड्रामा पायलट एपिसोड',
      tr: 'Mikro-Drama Pilot Bölümü',
      id: 'Episode Pilot Mikro-Drama',
    },
    category: 'SOAP_DRAMA',
    provider: 'ReelShort',
    durationSec: 120,
  },
  {
    id: 'step_viral_1',
    titles: {
      it: 'Clip Virale Sponsorizzata Diretta',
      en: 'Direct Sponsored Viral Clip',
      es: 'Clip Viral Patrocinado Directo',
      fr: 'Clip Viral Sponsorisé Direct',
      de: 'Direkt gesponserter viraler Clip',
      pt: 'Clipe Viral Patrocinado Direto',
      ru: 'Прямой спонсорский вирусный клип',
      zh: '官方赞助热门短视频',
      ja: 'ダイレクトスポンサー動画クリップ',
      ko: '직접 스폰서 바이럴 클립',
      ar: 'مقطع فيديو ترويجي مباشر',
      hi: 'डायरेक्ट स्पॉन्सर्ड वायरल क्लिप',
      tr: 'Doğrudan Sponsorlu Viral Klip',
      id: 'Klip Viral Sponsor Langsung',
    },
    category: 'TIKTOK_VIRAL',
    provider: 'ShortTV',
    durationSec: 120,
  },
  {
    id: 'step_cinema_1',
    titles: {
      it: 'Trailer Cinema Ufficiale',
      en: 'Official Cinema Trailer',
      es: 'Tráiler de Cine Oficial',
      fr: 'Bande-Annonce Cinéma Officielle',
      de: 'Offizieller Kino-Trailer',
      pt: 'Trailer de Cinema Oficial',
      ru: 'Официальный кинотрейлер',
      zh: '官方院线电影预告片',
      ja: '公式シネマトレーラー',
      ko: '공식 시네마 예고편',
      ar: 'إعلان سينمائي رسمي',
      hi: 'आधिकारिक सिनेमा ट्रेलर',
      tr: 'Resmi Sinema Fragmanı',
      id: 'Trailer Sinema Resmi',
    },
    category: 'CINEMA_TRAILER',
    provider: 'Kalos TV',
    durationSec: 120,
  },
  {
    id: 'step_music_1',
    titles: {
      it: 'Traccia Audio Certificata',
      en: 'Certified Audio Track Review',
      es: 'Pista de Audio Certificada',
      fr: 'Écoute de Piste Audio Certifiée',
      de: 'Zertifizierter Audiotrack',
      pt: 'Faixa de Áudio Certificada',
      ru: 'Прослушивание сертифицированного трека',
      zh: '官方认证音频曲目试听',
      ja: '認証オーディオトラック試聴',
      ko: '인증 오디오 트랙 감상',
      ar: 'مقطع صوتي معتمد للاستماع',
      hi: 'प्रमाणित ऑडियो ट्रैक',
      tr: 'Sertifikalı Ses Parçası Dinleme',
      id: 'Trek Audio Tersertifikasi',
    },
    category: 'MUSIC_HIT',
    provider: 'SubmitHub',
    durationSec: 120,
  },
  {
    id: 'step_action_1',
    titles: {
      it: 'Task Interattivo S2S Diretto',
      en: 'Direct S2S Interactive Task',
      es: 'Tarea Interactiva S2S Directa',
      fr: 'Tâche Interactive S2S Directe',
      de: 'Direkte interaktive S2S-Aufgabe',
      pt: 'Tarefa Interativa S2S Direta',
      ru: 'Прямое интерактивное S2S-задание',
      zh: 'S2S 直连互动任务',
      ja: 'ダイレクトS2Sインタラクティブタスク',
      ko: '직접 S2S 인터랙티브 과제',
      ar: 'مهمة تفاعلية S2S مباشرة',
      hi: 'डायरेक्ट S2S इंटरैक्टिव टास्क',
      tr: 'Doğrudan S2S Etkileşimli Görev',
      id: 'Tugas Interaktif S2S Langsung',
    },
    category: 'INTERACTIVE_ACTION',
    provider: 'Plarium',
    durationSec: 120,
  },
];

export const AutoInteractiveCycleEngine: React.FC<AutoInteractiveCycleEngineProps> = ({
  activeMultiplier: _activeMultiplier = 1,
  autoStartTriggerKey = 1,
  selectedCategories = ['videos', 'games', 'interactions'],
  sessionMinutes = 10,
  telegramUserId = 0,
  onExitFullScreen,
  onEarnFlowPoints,
  onSyncTimeBar,
}) => {
  const { t, lang } = useTranslation();
  const extra = EXTRA_UI_LOCALIZATION[lang] || EXTRA_UI_LOCALIZATION.en;
  const validMinutes = resolveSessionMinutes(sessionMinutes);
  const blockSeconds = 600;

  const [currentBlock, setCurrentBlock] = useState<number>(1);
  const [secondsDone, setSecondsDone] = useState(0);
  const [running, setRunning] = useState(true);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [serverVerified, setServerVerified] = useState<boolean>(false);

  const activePlaylist = useMemo(
    () => filterStepsByCategories(DEFAULT_CYCLE_STEPS, selectedCategories),
    [selectedCategories]
  );

  const currentStep = useMemo(() => {
    if (activePlaylist.length === 0) return undefined;
    const totalCycle = activePlaylist.reduce((acc, s) => acc + Math.max(1, s.durationSec), 0);
    const position = secondsDone % totalCycle;
    let acc = 0;
    for (const step of activePlaylist) {
      acc += Math.max(1, step.durationSec);
      if (position < acc) return step;
    }
    return activePlaylist[0];
  }, [secondsDone, activePlaylist]);

  const currentBlockReward = rewardForBlock(currentBlock, 1.0);

  // Avvia o ripristina sessione attiva sul server
  useEffect(() => {
    let cancelled = false;
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';

    // Prima verifica se esiste una sessione attiva da riprendere
    fetch(`/api/session/status?telegramUserId=${telegramUserId}&timeZone=${encodeURIComponent(tz)}`)
      .then((r) => r.json())
      .then((statusData) => {
        if (cancelled) return;
        if (statusData?.activeSession && statusData.activeSession.sessionId) {
          const act = statusData.activeSession;
          setSessionId(act.sessionId);
          if (act.blockNumber) setCurrentBlock(act.blockNumber);
          const resumeSec = Math.min(blockSeconds, act.elapsedSeconds || 0);
          setSecondsDone(resumeSec);
          if (onSyncTimeBar) onSyncTimeBar(resumeSec);
          setServerVerified(true);
          return;
        }

        // Altrimenti avvia una nuova sessione
        return fetch('/api/session/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            telegramUserId,
            sessionMinutes: validMinutes,
            categories: selectedCategories,
            timeZone: tz,
          }),
        })
          .then((r) => r.json())
          .then((data) => {
            if (cancelled) return;
            if (data?.sessionId) setSessionId(data.sessionId);
            if (typeof data?.blockNumber === 'number' && data.blockNumber >= 1) {
              setCurrentBlock(data.blockNumber);
            }
            setServerVerified(true);
          });
      })
      .catch(() => {
        if (!cancelled) setServerVerified(false);
      });

    return () => {
      cancelled = true;
    };
  }, [autoStartTriggerKey, telegramUserId, validMinutes, selectedCategories]);

  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => {
      setSecondsDone((prev) => {
        const next = prev + 1;
        if (onSyncTimeBar) onSyncTimeBar(next);
        return next >= blockSeconds ? blockSeconds : next;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [running, blockSeconds, onSyncTimeBar]);

  useEffect(() => {
    if (!running || secondsDone < blockSeconds) return;
    setRunning(false);
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    void fetch('/api/session/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId,
        telegramUserId,
        blockNumber: currentBlock,
        timeZone: tz,
      }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data?.ok && typeof data.creditedPoints === 'number' && onEarnFlowPoints) {
          onEarnFlowPoints(
            data.creditedPoints,
            `${t.ui.sessionBoxLabel} #${currentBlock} (+${data.creditedPoints} PT)`
          );
        }
      })
      .catch(() => {});
    setCurrentBlock((b) => b + 1);
  }, [secondsDone, blockSeconds, running, currentBlock, sessionId, telegramUserId, onEarnFlowPoints, t.ui.sessionBoxLabel]);

  const progressPct = Math.min(100, Math.round((secondsDone / blockSeconds) * 100));
  const rem = Math.max(0, blockSeconds - secondsDone);
  const mm = String(Math.floor(rem / 60)).padStart(2, '0');
  const ss = String(rem % 60).padStart(2, '0');

  const localizedStepTitle =
    currentStep?.titles[lang] || currentStep?.titles.en || currentStep?.titles.it || '';
  const localizedCategoryLabel = currentStep
    ? CYCLE_CATEGORY_LABELS[currentStep.category]?.[lang] ||
      CYCLE_CATEGORY_LABELS[currentStep.category]?.en ||
      currentStep.category
    : '';

  return (
    <div className="glass-panel rounded-2xl p-4 space-y-3 border border-emerald-500/25">
      {/* Header Ciclo Sessione */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-black uppercase tracking-wider text-emerald-300">
            {t.ui.certifiedSessionTitle}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {serverVerified && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/20 text-[10px] font-mono font-bold text-emerald-300">
              <ShieldCheck className="w-3 h-3" /> {extra.s2sDirectBadge}
            </span>
          )}
          <span className="font-mono text-sm font-black text-sky-300 tabular-nums">
            {mm}:{ss}
          </span>
        </div>
      </div>

      {/* Box Visivo Punti Utente (Solo PT) */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl bg-[#0B1324] border border-white/10 p-2 text-center">
          <div className="text-[9px] font-mono uppercase text-slate-400">{t.ui.sessionBoxLabel}</div>
          <div className="text-xs font-black font-mono text-white">
            #{currentBlock} ({validMinutes}{t.minutesShort})
          </div>
        </div>
        <div className="rounded-xl bg-emerald-950/60 border border-emerald-400/50 p-2 text-center">
          <div className="text-[9px] font-mono uppercase text-emerald-300">{t.ui.sessionRewardBoxLabel}</div>
          <div className="text-xs font-black font-mono text-emerald-300">
            +{currentBlockReward} PT
          </div>
        </div>
        <div className="rounded-xl bg-[#0B1324] border border-sky-400/25 p-2 text-center">
          <div className="text-[9px] font-mono uppercase text-sky-300">{t.ui.verificationBoxLabel}</div>
          <div className="text-xs font-black font-mono text-amber-300">{t.ui.s2sActiveLabel}</div>
        </div>
      </div>

      {/* Attività Corrente Filtrata dalle Categorie Scelte */}
      {currentStep && (
        <div className="rounded-xl bg-[#0A1326] border border-sky-400/20 p-2.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Layers className="w-4 h-4 text-sky-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-black text-white truncate">{localizedStepTitle}</div>
              <div className="text-[10px] font-mono text-slate-400 truncate">
                {currentStep.provider} ({extra.directPartnerBadge}) • {localizedCategoryLabel}
              </div>
            </div>
          </div>
          <span className="text-xs font-mono font-black text-emerald-400 shrink-0">
            +{currentBlockReward} PT
          </span>
        </div>
      )}

      {/* Barra Progresso 10 Minuti */}
      <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => setRunning((r) => !r)}
          className="flex-1 py-2.5 px-3 rounded-xl bg-sky-500/20 border border-sky-400/30 text-xs font-black uppercase text-white flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
        >
          {running ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{running ? t.ui.pauseBtn : t.ui.resumeBtn}</span>
        </button>
        {!running && secondsDone >= blockSeconds && (
          <button
            type="button"
            onClick={async () => {
              const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
              try {
                const r = await fetch('/api/session/start', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    telegramUserId,
                    sessionMinutes: validMinutes,
                    categories: selectedCategories,
                    timeZone: tz,
                  }),
                });
                const data = await r.json();
                if (data?.sessionId) setSessionId(data.sessionId);
              } catch {
                return;
              }
              setSecondsDone(0);
              setRunning(true);
            }}
            className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 text-xs font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 border-0"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{t.ui.startNextSessionBtn} #{currentBlock}</span>
          </button>
        )}
        {onExitFullScreen && (
          <button
            type="button"
            onClick={onExitFullScreen}
            className="py-2.5 px-4 rounded-xl bg-slate-800 text-xs font-black uppercase text-slate-300 cursor-pointer"
          >
            {t.ui.backBtn}
          </button>
        )}
      </div>
    </div>
  );
};

export default AutoInteractiveCycleEngine;
