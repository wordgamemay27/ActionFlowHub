export { TonPayoutWorker, tonPayoutWorker } from './tonPayoutWorker';
export { SettlementWorker, settlementWorker } from './settlementWorker';
export {
  startBlockchainListener,
  stopBlockchainListener,
  getListenerStatus,
} from './blockchainListener';

import { TonPayoutWorker } from './tonPayoutWorker';
import { SettlementWorker, SettlementJob } from './settlementWorker';
import {
  startBlockchainListener,
  stopBlockchainListener,
  getListenerStatus,
} from './blockchainListener';

export const workers = {
  tonPayout: {
    start: () => TonPayoutWorker.start(),
    stop: () => TonPayoutWorker.stop(),
    getMetrics: () => TonPayoutWorker.getMetrics(),
  },
  settlement: {
    start: () => SettlementWorker.start(),
    stop: () => SettlementWorker.stop(),
    queueSettlement: (job: SettlementJob) => SettlementWorker.queueSettlement(job),
    getStatus: () => SettlementWorker.getQueueStatus(),
  },
  blockchain: {
    start: startBlockchainListener,
    stop: stopBlockchainListener,
    getStatus: getListenerStatus,
  },
};
