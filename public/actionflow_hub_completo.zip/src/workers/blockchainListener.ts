import { TonClient, Address } from '@ton/ton';
import { Connection, PublicKey } from '@solana/web3.js';
import { dbPool } from '../db/ledgerService';
import { ProviderReputationService } from '../services/providerReputation';
import { SettlementService } from '../db/settlementService';
import { WALLET_CONFIG } from '../config/wallets';

interface BlockchainConfig {
  ton: { rpc: string; enabled: boolean };
  solana: { rpc: string; enabled: boolean };
  tonAddress: string;
  solAddress: string;
}

const CONFIG: BlockchainConfig = {
  ton: {
    rpc: process.env.TON_RPC || 'https://toncenter.com/api/v2/jsonRPC',
    enabled: true,
  },
  solana: {
    rpc: process.env.SOL_RPC || 'https://api.mainnet-beta.solana.com',
    enabled: true,
  },
  tonAddress:
    process.env.TON_COLD_ADDRESS ||
    WALLET_CONFIG.TON.payoutAddresses[0] ||
    'UQArcaLwWBTXqOfyJCy3mjPSEuD80p66jzF_95HyXRShBOo-',
  solAddress:
    process.env.SOL_COLD_ADDRESS ||
    WALLET_CONFIG.SOL.payoutAddresses[0] ||
    'FCiSaZcMYYPyzkJQkfNXdnw4v2PjiR241KYpEm2FeqdT',
};

const POLL_INTERVAL_TON = 15_000;
const POLL_INTERVAL_SOL = 10_000;
const CONFIRMATIONS_TON = 1;
const CONFIRMATIONS_SOL = 32;

let tonClient: TonClient | null = null;
let solConnection: Connection | null = null;
let isRunning = false;
let tonTimer: NodeJS.Timeout | null = null;
let solTimer: NodeJS.Timeout | null = null;
const processedTxHashes = new Set<string>();

async function initClients(): Promise<void> {
  if (!tonClient) {
    tonClient = new TonClient({
      endpoint: CONFIG.ton.rpc,
    });
  }
  if (!solConnection) {
    solConnection = new Connection(CONFIG.solana.rpc, 'confirmed');
  }
}

export async function checkTonDeposits(): Promise<void> {
  if (!CONFIG.ton.enabled) return;
  try {
    await initClients();
    if (!tonClient) return;

    const parsedAddress = Address.parse(CONFIG.tonAddress);
    const transactions = await tonClient.getTransactions(parsedAddress, { limit: 25 });

    for (const tx of transactions) {
      const txHash = tx.hash().toString('hex');
      if (processedTxHashes.has(txHash)) continue;

      const inMsg = tx.inMessage;
      if (inMsg && inMsg.info.type === 'internal') {
        const valueNano = inMsg.info.value.coins;
        if (valueNano > 0n) {
          processedTxHashes.add(txHash);
          const amountTon = Number(valueNano) / 1e9;
          const usdEstimate = Number((amountTon * 5.0).toFixed(2));

          await ProviderReputationService.recordPayment({
            providerId: 'ton_onchain_partner',
            batchId: `ton_dep_${txHash.slice(0, 12)}`,
            promisedUsd: usdEstimate,
            paidUsd: usdEstimate,
            txHash,
            notes: `TON Deposit (${CONFIRMATIONS_TON} conf)`,
          });

          if (dbPool) {
            await SettlementService.executeBatchSettlement({
              batchId: `ton_batch_${txHash.slice(0, 12)}`,
              partnerId: 'ton_onchain_partner',
              periodStart: Date.now() - 86400_000,
              periodEnd: Date.now(),
              expectedGrossUsd: usdEstimate,
              actualNetReceivedUsd: usdEstimate,
              haircutRatio: 1.0,
              onchainTxHash: txHash,
            });
          }
        }
      }
    }
  } catch {
    // Non-fatal RPC polling warning in dev/offline environments
  }
}

export async function checkSolanaDeposits(): Promise<void> {
  if (!CONFIG.solana.enabled) return;
  try {
    await initClients();
    if (!solConnection) return;

    const pubKey = new PublicKey(CONFIG.solAddress);
    const signatures = await solConnection.getSignaturesForAddress(pubKey, { limit: 20 });

    for (const sigInfo of signatures) {
      if (sigInfo.err) continue;
      if (processedTxHashes.has(sigInfo.signature)) continue;
      processedTxHashes.add(sigInfo.signature);

      await ProviderReputationService.recordPayment({
        providerId: 'sol_onchain_partner',
        batchId: `sol_dep_${sigInfo.signature.slice(0, 12)}`,
        promisedUsd: 10,
        paidUsd: 10,
        txHash: sigInfo.signature,
        notes: `SOL Deposit (${CONFIRMATIONS_SOL} conf)`,
      });
    }
  } catch {
    // Non-fatal RPC polling warning
  }
}

export function startBlockchainListener(): void {
  if (isRunning) return;
  isRunning = true;
  void initClients();
  tonTimer = setInterval(() => {
    void checkTonDeposits();
  }, POLL_INTERVAL_TON);
  solTimer = setInterval(() => {
    void checkSolanaDeposits();
  }, POLL_INTERVAL_SOL);
}

export function stopBlockchainListener(): void {
  if (tonTimer) {
    clearInterval(tonTimer);
    tonTimer = null;
  }
  if (solTimer) {
    clearInterval(solTimer);
    solTimer = null;
  }
  isRunning = false;
}

export function getListenerStatus() {
  return {
    isRunning,
    tonEnabled: CONFIG.ton.enabled,
    solanaEnabled: CONFIG.solana.enabled,
    tonAddress: CONFIG.tonAddress,
    solAddress: CONFIG.solAddress,
    processedCount: processedTxHashes.size,
  };
}
