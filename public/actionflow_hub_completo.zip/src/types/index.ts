// ============================================================================
// TIPI CENTRALI - ActionFlow Hub
// ============================================================================

// ----------------------------------------------------------
// Profilo Utente
// ----------------------------------------------------------
export interface UserProfile {
  id: string;
  telegramId: number;
  username: string;
  firstName: string;
  lastName?: string;
  points: number;                    // Punti legacy (withdrawable_points)
  gramBalance: number;               // Balance GRAM (1 GRAM = 10 points)
  tonBalance: number;                // Balance TON
  walletAddress: string;             // Indirizzo TON (UQ... o EQ...)
  tier: 'TIER 1' | 'TIER 2' | 'TIER 3' | 'VIP ELITE';
  baseRatePercent: number;           // % base conversione points → GRAM/TON
  payoutSharePercent: number;        // % condivisione (default 33%)
  energyCharges: number;             // Cariche energia (per overdrive)
  overdriveActive: boolean;          // Overdrive attivo
  overdriveExpiresAt: number | null; // Scadenza overdrive (timestamp ms)
  turboBoostPercent: number;         // 0 (1x), 100 (x2), 200 (x3 60m), 300 (x4 120m)
  turboRemainingSeconds: number;     // Secondi rimanenti turbo
  turboIsActive: boolean;            // Turbo attivo ora
  totalWatchedAds: number;           // Contatore ads visti
  completedTasksCount: number;       // Task completati
  role?: 'user' | 'admin';           // Ruolo (opzionale)
  referralCode?: string;             // Codice referral (opzionale)
  referredBy?: string;               // Chi ha referenziato (opzionale)
}

// ----------------------------------------------------------
// Transazioni
// ----------------------------------------------------------
export interface Transaction {
  id: string;
  userId: string;
  type: 'TASK_CLAIM' | 'WITHDRAWAL' | 'DEPOSIT' | 'REFERRAL' | 'BONUS' | 'PENALTY' | 'AIRDROP_CLAIM' | 'STARS_PURCHASE' | 'TURBO_ACTIVATION';
  amountPoints: number;
  amountGram: number;
  amountTon: number;
  timestamp: string;
  status: 'PENDING' | 'APPROVED' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'PROCESSING';
  hash: string;
  details?: string;
  recipientWallet?: string;
  requestId?: string;
  cryptoAsset?: 'TON' | 'USDT';
  cryptoAmount?: number;
}

// ----------------------------------------------------------
// Impostazioni Admin
// ----------------------------------------------------------
export interface AdminSettings {
  // Payout
  minWithdrawalPoints: number;
  minWithdrawalTon: number;
  minWithdrawalUsdt: number;
  dailyWithdrawalLimitPoints: number;
  dailyWithdrawalLimitTon: number;
  dailyWithdrawalLimitUsdt: number;

  // Conversioni
  pointsToGramRate: number;        // 1 point = X GRAM
  pointsToTonRate: number;         // 1 point = X TON
  gramToTonRate: number;           // 1 GRAM = X TON
  usdToTonRate: number;            // 1 USD = X TON

  // Task
  basePointsPerTask: number;
  maxTasksPerDay: number;
  taskCooldownMinutes: number;

  // Referral
  referralBonusPoints: number;
  referralBonusPercent: number;
  minReferralWithdrawal: number;

  // Turbo/Boost
  turboStarsCost: Record<number, number>; // stars -> boostPercent
  turboDurationSeconds: Record<number, number>;

  // Sicurezza
  maxFailedWithdrawals: number;
  lockoutDurationMinutes: number;
  requireEmailVerification: boolean;
  requirePhoneVerification: boolean;

  // Feature flags
  enableWithdrawals: boolean;
  enableReferrals: boolean;
  enableTurboBoost: boolean;
  enableAirdrops: boolean;
  enableShopping: boolean;
  enableGames: boolean;
  enableAiWork: boolean;
  enableReceiptOcr: boolean;
  enableTelegramBots: boolean;
}

// ----------------------------------------------------------
// Task / Attività
// ----------------------------------------------------------
export interface Task {
  id: string;
  title: string;
  description: string;
  category: string;
  points: number;
  gramReward: number;
  tonReward: number;
  durationMinutes: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  icon: string;
  color: string;
  requirements?: string[];
  rewardType: 'POINTS' | 'GRAM' | 'TON' | 'AIRDROP' | 'TOKEN' | 'MINING';
  provider?: string;
  partnerUrl?: string;
  isActive: boolean;
  maxCompletions?: number;
  currentCompletions: number;
  expiresAt?: string;
  createdAt: string;
  updatedAt: string;
}

// ----------------------------------------------------------
// Airdrop / Campagne
// ----------------------------------------------------------
export interface AirdropCampaign {
  id: string;
  title: string;
  description: string;
  officialLogoUrl: string;
  masterRefLink: string;
  monetizationType: 'DIRECT_LISTING' | 'CPA_S2S' | 'REF_SHARE' | 'AD_GATED';
  s2sPostbackUrl: string;
  isCertified: boolean;
  rewardKind: 'AIRDROP' | 'TOKEN' | 'MINING';
  rewardTokenSymbol: string;
  rewardAmount?: number;
  rewardNetwork: string;
  status: 'ACTIVE' | 'PAUSED' | 'ENDED';
  startDate: string;
  endDate?: string;
  maxParticipants?: number;
  currentParticipants: number;
  createdAt: string;
  updatedAt: string;
}

// ----------------------------------------------------------
// Notifiche / Toast
// ----------------------------------------------------------
export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

// ----------------------------------------------------------
// Configurazione Rete Crypto
// ----------------------------------------------------------
export type NetworkKey = 'TON' | 'SOLANA' | 'PI_NETWORK' | 'USDT_TON';

export interface NetworkConfig {
  key: NetworkKey;
  tabLabel: Record<string, string>;
  walletAppName: string;
  walletAppUrl: string;
  addressPlaceholder: Record<string, string>;
  addressHint: Record<string, string>;
  nativeTokenSymbol: string;
  nativeTokenDecimals: number;
  supportedTokens: Array<{
    symbol: string;
    name: string;
    decimals: number;
    contractAddress?: string;
    logoUrl: string;
  }>;
  rpcUrl: string;
  explorerUrl: string;
  chainId?: string;
}

// ----------------------------------------------------------
// Stato Globale App (per context/state management)
// ----------------------------------------------------------
export interface AppState {
  user: UserProfile | null;
  transactions: Transaction[];
  tasks: Task[];
  airdrops: AirdropCampaign[];
  adminSettings: AdminSettings | null;
  isLoading: boolean;
  error: string | null;
  toasts: Toast[];
  currentTab: string;
  sidebarOpen: boolean;
}

// ----------------------------------------------------------
// Costanti di Default
// ----------------------------------------------------------
export const DEFAULT_ADMIN_SETTINGS: AdminSettings = {
  minWithdrawalPoints: 500,
  minWithdrawalTon: 1,
  minWithdrawalUsdt: 5,
  dailyWithdrawalLimitPoints: 10000,
  dailyWithdrawalLimitTon: 20,
  dailyWithdrawalLimitUsdt: 100,
  pointsToGramRate: 1,
  pointsToTonRate: 0.002,
  gramToTonRate: 0.002,
  usdToTonRate: 0.2,
  basePointsPerTask: 30,
  maxTasksPerDay: 50,
  taskCooldownMinutes: 5,
  referralBonusPoints: 30,
  referralBonusPercent: 10,
  minReferralWithdrawal: 500,
  turboStarsCost: {},
  turboDurationSeconds: {},
  maxFailedWithdrawals: 3,
  lockoutDurationMinutes: 30,
  requireEmailVerification: false,
  requirePhoneVerification: false,
  enableWithdrawals: true,
  enableReferrals: true,
  enableTurboBoost: false,
  enableAirdrops: true,
  enableShopping: true,
  enableGames: true,
  enableAiWork: true,
  enableReceiptOcr: true,
  enableTelegramBots: true,
};

export const NETWORK_CONFIGS: Record<NetworkKey, NetworkConfig> = {
  TON: {
    key: 'TON',
    tabLabel: { it: 'Rete TON', en: 'TON Network', es: 'Red TON', fr: 'Réseau TON', de: 'TON-Netzwerk', pt: 'Rede TON' },
    walletAppName: 'Tonkeeper / Telegram Wallet',
    walletAppUrl: 'https://tonkeeper.com',
    addressPlaceholder: { it: 'Incolla il tuo indirizzo Tonkeeper (UQ... o EQ...)', en: 'Paste your Tonkeeper address (UQ... or EQ...)' },
    addressHint: { it: 'Indirizzo Tonkeeper (UQ... o EQ...) sulla Rete TON per ricevere GRAM, USDT, NOT o DOGS.', en: 'Tonkeeper address (UQ... or EQ...) on TON Network to receive GRAM, USDT, NOT or DOGS.' },
    nativeTokenSymbol: 'TON',
    nativeTokenDecimals: 9,
    supportedTokens: [
      { symbol: 'TON', name: 'Toncoin', decimals: 9, logoUrl: 'https://cdn.simpleicons.org/ton/0098EA' },
      { symbol: 'USDT', name: 'Tether USD', decimals: 6, contractAddress: 'EQBynBO23ywHy_CgarY9NK9FTz0yDsG82PtcbSTQgGo24iuB', logoUrl: 'https://cdn.simpleicons.org/tether/26A17B' },
      { symbol: 'GRAM', name: 'Gram', decimals: 9, contractAddress: 'EQD0vdSA_Nedpn9uBGU3lQ4z5841YZT6UJgZfQ6J81KBM', logoUrl: 'https://cdn.simpleicons.org/telegram/26A5E4' },
      { symbol: 'NOT', name: 'Notcoin', decimals: 9, contractAddress: 'EQAvlWFDxGF2lXm67y4yzC17wYKD9A0guwPkMs1gOsM__NOT', logoUrl: 'https://cdn.simpleicons.org/notcoin/FFD700' },
      { symbol: 'DOGS', name: 'Dogs', decimals: 9, contractAddress: 'EQB2_Jn4kBVCpb9zZI4fJgK6r8X9q8X9q8X9q8X9q8X9q8X9', logoUrl: 'https://cdn.simpleicons.org/dogs/8A2BE2' },
    ],
    rpcUrl: 'https://toncenter.com/api/v2/jsonRPC',
    explorerUrl: 'https://tonscan.org',
    chainId: 'ton',
  },
  SOLANA: {
    key: 'SOLANA',
    tabLabel: { it: 'Rete Solana', en: 'Solana Network' },
    walletAppName: 'Phantom / Solflare',
    walletAppUrl: 'https://phantom.app',
    addressPlaceholder: { it: 'Incolla il tuo indirizzo Solana', en: 'Paste your Solana address' },
    addressHint: { it: 'Indirizzo Solana (Base58) per ricevere SOL, USDC, USDT o BONK.', en: 'Solana address (Base58) to receive SOL, USDC, USDT or BONK.' },
    nativeTokenSymbol: 'SOL',
    nativeTokenDecimals: 9,
    supportedTokens: [
      { symbol: 'SOL', name: 'Solana', decimals: 9, logoUrl: 'https://cdn.simpleicons.org/solana/9945FF' },
      { symbol: 'USDC', name: 'USD Coin', decimals: 6, contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', logoUrl: 'https://cdn.simpleicons.org/usdc/2775CA' },
      { symbol: 'USDT', name: 'Tether USD', decimals: 6, contractAddress: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', logoUrl: 'https://cdn.simpleicons.org/tether/26A17B' },
      { symbol: 'BONK', name: 'Bonk', decimals: 5, contractAddress: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xrnBR75Y6Si33L4', logoUrl: 'https://cdn.simpleicons.org/bonk/8A2BE2' },
    ],
    rpcUrl: 'https://api.mainnet-beta.solana.com',
    explorerUrl: 'https://solscan.io',
    chainId: 'solana',
  },
  PI_NETWORK: {
    key: 'PI_NETWORK',
    tabLabel: { it: 'Pi Network', en: 'Pi Network' },
    walletAppName: 'Pi Wallet',
    walletAppUrl: 'https://minepi.com',
    addressPlaceholder: { it: 'Incolla il tuo indirizzo Pi Wallet pubblico (inizia con G...)', en: 'Paste your public Pi Wallet address (starts with G...)' },
    addressHint: { it: 'Indirizzo Pi Wallet pubblico (inizia con G...) per ricevere Pi Coin (PI).', en: 'Public Pi Wallet address (starts with G...) to receive Pi Coin (PI).' },
    nativeTokenSymbol: 'PI',
    nativeTokenDecimals: 6,
    supportedTokens: [
      { symbol: 'PI', name: 'Pi Coin', decimals: 6, logoUrl: 'https://cdn.simpleicons.org/pinetwork/00C851' },
    ],
    rpcUrl: 'https://api.minepi.com/v2',
    explorerUrl: 'https://explorer.pi.network',
    chainId: 'pi',
  },
  USDT_TON: {
    key: 'USDT_TON',
    tabLabel: { it: 'USDT su TON', en: 'USDT on TON' },
    walletAppName: 'Tonkeeper / Telegram Wallet',
    walletAppUrl: 'https://tonkeeper.com',
    addressPlaceholder: { it: 'Incolla il tuo indirizzo Tonkeeper (UQ... o EQ...)', en: 'Paste your Tonkeeper address (UQ... or EQ...)' },
    addressHint: { it: 'Indirizzo Tonkeeper (UQ... o EQ...) sulla Rete TON per ricevere USDT.', en: 'Tonkeeper address (UQ... or EQ...) on TON Network to receive USDT.' },
    nativeTokenSymbol: 'USDT',
    nativeTokenDecimals: 6,
    supportedTokens: [
      { symbol: 'USDT', name: 'Tether USD', decimals: 6, contractAddress: 'EQBynBO23ywHy_CgarY9NK9FTz0yDsG82PtcbSTQgGo24iuB', logoUrl: 'https://cdn.simpleicons.org/tether/26A17B' },
    ],
    rpcUrl: 'https://toncenter.com/api/v2/jsonRPC',
    explorerUrl: 'https://tonscan.org',
    chainId: 'ton',
  },
};

// ----------------------------------------------------------
// Utilità per indirizzi TON
// ----------------------------------------------------------
export function isValidTonAddress(address: string): boolean {
  if (!address || typeof address !== 'string') return false;
  const trimmed = address.trim();
  // Formati validi: UQ... (bounceable) o EQ... (non-bounceable), 48 caratteri, base64url
  return /^(UQ|EQ)[A-Za-z0-9_-]{46}$/.test(trimmed);
}

export function normalizeTonAddress(address: string): string {
  if (!address) return '';
  return address.trim().toUpperCase();
}

// ----------------------------------------------------------
// Generazione Hash Transazione
// ----------------------------------------------------------
export function generateTxHash(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 10);
  return `tx_${timestamp}_${random}`;
}

// ----------------------------------------------------------
// Scala Punti e Conversione Wallet: 100 PT = 1,00 $ (1 PT = 0,01 $)
// Compito standard = 30 PT | Prelievo minimo = 500 PT ($5,00)
// ----------------------------------------------------------
export const USER_PAYOUT_SHARE_PERCENT = 30;
export const PLATFORM_RETENTION_PERCENT = 70;
export const POINTS_PER_USDT = 100;
export const USER_POINTS_PER_ONE_USDT_TASK = 30;

export function calculateUserRewardFromGrossUsdt(grossUsdt: number): {
  grossUsdt: number;
  userUsdt: number;
  userPoints: number;
  platformUsdt: number;
} {
  const safeGross = Math.max(0, Number(grossUsdt) || 0);
  const userUsdt = Number((safeGross * 0.3).toFixed(2));
  const userPoints = Math.round(userUsdt * POINTS_PER_USDT);
  const platformUsdt = Number((safeGross * 0.7).toFixed(2));
  return { grossUsdt: safeGross, userUsdt, userPoints, platformUsdt };
}

export function calculateTonEquivalent(points: number, multiplier = 1): number {
  // 100 PT = $1.00 -> 500 PT = $5.00 ≈ 1.00 TON (0.002 TON per PT)
  return Number((points * 0.002 * multiplier).toFixed(4));
}

export function calculateGramEquivalent(points: number): number {
  return Number((points * 1).toFixed(2));
}

export function calculateUsdtEquivalent(points: number): number {
  // Tasso unico nel Wallet: 100 PT = 1,00 $ (1 PT = 0,01 $)
  return Number((points * 0.01).toFixed(2));
}

