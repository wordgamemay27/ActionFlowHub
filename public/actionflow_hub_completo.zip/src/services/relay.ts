export { getDirectProviderRelayUrl } from '../lib/catalogData';
