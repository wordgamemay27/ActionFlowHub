// ============================================================================
// API & TELEGRAM SERVICES — Gestione utente, conversioni e tracciamento
// ============================================================================

import { openAnyUrlSafely, isTelegramUrl, type AdTrackingMeta } from '../utils/navigation';
import {
  UserProfile,
  Task,
  AdminSettings,
  DEFAULT_ADMIN_SETTINGS,
} from '../types';

export { openAnyUrlSafely, isTelegramUrl };
export type { AdTrackingMeta };

export type TelegramUser = {
  id: number;
  first_name: string;
  last_name: string;
  username: string;
  language_code: string;
  is_premium: boolean;
  photo_url: string;
};

export interface AdFormat {
  id: string;
  title: string;
  providerKey: string;
  targetUrl: string;
}

export const DEV_ONLY_FALLBACK_USER: TelegramUser = {
  id: 0,
  first_name: 'Utente Ospite / Test',
  last_name: '',
  username: 'guest_test_user',
  language_code: 'it',
  is_premium: false,
  photo_url: '',
};

export const INITIAL_TASKS: Task[] = [];

export const AD_FORMATS: AdFormat[] = [];

export const ADMIN_SETTINGS: AdminSettings = {
  ...DEFAULT_ADMIN_SETTINGS,
  minWithdrawalPoints: 500,
  minWithdrawalTon: 1,
  minWithdrawalUsdt: 5,
};

export async function trackAdInteraction(payload: {
  eventType: 'IMPRESSION' | 'CLICK' | 'AUTO_TRIGGER';
  slotId?: string;
  providerKey?: string;
  target_url: string;
  pageContext?: string;
  telegramUserId?: number;
}): Promise<void> {
  try {
    await fetch('/api/affiliate/click', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch {
    // Non-blocking telemetry
  }
}

export function getTelegramUser(): TelegramUser | null {
  try {
    const tg = (window as any)?.Telegram?.WebApp;
    const u = tg?.initDataUnsafe?.user;
    if (u && typeof u.id === 'number') {
      return {
        id: u.id,
        first_name: u.first_name || 'User',
        last_name: u.last_name || '',
        username: u.username || `user_${u.id}`,
        language_code: u.language_code || 'it',
        is_premium: Boolean(u.is_premium),
        photo_url: u.photo_url || '',
      };
    }
  } catch {
    // ignore
  }
  return DEV_ONLY_FALLBACK_USER;
}

const LOCAL_USER_KEY = 'af_user_profile_v5';
const CLEAN_MEMORY_SCHEMA_KEY = 'af_clean_memory_schema_v5';
const CLEAN_MEMORY_SCHEMA_VALUE = 'CLEAN_SCHEMA_V5_100PT';

const LEGACY_STORAGE_KEYS = [
  'af_user_profile_v1',
  'af_user_profile_v2',
  'af_user_profile_v3',
  'af_user_profile_v4',
  'af_clean_memory_schema_v4',
  'actionflow_user_profile',
  'af_real_rewards_v1',
  'actionflow_real_rewards_v1',
  'af_affiliate_clicks_v1',
  'actionflow_ad_watch_history_v1',
  'af_session_id',
  'af_completed_blocks',
  'af_last_reset_day',
  'af_entry_country',
  'af_entry_categories',
  'af_entry_minutes',
  'af_entry_lang',
  'af_product_type',
  'af_product_types_multi',
  'af_user_gender',
  'af_entry_completed',
  'gf_user_lang',
  'gf_user_lang_manual',
  'af_lang_v1',
];

/**
 * Pulisce integralmente localStorage e sessionStorage da qualsiasi conteggio,
 * saldo o stato di versioni precedenti.
 */
export function purgeLegacyAppMemory(force = false): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const currentSchema = window.localStorage?.getItem(CLEAN_MEMORY_SCHEMA_KEY);
    if (!force && currentSchema === CLEAN_MEMORY_SCHEMA_VALUE) {
      return false;
    }

    for (const key of LEGACY_STORAGE_KEYS) {
      try {
        window.localStorage?.removeItem(key);
        window.sessionStorage?.removeItem(key);
      } catch {
        // ignore
      }
    }

    // Rimuove eventuali chiavi residue con prefissi vecchi
    if (window.localStorage) {
      const keysToRemove: string[] = [];
      for (let i = 0; i < window.localStorage.length; i++) {
        const k = window.localStorage.key(i);
        if (
          k &&
          k !== CLEAN_MEMORY_SCHEMA_KEY &&
          (k.startsWith('af_') || k.startsWith('actionflow_') || k.startsWith('gf_'))
        ) {
          keysToRemove.push(k);
        }
      }
      for (const k of keysToRemove) {
        window.localStorage.removeItem(k);
      }
    }

    if (window.sessionStorage) {
      window.sessionStorage.clear();
    }

    window.localStorage?.setItem(CLEAN_MEMORY_SCHEMA_KEY, CLEAN_MEMORY_SCHEMA_VALUE);
    return true;
  } catch {
    return false;
  }
}

// Esegue la pulizia automatica della memoria all'avvio del modulo
purgeLegacyAppMemory(false);

export function initUserProfile(tgUser: TelegramUser): UserProfile {
  purgeLegacyAppMemory(false);
  try {
    const raw = localStorage.getItem(LOCAL_USER_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as UserProfile;
      if (parsed && typeof parsed.points === 'number') {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  const initial: UserProfile = {
    id: `usr_${tgUser.id || 'guest'}`,
    telegramId: tgUser.id || 0,
    username: tgUser.username || 'guest_test_user',
    firstName: tgUser.first_name || 'Utente Ospite / Test',
    lastName: tgUser.last_name || '',
    languageCode: tgUser.language_code || 'it',
    isPremium: Boolean(tgUser.is_premium),
    points: 0,
    gramBalance: 0,
    tonBalance: 0,
    tier: 'TIER 1',
    energyCharges: 3,
    overdriveActive: false,
    overdriveEndsAt: null,
    turboBoostPercent: 0,
    turboRemainingSeconds: 0,
    completedTasksCount: 0,
    walletAddress: '',
    role: 'user',
    createdAt: new Date().toISOString(),
    lastActiveAt: new Date().toISOString(),
  } as any;
  saveUserLocally(initial);
  return initial;
}

export function saveUserLocally(profile: UserProfile): void {
  try {
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(profile));
  } catch {
    // ignore
  }
}

export function generateTxHash(): string {
  return `0x${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`;
}

export async function verifyTelegramInitDataServerSide(
  initData: string
): Promise<{ success: boolean; user?: TelegramUser; error?: string }> {
  try {
    const res = await fetch('/api/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initData }),
    });
    if (!res.ok) return { success: false };
    return await res.json();
  } catch {
    return { success: false };
  }
}

export async function authorizeSensitiveTelegramOperation(
  operation: string,
  telegramId: number,
  points: number
): Promise<boolean> {
  try {
    const res = await fetch('/api/payout/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operation, telegram_user_id: telegramId, points }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ----------------------------------------------------------------
// Funzioni di conversione nel Wallet: 100 PT = 1,00 $ (1 PT = 0,01 $)
// Compito standard = 30 PT | Minimo prelievo = 500 PT ($5,00)
// ----------------------------------------------------------------
export function calculateGramEquivalent(points: number): number {
  return Math.round(points);
}

export function calculateTonEquivalent(points: number, multiplier = 1): number {
  return Number((points * 0.002 * multiplier).toFixed(4));
}

export function calculateUsdtEquivalent(points: number): number {
  return Number((points * 0.01).toFixed(2));
}

