// ============================================================================
// MODELLO COMMERCIALE — AFFILIAZIONE TON + RICOMPENSE REALI
// ============================================================================
// REGOLA 1 (GUADAGNO DELL'APPLICAZIONE)
//   Ogni avvio di compito, iscrizione o referral transita dai link di
//   affiliazione ufficiali della piattaforma. Il sistema registra il click con
//   un click_id e accredita il provento in TON (o crypto consolidate / contanti)
//   nella tesoreria del partner. Il provento resta dell'applicazione.
//
// REGOLA 2 (GUADAGNO DELL'UTENTE)
//   L'utente NON accumula punti fittizi. Accumula esclusivamente ricompense
//   reali e verificabili:
//     - AIRDROP  -> partecipazione a un progetto con distribuzione reale
//     - TOKEN    -> token ufficiale del progetto partner accreditato
//     - MINING   -> mining certificato (hash, quota, rete)
//   Nessuna ricompensa viene dichiarata se non esiste un riferimento
//   verificabile (progetto, token, rete, stato, tx hash).
// ============================================================================

import { openAnyUrlSafely } from '../utils/navigation';

export type AffiliateActionKind = 'TASK' | 'SIGNUP' | 'REFERRAL';
export type RewardKind = 'AIRDROP' | 'TOKEN' | 'MINING';
export type RewardStatus = 'PENDING' | 'CLAIMABLE' | 'CLAIMED' | 'VERIFIED';

export interface RealReward {
  id: string;
  kind: RewardKind;
  /** Progetto partner (nome ufficiale del progetto). */
  project: string;
  /** Simbolo del token ufficiale del progetto. */
  tokenSymbol: string;
  /** Quantita' (null = da calcolare in base alla quota/airdrop). */
  amount: number | null;
  /** Rete su cui e' denominata la ricompensa. */
  network: string;
  status: RewardStatus;
  /** Task/azione da cui deriva la ricompensa. */
  source: string;
  earnedAt: number;
  /** Hash di transazione (mining on-chain / claim airdrop). */
  txHash?: string | null;
}

export interface AffiliateClickPayload {
  partnerId: string;
  taskId: string;
  kind: AffiliateActionKind;
  clickId: string;
  url: string;
  /** Ricompensa reale che l'utente ottiene completando l'azione. */
  reward?: {
    kind: RewardKind;
    project: string;
    tokenSymbol: string;
    amount?: number | null;
    network?: string;
  };
}

const REWARDS_KEY = 'af_real_rewards_v1';
const CLICKS_KEY = 'af_affiliate_clicks_v1';

/* -------------------------------------------------------------------------- */
/* IDENTIFICATIVI                                                             */
/* -------------------------------------------------------------------------- */

export function newClickId(): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `af_${Date.now().toString(36)}_${rand}`;
}

export function newRewardId(seed: string): string {
  return `rw_${seed}_${Date.now().toString(36)}`;
}

/* -------------------------------------------------------------------------- */
/* LINK DI AFFILIAZIONE                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Costruisce il link di affiliazione ufficiale aggiungendo gli identificativi
 * di tracciamento (click_id + sub id). Il link resta quello del partner: non
 * viene riscritto, viene solo arricchito dei parametri di tracciamento.
 */
export function buildAffiliateUrl(
  baseUrl: string,
  params: { clickId: string; partnerId?: string; subId?: string; sub2?: string }
): string {
  if (!baseUrl) return baseUrl;
  const sep = baseUrl.includes('?') ? '&' : '?';
  const query: string[] = [`click_id=${encodeURIComponent(params.clickId)}`];
  if (params.partnerId) query.push(`partner_id=${encodeURIComponent(params.partnerId)}`);
  if (params.subId) query.push(`sub_id=${encodeURIComponent(params.subId)}`);
  if (params.sub2) query.push(`sub2=${encodeURIComponent(params.sub2)}`);
  return `${baseUrl}${sep}${query.join('&')}`;
}

/* -------------------------------------------------------------------------- */
/* TRACCIAMENTO CLICK                                                         */
/* -------------------------------------------------------------------------- */

function persistClick(payload: AffiliateClickPayload): void {
  try {
    const raw = localStorage.getItem(CLICKS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    list.unshift({ ...payload, ts: Date.now() });
    localStorage.setItem(CLICKS_KEY, JSON.stringify(list.slice(0, 200)));
  } catch {
    /* storage non disponibile: il click resta comunque tracciato lato server */
  }
}

/**
 * Registra il click di affiliazione lato server (provento TON della piattaforma).
 * Non blocca mai l'azione dell'utente: in caso di errore si prosegue.
 */
export async function trackAffiliateClick(payload: AffiliateClickPayload): Promise<void> {
  persistClick(payload);
  try {
    await fetch('/api/affiliate/click', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true,
    });
  } catch {
    /* tracking non disponibile: l'azione utente prosegue */
  }
}

/**
 * Apre un link di affiliazione tracciato: il click parte SEMPRE dal link
 * ufficiale del partner, con il click_id che permette al partner di
 * attribuire la conversione e all'applicazione di incassarne il provento.
 */
export function openTrackedLink(
  url: string,
  meta: {
    partnerId: string;
    taskId?: string;
    telegramId?: number;
    kind?: AffiliateActionKind;
    reward?: AffiliateClickPayload['reward'];
  }
): void {
  const clickId = newClickId();
  const taskId = meta.taskId || `task_${meta.partnerId}`;
  const tracked = buildAffiliateUrl(url, {
    clickId,
    partnerId: meta.partnerId,
    subId: meta.telegramId ? String(meta.telegramId) : undefined,
  });

  void trackAffiliateClick({
    partnerId: meta.partnerId,
    taskId,
    kind: meta.kind || 'TASK',
    clickId,
    url: tracked,
    reward: meta.reward,
  });

  openAnyUrlSafely(tracked, {
    slotId: taskId,
    providerKey: meta.partnerId,
    campaignId: clickId,
    pageContext: 'affiliate',
  });
}

/* -------------------------------------------------------------------------- */
/* RICOMPENSE REALI DELL'UTENTE                                               */
/* -------------------------------------------------------------------------- */

export function readRealRewards(): RealReward[] {
  try {
    const raw = localStorage.getItem(REWARDS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? (list as RealReward[]) : [];
  } catch {
    return [];
  }
}

export function writeRealRewards(list: RealReward[]): void {
  try {
    localStorage.setItem(REWARDS_KEY, JSON.stringify(list.slice(0, 100)));
  } catch {
    /* storage non disponibile */
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('af-rewards-changed'));
  }
}

/**
 * Accorda una ricompensa REALE all'utente e la registra lato server.
 * Nessuna ricompensa fittizia: senza progetto/token/rete la ricompensa
 * viene scartata invece di essere mostrata.
 */
export async function recordRealReward(
  reward: Omit<RealReward, 'id' | 'earnedAt' | 'status'> & { status?: RewardStatus }
): Promise<RealReward | null> {
  if (!reward.project || !reward.tokenSymbol || !reward.network) return null;

  const full: RealReward = {
    ...reward,
    id: newRewardId(reward.source || reward.project),
    earnedAt: Date.now(),
    status: reward.status || 'PENDING',
  };

  const list = readRealRewards();
  writeRealRewards([full, ...list]);

  try {
    await fetch('/api/rewards/record', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(full),
    });
  } catch {
    /* la ricompensa resta comunque nel profilo locale */
  }

  return full;
}

/** Totale delle ricompense reali per tipo (per la testata). */
export function summarizeRealRewards(list: RealReward[]): {
  total: number;
  airdrop: number;
  token: number;
  mining: number;
} {
  return {
    total: list.length,
    airdrop: list.filter((r) => r.kind === 'AIRDROP').length,
    token: list.filter((r) => r.kind === 'TOKEN').length,
    mining: list.filter((r) => r.kind === 'MINING').length,
  };
}
