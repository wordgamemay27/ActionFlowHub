// ============================================================================
// WITHDRAW VIEW - Prelievo CASH (Valuta Locale 190+ Paesi) & CRYPTO (USDT/TON)
// ============================================================================
import React, { useState } from 'react';
import {
  ArrowLeft,
  Send,
  Loader2,
  ClipboardPaste as Paste,
  Banknote,
  Wallet,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { CleanAdSlot } from '../components/CleanAdSlot';
import { UserProfile, Transaction } from '../types';
import { calculateTonEquivalent } from '../services/api';
import { openTrackedLink } from '../lib/affiliate';
import { useTranslation } from '../lib/i18n';
import { EXTRA_UI_LOCALIZATION } from '../lib/providerLocalization';

interface WithdrawViewProps {
  user: UserProfile;
  transactions: Transaction[];
  onRequestWithdrawal: (points: number, wallet: string, asset?: string) => Promise<boolean>;
  onNavigateHome: () => void;
}

type PayoutMode = 'CASH_LOCAL' | 'CRYPTO_DIRECT';

const LOCAL_CASH_GATEWAYS = [
  {
    key: 'AIRTM' as const,
    tabLabel: 'Airtm (Cash 190+)',
    gatewayName: 'Airtm Global Cash-Out',
    signupUrl: 'https://app.airtm.com/signup',
    supportedLocalMethods:
      'WeChat Pay, Alipay • Vodafone Cash, InstaPay • CIH Bank, Cash Plus, Inwi Money • BaridiMob CCP • bKash, Nagad • Euro SEPA, Revolut, Postepay, Pix, MoneyGram',
    inputLabel: 'Airtm Email / Username',
    placeholder: 'email@example.com',
    hint: 'USDC/USD -> Local Currency (EUR, USD, CNY, MAD, DZD, EGP, BDT, BRL)',
    prefixTag: 'CASH-AIRTM:',
  },
  {
    key: 'PAYEER' as const,
    tabLabel: 'Payeer (USD / EUR)',
    gatewayName: 'Payeer Multi-Currency (USD / EUR)',
    signupUrl: 'https://payeer.com/en/auth/?register=yes',
    supportedLocalMethods:
      'Instant USD/EUR • Visa/Mastercard, Local Bank & Mobile Money',
    inputLabel: 'Payeer Account (P...)',
    placeholder: 'P108459201',
    hint: 'Direct USD/EUR credit to your Payeer account (P12345678).',
    prefixTag: 'CASH-PAYEER:',
  },
  {
    key: 'VOLET' as const,
    tabLabel: 'Volet / AdvCash',
    gatewayName: 'Volet.com (AdvCash) Global Cash',
    signupUrl: 'https://volet.com/',
    supportedLocalMethods:
      'Visa/Mastercard, Local Bank Transfer, Mobile Money',
    inputLabel: 'Volet Account Email',
    placeholder: 'user@example.com',
    hint: 'Direct USD/EUR cash balance on Volet.',
    prefixTag: 'CASH-VOLET:',
  },
];

const CRYPTO_NETWORKS = [
  {
    key: 'TON' as const,
    tabLabel: 'TON (USDT / TON)',
    walletAppName: 'Tonkeeper / Telegram Wallet',
    walletAppUrl: 'https://tonkeeper.com',
    addressPlaceholder: {
      it: 'Incolla il tuo indirizzo Tonkeeper (UQ... o EQ...)',
      en: 'Paste your Tonkeeper address (UQ... or EQ...)',
    },
    addressHint: {
      it: 'Indirizzo Tonkeeper (UQ... o EQ...) sulla Rete TON per ricevere USDT, TON, GRAM o NOT.',
      en: 'Tonkeeper address (UQ... or EQ...) on TON Network to receive USDT, TON, GRAM or NOT.',
    },
    network: 'TON' as const,
    nativeTokenSymbol: 'TON',
    nativeTokenDecimals: 9,
  },
  {
    key: 'SOLANA' as const,
    tabLabel: 'USDT / Solana',
    walletAppName: 'Phantom / Trust Wallet',
    walletAppUrl: 'https://phantom.app',
    addressPlaceholder: {
      it: 'Incolla il tuo indirizzo Solana / USDT (Phantom o Trust Wallet)',
      en: 'Paste your Solana / USDT address (Phantom or Trust Wallet)',
    },
    addressHint: {
      it: 'Indirizzo Solana (Base58) per ricevere USDT, USDC o SOL direttamente sul tuo wallet.',
      en: 'Solana address (Base58) to receive USDT, USDC or SOL directly in your wallet.',
    },
    network: 'SOLANA' as const,
    nativeTokenSymbol: 'SOL',
    nativeTokenDecimals: 9,
  },
  {
    key: 'PI_NETWORK' as const,
    tabLabel: 'Pi Network',
    walletAppName: 'Pi Wallet',
    walletAppUrl: 'https://minepi.com',
    addressPlaceholder: {
      it: 'Incolla il tuo indirizzo Pi Wallet pubblico (inizia con G...)',
      en: 'Paste your public Pi Wallet address (starts with G...)',
    },
    addressHint: {
      it: 'Indirizzo Pi Wallet pubblico (inizia con G...) per ricevere Pi Coin (PI).',
      en: 'Public Pi Wallet address (starts with G...) to receive Pi Coin (PI).',
    },
    network: 'PI_NETWORK' as const,
    nativeTokenSymbol: 'PI',
    nativeTokenDecimals: 6,
  },
];

export const WithdrawView: React.FC<WithdrawViewProps> = ({
  user,
  transactions,
  onRequestWithdrawal,
  onNavigateHome,
}) => {
  const { t, lang } = useTranslation();
  const extra = EXTRA_UI_LOCALIZATION[lang] || EXTRA_UI_LOCALIZATION.en;
  const [payoutMode, setPayoutMode] = useState<PayoutMode>('CASH_LOCAL');
  const [activeCashGateway, setActiveCashGateway] = useState<0 | 1 | 2>(0);
  const [activeNetwork, setActiveNetwork] = useState<0 | 1 | 2>(0);
  const [walletAddress, setWalletAddress] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [acceptedLegalDisclaimer, setAcceptedLegalDisclaimer] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const network = CRYPTO_NETWORKS[activeNetwork] || CRYPTO_NETWORKS[0];
  const cashGateway = LOCAL_CASH_GATEWAYS[activeCashGateway] || LOCAL_CASH_GATEWAYS[0];

  // Scala unica nel Wallet: 100 PT = 1,00 $ (1 PT = 0,01 $ | Minimo prelievo: 500 PT = 5,00 $)
  const usdEquivalent = (pts: number) => (pts * 0.01).toFixed(2);

  const handlePayout = async () => {
    const cleanTarget = walletAddress.trim();
    if (!cleanTarget) {
      setError(
        payoutMode === 'CASH_LOCAL'
          ? `${cashGateway.gatewayName}: ${cashGateway.inputLabel}`
          : 'Wallet address required'
      );
      return;
    }

    if (!acceptedLegalDisclaimer) {
      setError('3-Strike Policy confirmation required');
      return;
    }

    if (payoutMode === 'CRYPTO_DIRECT') {
      if (activeNetwork === 0 && (!/^(UQ|EQ)/i.test(cleanTarget) || cleanTarget.length < 48)) {
        setError('Invalid TON address (UQ... / EQ...)');
        return;
      }
    } else {
      if (cashGateway.key === 'PAYEER' && !/^P\d{6,15}$/i.test(cleanTarget)) {
        setError('Invalid Payeer ID (P10845920)');
        return;
      }
      if (cashGateway.key === 'AIRTM' || cashGateway.key === 'VOLET') {
        const emailLike = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(cleanTarget);
        const usernameLike = /^[a-z0-9._-]{3,32}$/i.test(cleanTarget);
        if (!emailLike && !usernameLike) {
          setError(`Invalid ${cashGateway.gatewayName} account (email o username)`);
          return;
        }
      }
    }

    if (user.points < 500) {
      setError(t.ui.minWithdrawLabel);
      return;
    }

    const points = parseInt(withdrawAmount, 10) || 500;
    if (points < 500) {
      setError(t.ui.minWithdrawLabel);
      return;
    }
    if (points > user.points) {
      setError(t.ui.availablePointsLabel);
      return;
    }

    setIsLoading(true);
    setError(null);

    const formattedRecipient =
      payoutMode === 'CASH_LOCAL'
        ? `${cashGateway.prefixTag}${cleanTarget}`
        : cleanTarget;

    const chosenAsset =
      payoutMode === 'CASH_LOCAL'
        ? `CASH_${cashGateway.key}`
        : network.nativeTokenSymbol;

    try {
      const ok = await onRequestWithdrawal(points, formattedRecipient, chosenAsset);
      if (ok) {
        setSuccess(
          payoutMode === 'CASH_LOCAL'
            ? `$${usdEquivalent(points)} -> ${cashGateway.gatewayName}`
            : `${points} PT -> ${network.nativeTokenSymbol}`
        );
        setWalletAddress('');
        setWithdrawAmount('');
        setTimeout(() => setSuccess(null), 4000);
      } else {
        setError('Error');
      }
    } catch {
      setError('Error');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePaste = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        setWalletAddress(text.trim());
        setError(null);
      })
      .catch(() => {});
  };

  const formatAddress = (address: string): string => {
    const clean = address.trim();
    if (clean.startsWith('CASH-')) {
      return clean.replace('CASH-', '💵 ');
    }
    if (clean.length > 14) {
      return `${clean.slice(0, 6)}...${clean.slice(-6)}`;
    }
    return clean;
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-3.5 pb-14 animate-fade-in select-none">
      {/* CLEAN AD SLOT IN ALTO */}
      <CleanAdSlot page="wallet" placement="WALLET_TOP" telegramUserId={user?.telegramId} />

      {/* HEADER CHIARO: INCASSA CASH IN VALUTA LOCALE O CRYPTO (SENZA BOOST) */}
      <div className="flex items-center justify-between gap-3 px-1 py-1">
        <button
          type="button"
          onClick={onNavigateHome}
          className="p-2.5 rounded-xl bg-[#0098EA] text-white hover:bg-cyan-400 hover:text-slate-950 border-0 cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0 shadow-md"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h2 className="text-lg font-black text-white">{t.ui.withdrawTitle}</h2>
          <div className="text-xs text-emerald-300 font-bold">
            {t.ui.withdrawSubtitle}
          </div>
        </div>
        <span className="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 font-mono text-[11px] font-black text-emerald-300 shrink-0">
          100 PT = $1.00
        </span>
      </div>

      {/* SALDO CON RIFERIMENTO DIRETTO PUNTI -> CASH (USD/VALUTA LOCALE) & CRYPTO */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-2xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 p-3.5 border border-emerald-500/30 text-center">
          <div className="text-[10px] font-mono text-emerald-300/80 uppercase tracking-wider">{t.ui.availablePointsLabel}</div>
          <div className="text-xl sm:text-2xl font-black text-amber-400 tabular-nums">{user.points.toLocaleString()} PT</div>
          <div className="text-[10px] font-bold text-emerald-300">
            {t.ui.minWithdrawLabel}
          </div>
        </div>
        <div className="rounded-2xl bg-gradient-to-r from-green-500/25 to-emerald-500/25 p-3.5 border border-green-400/40 text-center">
          <div className="text-[10px] font-mono text-green-300 uppercase tracking-wider">{t.ui.cashValueLabel}</div>
          <div className="text-xl sm:text-2xl font-black text-white tabular-nums">${usdEquivalent(user.points)}</div>
          <div className="text-[10px] font-bold text-green-300">100 PT = $1.00</div>
        </div>
        <div className="rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 p-3.5 border border-amber-500/30 text-center">
          <div className="text-[10px] font-mono text-amber-300/80 uppercase tracking-wider">{t.ui.tonValueLabel}</div>
          <div className="text-xl sm:text-2xl font-black text-white tabular-nums">{calculateTonEquivalent(user.points).toFixed(4)}</div>
          <div className="text-[10px] text-amber-300/80">TON Network</div>
        </div>
      </div>

      {/* SELETTORE PRINCIPALE: 1. CONTANTI VALUTA LOCALE (CASH) vs 2. CRYPTO DIRETTA */}
      <div className="grid grid-cols-2 gap-2.5 p-1.5 rounded-2xl bg-[#0A1220] border border-sky-500/20">
        <button
          type="button"
          onClick={() => {
            setPayoutMode('CASH_LOCAL');
            setWalletAddress('');
            setError(null);
          }}
          className={`py-3 px-3 rounded-xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer border-0 ${
            payoutMode === 'CASH_LOCAL'
              ? 'bg-gradient-to-r from-emerald-400 via-green-400 to-teal-400 text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.4)]'
              : 'bg-[#131F3A]/80 text-slate-300 hover:bg-[#192848]'
          }`}
        >
          <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm uppercase">
            <Banknote className="w-4 h-4 shrink-0" />
            <span>{t.ui.cashLocalTab}</span>
          </div>
          <span className={`text-[10px] font-bold ${payoutMode === 'CASH_LOCAL' ? 'text-slate-900' : 'text-emerald-300/80'}`}>
            EUR, USD, WeChat, Vodafone Cash, Pix, bKash
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            setPayoutMode('CRYPTO_DIRECT');
            setWalletAddress('');
            setError(null);
          }}
          className={`py-3 px-3 rounded-xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer border-0 ${
            payoutMode === 'CRYPTO_DIRECT'
              ? 'bg-gradient-to-r from-sky-400 via-cyan-300 to-blue-400 text-slate-950 shadow-[0_0_20px_rgba(56,189,248,0.4)]'
              : 'bg-[#131F3A]/80 text-slate-300 hover:bg-[#192848]'
          }`}
        >
          <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm uppercase">
            <Wallet className="w-4 h-4 shrink-0" />
            <span>{t.ui.cryptoWalletTab}</span>
          </div>
          <span className={`text-[10px] font-bold ${payoutMode === 'CRYPTO_DIRECT' ? 'text-slate-900' : 'text-sky-300/80'}`}>
            USDT, TON, Solana, Pi Network
          </span>
        </button>
      </div>

      {/* MODALITÀ 1: CONTANTI IN VALUTA LOCALE (190+ PAESI) */}
      {payoutMode === 'CASH_LOCAL' && (
        <div className="rounded-2xl bg-[#0A1220] border border-emerald-500/30 p-3.5 space-y-3">
          {/* TABS GATEWAY CASH */}
          <div className="grid grid-cols-3 gap-2">
            {LOCAL_CASH_GATEWAYS.map((gw, idx) => (
              <button
                key={gw.key}
                type="button"
                onClick={() => {
                  setActiveCashGateway(idx as 0 | 1 | 2);
                  setWalletAddress('');
                  setError(null);
                }}
                className={`py-2 px-2 rounded-xl text-xs font-black uppercase tracking-wider border cursor-pointer transition-all ${
                  activeCashGateway === idx
                    ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-md'
                    : 'bg-[#131F3A]/80 border-sky-500/15 text-slate-300 hover:bg-[#192848]'
                }`}
              >
                {gw.tabLabel}
              </button>
            ))}
          </div>

          {/* DETTAGLIO VALUTE E PAESI SUPPORTATI + PULSANTE CREAZIONE CONTO */}
          <div className="rounded-xl bg-[#0E1A2F] border border-emerald-500/20 p-3 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-black text-white">{cashGateway.gatewayName}</span>
              <button
                type="button"
                onClick={() =>
                  openTrackedLink(cashGateway.signupUrl, {
                    partnerId: `withdraw_cash_${cashGateway.key.toLowerCase()}`,
                    taskId: `signup_${cashGateway.key.toLowerCase()}`,
                    telegramId: user.telegramId,
                    kind: 'SIGNUP',
                  })
                }
                className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-black text-[11px] uppercase flex items-center gap-1 cursor-pointer border-0 active:scale-95"
              >
                <span>{t.ui.openFreeCashAccountBtn}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
            <div className="text-[11px] text-emerald-300/90 leading-relaxed">
              <strong>{t.ui.whereToCashOutLabel}</strong> {cashGateway.supportedLocalMethods}
            </div>
          </div>

          {/* INPUT EMAIL / ID CONTO CASH */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-emerald-300">
              {cashGateway.inputLabel}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={walletAddress}
                onChange={(e) => {
                  setWalletAddress(e.target.value);
                  setError(null);
                }}
                placeholder={cashGateway.placeholder}
                className="flex-1 px-3 py-2.5 rounded-xl bg-[#060B14] border border-emerald-400/30 text-white text-sm font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-400"
              />
              <button
                type="button"
                onClick={handlePaste}
                className="px-3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-mono text-xs font-black uppercase cursor-pointer active:scale-95 border-0 shadow-lg flex items-center"
              >
                <Paste className="w-4 h-4 mr-1" />
                <span>{t.ui.pasteBtn}</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-400 leading-snug">{cashGateway.hint}</p>
          </div>
        </div>
      )}

      {/* MODALITÀ 2: CRYPTO DIRETTA (TON, SOLANA/USDT, PI NETWORK) */}
      {payoutMode === 'CRYPTO_DIRECT' && (
        <div className="rounded-2xl bg-[#0A1220] border border-sky-500/30 p-3.5 space-y-3">
          <div className="flex justify-between items-center gap-2 flex-wrap">
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
              {CRYPTO_NETWORKS.map((net, idx) => (
                <button
                  key={net.key}
                  type="button"
                  onClick={() => {
                    setActiveNetwork(idx as 0 | 1 | 2);
                    setWalletAddress('');
                    setError(null);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider shrink-0 border-0 cursor-pointer ${
                    activeNetwork === idx
                      ? 'bg-gradient-to-r from-sky-400 via-cyan-300 to-blue-400 text-slate-950 shadow-lg'
                      : 'bg-[#131F3A]/90 text-slate-300 hover:bg-[#192848]'
                  }`}
                >
                  {net.tabLabel}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() =>
                  openTrackedLink('https://www.bybit.com/invite', {
                    partnerId: `withdraw_exchange_${network.key.toLowerCase()}`,
                    taskId: `signup_exchange_${network.key.toLowerCase()}`,
                    telegramId: user.telegramId,
                    kind: 'SIGNUP',
                  })
                }
                className="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-black text-[10px] uppercase shrink-0 flex items-center gap-1 cursor-pointer active:scale-95"
              >
                <span>1. Bybit / Exchange</span>
                <ExternalLink className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() =>
                  openTrackedLink(network.walletAppUrl, {
                    partnerId: `withdraw_wallet_${network.key.toLowerCase()}`,
                    taskId: `signup_wallet_${network.key.toLowerCase()}`,
                    telegramId: user.telegramId,
                    kind: 'SIGNUP',
                  })
                }
                className="px-2.5 py-1.5 rounded-xl bg-sky-500/20 border border-sky-400/30 text-sky-300 font-black text-[10px] uppercase shrink-0 flex items-center gap-1 cursor-pointer active:scale-95"
              >
                <span>Wallet {network.walletAppName.split(' ')[0]}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-sky-300/80">
              {t.ui.walletAddressLabel} ({network.nativeTokenSymbol} / USDT)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={walletAddress}
                onChange={(e) => {
                  setWalletAddress(e.target.value);
                  setError(null);
                }}
                placeholder={lang === 'it' ? network.addressPlaceholder.it : network.addressPlaceholder.en}
                className="flex-1 px-3 py-2.5 rounded-xl bg-[#060B14] border border-sky-400/20 text-white text-sm font-mono placeholder-slate-500 focus:outline-none focus:border-sky-400"
              />
              <button
                type="button"
                onClick={handlePaste}
                className="px-3 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 text-slate-950 font-mono text-xs font-black uppercase cursor-pointer active:scale-95 border-0 shadow-lg flex items-center"
              >
                <Paste className="w-4 h-4 mr-1" />
                <span>{t.ui.pasteBtn}</span>
              </button>
            </div>
            {network.addressHint && (
              <p className="text-[10px] text-slate-400 leading-snug">
                {lang === 'it' ? network.addressHint.it : network.addressHint.en}
              </p>
            )}
          </div>
        </div>
      )}

      {/* SELEZIONE IMPORTO PUNTI */}
      <div className="space-y-2 rounded-2xl bg-[#0A1220] border border-sky-500/15 p-3.5">
        <div className="flex items-center justify-between text-sm">
          <span className="font-black text-white">{t.ui.amountToCashOutLabel}</span>
          <span className="text-xs font-black text-amber-400">{t.ui.availableLabel}: {user.points} PT</span>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={500}
            max={user.points}
            value={withdrawAmount}
            placeholder="500"
            onChange={(e) => {
              setWithdrawAmount(e.target.value);
              setError(null);
            }}
            className="flex-1 px-3 py-2 bg-[#171b20] border border-sky-400/20 rounded-xl text-sm font-black text-white focus:outline-none focus:border-sky-400"
          />
          <span className="text-xs font-mono font-bold text-emerald-300">
            ≈ ${usdEquivalent(parseInt(withdrawAmount, 10) || 500)}{' '}
            {payoutMode === 'CASH_LOCAL' ? 'CASH' : `USDT (${calculateTonEquivalent(parseInt(withdrawAmount, 10) || 500).toFixed(4)} ${network.nativeTokenSymbol})`}
          </span>
        </div>

        {/* BOTTONI IMPORTI RAPIDI */}
        <div className="grid grid-cols-4 gap-2 pt-1">
          {['500', '1000', '2500', '5000'].map((amt) => (
            <button
              key={amt}
              type="button"
              onClick={() => {
                setWithdrawAmount(amt);
                setError(null);
              }}
              className="py-2 px-3 rounded-xl bg-[#131F3A]/90 hover:bg-[#192848] text-white text-xs sm:text-sm font-black border border-sky-400/20 active:scale-95 cursor-pointer"
            >
              {amt} PT
            </button>
          ))}
        </div>
      </div>

      {/* REGOLA RIGIDA 3 STRIKE (FLESSIBILITÀ ZERO — UTENTI E FORNITORI) */}
      <div className="rounded-2xl bg-[#091224] border border-cyan-400/35 p-3.5 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs font-mono font-black uppercase tracking-wider text-cyan-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>3-STRIKE PROTOCOL (1 = OK • 2 = WARN • 3 = BLOCK)</span>
          </div>
          <span className="px-2 py-0.5 rounded bg-rose-500/20 border border-rose-400/40 text-[10px] font-mono font-black text-rose-300">
            S2S GUARD
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/40 p-2">
            <div className="text-xs font-black text-emerald-300 uppercase">1 = OK</div>
          </div>
          <div className="rounded-xl bg-amber-500/15 border border-amber-400/40 p-2">
            <div className="text-xs font-black text-amber-300 uppercase">2 = WARN</div>
          </div>
          <div className="rounded-xl bg-rose-500/20 border border-rose-400/50 p-2">
            <div className="text-xs font-black text-rose-300 uppercase">3 = BLOCK</div>
          </div>
        </div>
      </div>

      {/* CLAUSOLA DI ESONERO RESPONSABILITÀ & AUTONOMIA FISCALE DELL'UTENTE */}
      <div className="rounded-2xl bg-[#08101E] border border-amber-500/25 p-3 space-y-2">
        <label className="flex items-start gap-2.5 cursor-pointer">
          <input
            type="checkbox"
            checked={acceptedLegalDisclaimer}
            onChange={(e) => setAcceptedLegalDisclaimer(e.target.checked)}
            className="mt-1 w-4 h-4 accent-emerald-400 rounded cursor-pointer shrink-0"
          />
          <span className="text-[11px] text-slate-300 leading-snug">
            <strong className="text-amber-300">3-Strike &amp; Tax Autonomy:</strong> 1 = OK • 2 = WARN • 3 = BLOCK ({payoutMode === 'CASH_LOCAL' ? cashGateway.gatewayName : network.walletAppName}).
          </span>
        </label>
      </div>

      {/* Messaggio di errore */}
      {error && (
        <div className="text-sm text-red-400 p-3 rounded-xl bg-[#0A1122] border border-red-500/30 font-bold">
          {error}
        </div>
      )}

      {/* Stato elaborazione */}
      {isLoading && (
        <div className="rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-sm p-4 shadow-md flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span className="font-black text-sm">...</span>
        </div>
      )}

      {/* Messaggio di successo */}
      {success && (
        <div className="rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 p-4 text-white">
          <div className="flex items-center gap-1.5 text-sm font-black">
            <CheckCircle2 className="w-4 h-4" />
            <span>OK</span>
          </div>
          <div className="text-xs text-white/95 mt-0.5">{success}</div>
        </div>
      )}

      {/* Bottoni di azione */}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={onNavigateHome}
          className="flex items-center justify-center py-2.5 px-4 rounded-xl bg-[#131F3A] text-white font-mono text-xs font-black uppercase cursor-pointer active:scale-95 border border-sky-500/20"
        >
          {t.ui.backBtn}
        </button>
        <button
          type="button"
          onClick={handlePayout}
          disabled={isLoading || !acceptedLegalDisclaimer}
          className="flex-1 py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-400 via-green-400 to-teal-400 text-slate-950 font-mono text-sm sm:text-base font-black uppercase cursor-pointer active:scale-95 border-0 shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
          <span>
            {payoutMode === 'CASH_LOCAL'
              ? `${t.ui.cashOutOnBtn} ${cashGateway.key}`
              : `${t.ui.cashOutCryptoBtn} (${network.nativeTokenSymbol})`}
          </span>
        </button>
      </div>

      {/* CRONOLOGIA PRELIEVI */}
      <div className="space-y-3 pt-3 border-t border-sky-500/10">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black text-white">{t.ui.withdrawHistoryTitle}</h3>
        </div>
        {transactions
          .filter((txItem) => txItem.type === 'WITHDRAWAL')
          .slice(0, 10)
          .map((tx) => (
            <div
              key={tx.id}
              className="rounded-xl bg-[#0A1220] p-3 border border-sky-500/10 flex items-center justify-between"
            >
              <div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-black text-white">{tx.amountPoints.toLocaleString()} PT</span>
                  <span className="text-[11px] font-mono text-emerald-300">
                    ≈ ${usdEquivalent(tx.amountPoints)}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-black ${
                      tx.status === 'COMPLETED'
                        ? 'text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400'
                        : tx.status === 'CANCELLED' || tx.status === 'FAILED'
                        ? 'text-rose-300 bg-rose-500/20 border border-rose-400/35'
                        : 'text-amber-300 bg-amber-500/20 border border-amber-400/35'
                    }`}
                  >
                    {tx.status === 'COMPLETED'
                      ? t.ui.completedBadge
                      : tx.status === 'CANCELLED' || tx.status === 'FAILED'
                      ? 'RIMBORSATO'
                      : 'IN ELABORAZIONE'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 truncate max-w-[230px]">
                  {formatAddress(tx.recipientWallet || '')}
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-slate-400">
                  {new Date(tx.timestamp).toLocaleDateString()}
                </div>
                <div className="text-[10px] text-slate-400">
                  {new Date(tx.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>
            </div>
          ))}
        {transactions.filter((txItem) => txItem.type === 'WITHDRAWAL').length === 0 && (
          <div className="text-center py-5 text-slate-400 text-sm">{t.ui.noWithdrawalsYet}</div>
        )}
      </div>

      {/* NOTA LEGALE INTERNAZIONALE DI ESONERO RESPONSABILITÀ PIATTAFORMA */}
      <div className="rounded-2xl bg-[#060B14] border border-slate-800 p-3.5 space-y-1.5 text-[10px] text-slate-400 leading-relaxed">
        <div className="flex items-center gap-1.5 text-slate-300 font-black uppercase tracking-wider text-[10px]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{extra.legalTitle}</span>
        </div>
        <p>{extra.legalPoint1}</p>
        <p>{extra.legalPoint2}</p>
        <p>{extra.legalPoint3}</p>
      </div>
    </div>
  );
};

export default WithdrawView;

