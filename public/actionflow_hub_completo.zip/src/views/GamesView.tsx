// ============================================================================
// GAMES VIEW — Giochi Case Madri Dirette & Web3 (Zero Doppioni)
// Cliccando la foto si aprono le istruzioni interne di esecuzione e Mail.
// ============================================================================

import React, { useState, useMemo } from 'react';
import { ArrowLeft, Gamepad2 } from 'lucide-react';
import { CleanAdSlot } from '../components/CleanAdSlot';
import {
  ProviderCardWithPhoto,
  ProviderExecutionModal,
  VerifiedProviderItem,
} from '../components/ProviderExecutionModal';
import { VERIFIED_GAMES_PROVIDERS, VERIFIED_UX_QA_PROVIDERS } from '../lib/verifiedDirectProviders';
import { openTrackedLink } from '../lib/affiliate';
import { SupportedLang, useTranslation } from '../lib/i18n';
import { ProjectCardData, ProjectActionItem } from '../lib/catalogData';
import { UserProfile } from '../types';

interface GamesViewProps {
  user: UserProfile;
  lang: SupportedLang;
  subCategory?: 'mobile' | 'pc' | 'all';
  onBack: () => void;
  onSelectProjectAction: (
    project: ProjectCardData,
    action: ProjectActionItem,
    actionIdx: number
  ) => void;
  pendingActions?: Record<string, any>;
}

const MOBILE_GAME_IDS = new Set([
  'game-catizen-ton',
  'game-playdeck-ton',
  'game-sweat-dubai',
  'game-zbd-lightning',
  'game-thndr-lightning',
  'game-fumb-bitcoinminer',
  'game-smiles-lightning',
  'game-bling-crypto',
  'game-womplay-direct',
  'game-rollercoin-direct',
  'game-plarium-direct',
  'game-wargaming-direct',
  'game-gala-web3',
  'qa-playtestcloud-direct',
]);

const PC_WEB_GAME_IDS = new Set([
  'game-catizen-ton',
  'game-playdeck-ton',
  'game-sweat-dubai',
  'game-rollercoin-direct',
  'game-womplay-direct',
  'game-smiles-lightning',
  'game-gaijin-direct',
  'game-splinterlands-web3',
  'game-epic-direct',
  'game-xsolla-partner',
  'game-wargaming-direct',
  'game-gala-web3',
]);

export const GamesView: React.FC<GamesViewProps> = ({
  user,
  subCategory = 'all',
  onBack,
  onSelectProjectAction,
}) => {
  const { t } = useTranslation();
  const [selectedProvider, setSelectedProvider] = useState<VerifiedProviderItem | null>(null);

  const providers = useMemo(() => {
    const playtest = VERIFIED_UX_QA_PROVIDERS.find((p) => p.id === 'qa-playtestcloud-direct');
    const allGames = playtest ? [...VERIFIED_GAMES_PROVIDERS, playtest] : VERIFIED_GAMES_PROVIDERS;
    const filtered =
      subCategory === 'mobile'
        ? allGames.filter((p) => MOBILE_GAME_IDS.has(p.id))
        : subCategory === 'pc'
        ? allGames.filter((p) => PC_WEB_GAME_IDS.has(p.id))
        : allGames;
    return [...filtered].sort((a, b) => Number(Boolean(a.isLocked)) - Number(Boolean(b.isLocked)));
  }, [subCategory]);

  const titleText =
    subCategory === 'mobile'
      ? `🎮 ${t.nav.games_mobile}`
      : subCategory === 'pc'
      ? `🖥️ ${t.nav.games_pc}`
      : `🎮 ${t.nav.games}`;

  const descText =
    subCategory === 'mobile'
      ? t.ui.gamesMobileDesc
      : subCategory === 'pc'
      ? t.ui.gamesPcDesc
      : t.ui.gamesAllDesc;

  const handleExecuteProvider = (provider: VerifiedProviderItem) => {
    openTrackedLink(provider.directUrl, {
      partnerId: provider.id,
      telegramId: user.telegramId,
    });
    if (!provider.isServiceOnly && provider.userPoints > 0) {
      onSelectProjectAction(
        {
          id: provider.id,
          pageId: 'page_games_ladder',
          durationBucket: 'FAST',
          provider: provider.name,
          title: { it: provider.name, en: provider.name } as any,
          actions: [],
        },
        {
          label: { it: provider.name, en: provider.name } as any,
          points: provider.userPoints,
          directUrl: provider.directUrl,
        },
        0
      );
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4 pb-12 animate-fade-in select-none">
      <CleanAdSlot page="games" placement="GAMES_TOP" telegramUserId={user.telegramId} />

      <div className="rounded-2xl border border-sky-400/25 bg-[#071122]/90 p-4 space-y-2">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onBack}
            className="p-2.5 rounded-xl bg-[#0098EA] text-white hover:bg-cyan-400 hover:text-slate-950 border-0 cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0 shadow-md"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-sky-400">
              <Gamepad2 className="w-4 h-4 text-sky-300" />
              <span>{titleText}</span>
            </div>
            <p className="text-xs text-slate-300 leading-snug mt-0.5">
              {descText}{' '}
              <strong className="text-amber-300">{t.ui.tapPhotoHint}</strong>
            </p>
          </div>
        </div>
      </div>

      {/* UNICA GRIGLIA PULITA SENZA DOPPIONI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {providers.map((provider) => (
          <ProviderCardWithPhoto
            key={provider.id}
            provider={provider}
            onOpenInstructions={(p) => setSelectedProvider(p)}
            onExecuteDirect={handleExecuteProvider}
          />
        ))}
      </div>

      <ProviderExecutionModal
        provider={selectedProvider}
        onClose={() => setSelectedProvider(null)}
        onExecute={handleExecuteProvider}
      />
    </div>
  );
};

export default GamesView;

