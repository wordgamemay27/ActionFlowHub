// ============================================================================
// RECEIPT OCR VIEW — Scontrini GEO (Filtro Automatico Paese IT/UE vs USA/UK/CA)
// Cliccando la foto si aprono le istruzioni interne di esecuzione e modalità.
// ============================================================================

import React, { useState, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  Camera,
  CheckCircle2,
  X,
  Loader2,
  AlertCircle,
  Globe,
} from 'lucide-react';
import { CleanAdSlot } from '../components/CleanAdSlot';
import {
  ProviderCardWithPhoto,
  ProviderExecutionModal,
  VerifiedProviderItem,
} from '../components/ProviderExecutionModal';
import { VERIFIED_OCR_PROVIDERS } from '../lib/verifiedDirectProviders';
import { openTrackedLink } from '../lib/affiliate';
import { useTranslation } from '../lib/i18n';
import { UserProfile } from '../types';

interface ReceiptOcrViewProps {
  user: UserProfile;
  userCountry?: string;
  onEarnPoints: (points: number, label: string) => void;
  onBack: () => void;
}

export const ReceiptOcrView: React.FC<ReceiptOcrViewProps> = ({
  user,
  userCountry = 'IT',
  onEarnPoints,
  onBack,
}) => {
  const { t } = useTranslation();
  const [selectedProvider, setSelectedProvider] = useState<VerifiedProviderItem | null>(null);
  const [geoFilter, setGeoFilter] = useState<'IT_EU' | 'US_UK_CA'>(() =>
    ['US', 'UK', 'GB', 'CA'].includes(userCountry.toUpperCase()) ? 'US_UK_CA' : 'IT_EU'
  );

  const [imageUri, setImageUri] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [ocrResult, setOcrResult] = useState<{
    merchant: string;
    total: number;
    date: string;
    items: Array<{ name: string; price: number }>;
    category: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredOcrProviders = useMemo(() => {
    return VERIFIED_OCR_PROVIDERS.filter(
      (p) => p.geoRegion === 'GLOBAL' || p.geoRegion === geoFilter
    ).sort((a, b) => Number(Boolean(a.isLocked)) - Number(Boolean(b.isLocked)));
  }, [geoFilter]);

  const handleExecuteProvider = (provider: VerifiedProviderItem) => {
    openTrackedLink(provider.directUrl, {
      partnerId: provider.id,
      telegramId: user.telegramId,
    });
    if (!provider.isServiceOnly && provider.userPoints > 0) {
      onEarnPoints(provider.userPoints, `Scontrino GEO: ${provider.name}`);
    }
  };

  const handleImagePick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Invalid image');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Max 10MB');
      return;
    }
    const url = URL.createObjectURL(file);
    setImageUri(url);
    setError(null);
    setIsProcessing(true);
    setTimeout(() => {
      setOcrResult({
        merchant: 'OCR Verified Merchant',
        total: 32.4,
        date: new Date().toLocaleDateString(),
        items: [
          { name: 'Item 1', price: 14.9 },
          { name: 'Item 2', price: 17.5 },
        ],
        category: 'Store',
      });
      setIsProcessing(false);
    }, 1500);
  };

  const handleSubmitReceipt = () => {
    if (!ocrResult) return;
    // TODO: integrare OCR reale (Tabscanner/Veryfi) prima di erogare punti.
    // Fino ad allora la reward resta disabilitata per evitare frodi.
    setError('OCR in manutenzione: reward temporaneamente disabilitata');
    setImageUri(null);
    setOcrResult(null);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4 pb-12 animate-fade-in select-none">
      <CleanAdSlot page="receipts" placement="RECEIPTS_TOP" telegramUserId={user?.telegramId} />

      {/* HEADER CON FILTRO GEO OBBLIGATORIO */}
      <div className="rounded-2xl border border-sky-400/25 bg-[#071122]/90 p-4 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onBack}
              className="p-2.5 rounded-xl bg-[#0098EA] text-white hover:bg-cyan-400 hover:text-slate-950 border-0 cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0 shadow-md"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-400">
                <Globe className="w-4 h-4 text-emerald-300" />
                <span>🧾 {t.nav.ocr}</span>
              </div>
              <h2 className="text-base font-black text-white mt-0.5">
                {t.ui.ocrActiveApps} ({filteredOcrProviders.length})
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-[#040a14] p-1 rounded-xl border border-sky-400/25">
            <button
              type="button"
              onClick={() => setGeoFilter('IT_EU')}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-black uppercase transition-all cursor-pointer ${
                geoFilter === 'IT_EU'
                  ? 'bg-emerald-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🇪🇺 EU / IT
            </button>
            <button
              type="button"
              onClick={() => setGeoFilter('US_UK_CA')}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-black uppercase transition-all cursor-pointer ${
                geoFilter === 'US_UK_CA'
                  ? 'bg-amber-400 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🇺🇸 USA / UK / CA
            </button>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          {t.ui.ocrDesc}{' '}
          <strong className="text-amber-300">{t.ui.tapPhotoHint}</strong>
        </p>
      </div>

      {/* GRIGLIA FORNITORI SCONTRINI FILTRATI PER PAESE */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredOcrProviders.map((provider) => (
          <ProviderCardWithPhoto
            key={provider.id}
            provider={provider}
            onOpenInstructions={(p) => setSelectedProvider(p)}
            onExecuteDirect={handleExecuteProvider}
          />
        ))}
      </div>

      {/* SCANNER FOTOCAMERA DIRETTO IN-APP */}
      <div className="rounded-2xl bg-[#0D1326] border border-sky-400/20 p-4 shadow-lg space-y-3">
        <div className="text-xs font-mono font-black uppercase tracking-wider text-sky-300">
          {t.ui.ocrScannerTitle}
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
        />

        {!imageUri ? (
          <button
            type="button"
            onClick={handleImagePick}
            className="w-full py-5 rounded-xl border-2 border-dashed border-sky-400/35 bg-[#071020] hover:border-sky-400 text-white flex flex-col items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Camera className="w-7 h-7 text-sky-400" />
            <span className="text-xs font-black uppercase tracking-wider">
              {t.ui.ocrSnapOrUpload}
            </span>
          </button>
        ) : (
          <div className="space-y-3">
            <div className="relative rounded-xl overflow-hidden bg-slate-950 h-44">
              <img src={imageUri} alt="Receipt" className="w-full h-full object-contain" />
              <button
                type="button"
                onClick={() => {
                  setImageUri(null);
                  setOcrResult(null);
                }}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-red-600 text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isProcessing && (
              <div className="flex items-center justify-center gap-2 text-xs font-mono text-sky-300 py-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t.ui.ocrExtracting}</span>
              </div>
            )}

            {ocrResult && (
              <div className="flex items-center justify-between gap-3 bg-[#081528] p-3 rounded-xl border border-emerald-400/30">
                <div className="text-xs text-white">
                  <div className="font-black text-emerald-300">{ocrResult.merchant}</div>
                  <div className="text-slate-400">
                    {t.ui.ocrVerified} • {ocrResult.date}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleSubmitReceipt}
                  className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-mono text-xs font-black uppercase flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{t.ui.confirmBtn} (+30 PT)</span>
                </button>
              </div>
            )}
          </div>
        )}

        {error && (
          <div className="text-xs text-amber-300 flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* MODALE ISTRUZIONI INTERNE QUANDO CLICCHI LA FOTO */}
      <ProviderExecutionModal
        provider={selectedProvider}
        onClose={() => setSelectedProvider(null)}
        onExecute={handleExecuteProvider}
      />
    </div>
  );
};

export default ReceiptOcrView;
