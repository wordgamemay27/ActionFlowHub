// ============================================================================
// PROFILE VIEW — Profilo utente, statistiche, impostazioni
// ============================================================================

import React, { useState } from 'react';
import { ArrowLeft, Star, Shield, Key, ShieldCheck, ExternalLink, Copy, CheckCircle2, Send } from 'lucide-react';
import { CleanAdSlot } from '../components/CleanAdSlot';
import { UserProfile, Transaction } from '../types';
import { useTranslation } from '../lib/i18n';
import { EXTRA_UI_LOCALIZATION } from '../lib/providerLocalization';

interface ProfileViewProps {
  user: UserProfile;
  transactions: Transaction[];
  onOpenTonkeeperGuide: () => void;
  onNavigateHome: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  transactions,
  onNavigateHome,
}) => {
  const { t, lang } = useTranslation();
  const extra = EXTRA_UI_LOCALIZATION[lang] || EXTRA_UI_LOCALIZATION.en;
  const [, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const tierColors: Record<string, string> = {
    'TIER 1': 'text-emerald-400',
    'TIER 2': 'text-sky-400',
    'TIER 3': 'text-purple-400',
    'VIP ELITE': 'text-amber-400',
  };

  const stats = [
    { label: t.ui.availablePointsLabel, value: `${user.points.toLocaleString()} PT`, icon: Star, color: 'text-amber-400' },
    { label: t.ui.completedTasksLabel, value: user.completedTasksCount.toString(), icon: CheckCircle2, color: 'text-emerald-400' },
    { label: t.ui.withdrawThresholdLabel, value: '500 PT', icon: ShieldCheck, color: 'text-cyan-400' },
    { label: t.ui.accountStatusLabel, value: t.ui.regularStatus, icon: Shield, color: 'text-emerald-400' },
  ];

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4 pb-14 animate-fade-in select-none">
      {/* CLEAN AD SLOT */}
      <CleanAdSlot page="profile" placement="PROFILE_TOP" telegramUserId={user?.telegramId} />

      {/* HEADER */}
      <div className="flex items-center justify-between gap-3 px-1 py-1">
        <button
          type="button"
          onClick={onNavigateHome}
          className="p-2.5 rounded-xl bg-[#0098EA] text-white hover:bg-cyan-400 hover:text-slate-950 border-0 cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0 shadow-md"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 text-center">
          <h2 className="text-lg font-black text-white">{t.nav.profile}</h2>
          <p className="text-[11px] text-slate-400">ID: {user.telegramId}</p>
        </div>
        <div className="w-10" />
      </div>

      {/* PROFILO PRINCIPALE */}
      <div className="space-y-4">
        <div className="relative rounded-2xl bg-gradient-to-br from-[#0A1122] via-[#0E1830] to-[#0A1122] p-6 border-0 border-emerald-500/20 shadow-[0_0_24px_rgba(16,185,129,0.15)] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-emerald-500/5 to-transparent pointer-events-none" />
          
          <div className="relative z-10 flex items-center gap-4">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden shadow-[0_0_24px_rgba(16,185,129,0.4)] border-2 border-emerald-500/40">
              <div className="w-full h-full bg-gradient-to-br from-emerald-500/30 to-emerald-900/30 flex items-center justify-center">
                <span className="text-4xl sm:text-5xl font-black gold-diamond-royal-text">A</span>
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-emerald-500 border-2 border-[#05080f] flex items-center justify-center shadow-lg">
                <Star className="w-5 h-5 text-amber-300" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl sm:text-2xl font-black text-white truncate">{user.firstName} {user.lastName || ''}</h2>
              <p className="text-sm text-slate-300">@{user.username || `user_${user.telegramId}`}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`px-2 py-1 rounded-full text-xs font-black uppercase tracking-wider border-0 ${tierColors[user.tier] || 'text-sky-400'} bg-emerald-500/20`}>
                  {user.tier}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* STATISTICHE */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {stats.map((stat, idx) => {
            const IconComp = stat.icon;
            return (
              <div key={idx} className="rounded-2xl bg-[#0A1122] p-4 border border-sky-500/10 text-center">
                <div className="flex items-center justify-center gap-1.5 mb-1">
                  <span className={`${stat.color} text-xl`}>
                    <IconComp className="w-5 h-5" />
                  </span>
                  <span className="text-xs font-black uppercase tracking-wider text-slate-400">{stat.label}</span>
                </div>
                <div className="text-lg sm:text-xl font-black text-white tabular-nums">{stat.value}</div>
              </div>
            );
          })}
        </div>

        {/* IMPOSTAZIONI RAPIDE */}
        <div className="space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-sky-400 px-1">{t.ui.quickSettingsTitle}</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => copyToClipboard(user.telegramId.toString(), 'ID Telegram')}
              className="flex items-center gap-3 p-3 rounded-xl bg-[#0A1122] border border-sky-500/20 text-left active:scale-95 cursor-pointer"
            >
              <Key className="w-6 h-6 text-sky-400" />
              <div className="flex-1">
                <div className="text-sm font-black text-white">{t.ui.copyTelegramId}</div>
                <div className="text-[11px] text-sky-300/80">{user.telegramId}</div>
              </div>
              <Copy className="w-5 h-5 text-sky-400" />
            </button>
            <button
              type="button"
              onClick={() => copyToClipboard(user.walletAddress || '', 'Wallet')}
              className="flex items-center gap-3 p-3 rounded-xl bg-[#0A1122] border border-amber-500/20 text-left active:scale-95 cursor-pointer"
            >
              <Key className="w-6 h-6 text-amber-400" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-black text-white">{t.ui.walletAddressLabel}</div>
                <div className="text-[11px] text-amber-300/80 truncate">{user.walletAddress || t.ui.notSetLabel}</div>
              </div>
              <Copy className="w-5 h-5 text-amber-400" />
            </button>
          </div>

          {/* STATO REFERRAL */}
          <div className="rounded-2xl bg-gradient-to-r from-[#041816]/90 via-[#041816]/15 to-[#041816]/65 p-4 border border-emerald-500/20">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-black text-emerald-300">{t.ui.referralProgramTitle}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
                <div className="text-2xl font-black text-emerald-400">{(user as any).referralCount || 0}</div>
                <div className="text-[10px] font-mono text-emerald-300/80">{t.ui.totalReferrals}</div>
              </div>
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center">
                <div className="text-2xl font-black text-amber-300">{(user as any).referralEarnings || 0}</div>
                <div className="text-[10px] font-mono text-amber-300/80">{t.ui.referralEarnings}</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(`https://t.me/actionflow_bot?start=${(user as any).referralCode || user.telegramId}`, 'Link Referral')}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-mono text-xs font-black uppercase cursor-pointer active:scale-95 border-0 shadow-lg"
            >
              <ExternalLink className="w-4 h-4 mr-1 inline" />
              <span>{t.ui.copyReferralLinkBtn}</span>
            </button>
          </div>
        </div>

        {/* STORICO TRANSAZIONI */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-sky-400">{t.ui.recentTransactionsTitle}</h3>
          </div>
          {transactions.slice(0, 10).length > 0 ? (
            <div className="space-y-2">
              {transactions.slice(0, 10).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 rounded-xl bg-[#0A1122] border border-sky-500/10">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black ${
                      tx.type === 'TASK_CLAIM' ? 'bg-emerald-500/20 text-emerald-400' :
                      tx.type === 'WITHDRAWAL' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-sky-500/20 text-sky-400'
                    }`}>
                      {tx.type === 'TASK_CLAIM' && <Star className="w-4 h-4" />}
                      {tx.type === 'WITHDRAWAL' && <Send className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="text-sm font-black text-white">{tx.details || tx.type}</div>
                      <div className="text-[11px] text-slate-400">{new Date(tx.timestamp).toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-mono font-black ${tx.amountPoints > 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {tx.amountPoints > 0 ? '+' : ''}{tx.amountPoints} PT
                    </div>
                    <div className="text-[10px] text-sky-300/80 font-mono">
                      ≈ ${(Math.abs(tx.amountPoints) * 0.01).toFixed(2)} ({tx.amountTon.toFixed(4)} TON)
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 text-sm">
              {t.ui.noRecentTransactions}
            </div>
          )}
        </div>

        {/* PROTOCOLLO RIGIDO 3 STRIKE (UTENTI & FORNITORI) + ESONERO FISCALE */}
        <div className="rounded-2xl bg-[#060B14] border border-cyan-500/30 p-4 space-y-2.5 text-[11px] text-slate-300 leading-relaxed">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-cyan-300 font-black uppercase tracking-wider text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{extra.threeStrikeTitle}</span>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-400/40 text-[10px] font-mono font-black text-emerald-300">
              {extra.threeStrikeStatusRegular}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/35 p-2">
              <div className="text-xs font-black text-emerald-300">1 = OK</div>
              <div className="text-[10px] text-slate-300">{extra.strike1Desc}</div>
            </div>
            <div className="rounded-xl bg-amber-500/15 border border-amber-400/35 p-2">
              <div className="text-xs font-black text-amber-300">{extra.strike2Label}</div>
              <div className="text-[10px] text-slate-300">{extra.strike2Desc}</div>
            </div>
            <div className="rounded-xl bg-rose-500/20 border border-rose-400/45 p-2">
              <div className="text-xs font-black text-rose-300">{extra.strike3Label}</div>
              <div className="text-[10px] text-slate-300">{extra.strike3Desc}</div>
            </div>
          </div>
          <p className="text-slate-300 pt-1">{extra.pointsRedeemSummary}</p>
          <p className="text-[10px] text-slate-400">{extra.internationalDisclaimerText}</p>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;

