// ============================================================================
// ADMIN VIEW — Centro di Controllo Visivo, Interattivo & Autopilot
// ============================================================================

import React, { useState, useMemo } from 'react';
import { AdminSettings, Transaction, UserProfile } from '../types';
import {
  ShieldAlert,
  DollarSign,
  Activity,
  Settings,
  TrendingUp,
  CheckCircle2,
  Mail,
  ExternalLink,
  Home,
  Search,
  Lock,
  ShieldCheck,
} from 'lucide-react';
import { MAIL_COMPARTMENTS_REGISTRY } from '../lib/catalogMasterData';
import {
  MASTER_PROVIDER_GROUPS,
  ALL_VERIFIED_DIRECT_PROVIDERS,
  BANNED_PROVIDER_KEYWORDS,
} from '../lib/verifiedDirectProviders';

interface AdminViewProps {
  settings: AdminSettings;
  onUpdateSettings: (newSettings: AdminSettings) => void;
  currentUser: UserProfile;
  transactions: Transaction[];
  onApproveVerifiedTask?: (points: number, label: string, unlocksHalfStep?: boolean) => void;
  onUpdateTransactionStatus?: (id: string, status: 'APPROVED' | 'COMPLETED' | 'REJECTED', txHash?: string) => void;
  onNavigateHome?: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  settings,
  onUpdateSettings,
  transactions,
  onApproveVerifiedTask: _onApproveVerifiedTask,
  onUpdateTransactionStatus,
  onNavigateHome,
}) => {
  const [activeTab, setActiveTab] = useState<'registry' | 'mail_hub' | 'overview' | 'settings'>(
    'registry'
  );
  const [selectedGroup, setSelectedGroup] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const stats = useMemo(() => {
    const activeCount = ALL_VERIFIED_DIRECT_PROVIDERS.filter((p) => !p.isLocked).length;
    const lockedCount = ALL_VERIFIED_DIRECT_PROVIDERS.filter((p) => p.isLocked).length;
    const totalPoints = transactions
      .filter((t) => t.status === 'COMPLETED' && t.amountPoints > 0)
      .reduce((acc, curr) => acc + curr.amountPoints, 0);
    const totalWithdrawn = transactions
      .filter((t) => t.type === 'WITHDRAWAL' && t.status === 'COMPLETED')
      .reduce((acc, curr) => acc + curr.amountTon, 0);

    return {
      totalDirectProviders: ALL_VERIFIED_DIRECT_PROVIDERS.length,
      activeCount,
      lockedCount,
      totalPoints,
      totalWithdrawn: Number(totalWithdrawn.toFixed(4)),
    };
  }, [transactions]);

  const filteredProviders = useMemo(() => {
    const base =
      selectedGroup === 'ALL'
        ? ALL_VERIFIED_DIRECT_PROVIDERS
        : MASTER_PROVIDER_GROUPS.find((g) => g.groupKey === selectedGroup)?.items || [];

    if (!searchQuery.trim()) return base;
    const q = searchQuery.toLowerCase();
    return base.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.currencies.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q)
    );
  }, [selectedGroup, searchQuery]);

  return (
    <div className="space-y-3 pb-12 select-none">
      {/* HEADER BAR COMPATTA */}
      <div className="rounded-2xl bg-[#091224] p-3.5 border border-sky-400/25 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/35 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">
              Control Center • Autopilot
            </h2>
            <div className="flex items-center gap-2 text-[10px] font-mono text-emerald-300 mt-0.5">
              <span>{stats.activeCount} Attivi</span>
              <span>•</span>
              <span className="text-amber-300">{stats.lockedCount} Bloccati (PayPal)</span>
              <span>•</span>
              <span className="text-sky-300">{BANNED_PROVIDER_KEYWORDS.length} Nomi Banditi</span>
            </div>
          </div>
        </div>

        {onNavigateHome && (
          <button
            type="button"
            onClick={onNavigateHome}
            className="px-3 py-2 rounded-xl bg-sky-500 text-slate-950 font-mono text-xs font-black uppercase flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
        )}
      </div>

      {/* NAVIGAZIONE TAB INTERATTIVA */}
      <div className="grid grid-cols-4 gap-1.5 bg-[#070d19] p-1.5 rounded-2xl border border-sky-500/20">
        {[
          { id: 'registry' as const, label: `Fornitori (${stats.totalDirectProviders})`, icon: ShieldCheck },
          { id: 'mail_hub' as const, label: '5 Mail', icon: Mail },
          { id: 'overview' as const, label: 'Transazioni', icon: Activity },
          { id: 'settings' as const, label: 'Soglie', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-2 rounded-xl font-mono text-[10px] font-black uppercase flex items-center justify-center gap-1 transition-all cursor-pointer ${
                active
                  ? 'bg-sky-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: REGISTRO UNICO FORNITORI + STATO 3-STRIKE VISIVO */}
      {activeTab === 'registry' && (
        <div className="space-y-3">
          {/* BARRA STATO 3-STRIKE COMPATTA */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/40 p-2.5 text-center">
              <div className="text-xs font-black text-emerald-300">1 = OK</div>
              <div className="text-[10px] font-mono text-slate-300 mt-0.5">Haircut Automatico</div>
            </div>
            <div className="rounded-xl bg-amber-500/15 border border-amber-400/40 p-2.5 text-center">
              <div className="text-xs font-black text-amber-300">2 = WARNING</div>
              <div className="text-[10px] font-mono text-slate-300 mt-0.5">Avviso Automatico</div>
            </div>
            <div className="rounded-xl bg-rose-500/20 border border-rose-400/50 p-2.5 text-center">
              <div className="text-xs font-black text-rose-300">3 = BLOCCO</div>
              <div className="text-[10px] font-mono text-slate-300 mt-0.5">Quarantena + Failover</div>
            </div>
          </div>

          {/* FILTRI CATEGORIA E RICERCA ISTANTANEA */}
          <div className="rounded-2xl bg-[#091224] border border-sky-400/25 p-3 space-y-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setSelectedGroup('ALL')}
                className={`px-2.5 py-1.5 rounded-xl font-mono text-[10px] font-black uppercase shrink-0 cursor-pointer ${
                  selectedGroup === 'ALL'
                    ? 'bg-sky-400 text-slate-950'
                    : 'bg-[#050b16] border border-white/10 text-slate-300'
                }`}
              >
                Tutti ({stats.totalDirectProviders})
              </button>
              {MASTER_PROVIDER_GROUPS.map((g) => (
                <button
                  key={g.groupKey}
                  type="button"
                  onClick={() => setSelectedGroup(g.groupKey)}
                  className={`px-2.5 py-1.5 rounded-xl font-mono text-[10px] font-black uppercase shrink-0 cursor-pointer ${
                    selectedGroup === g.groupKey
                      ? 'bg-sky-400 text-slate-950'
                      : 'bg-[#050b16] border border-white/10 text-slate-300'
                  }`}
                >
                  {g.groupTitle} ({g.items.length})
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Verifica qualsiasi nome nel registro unico..."
                className="w-full rounded-xl bg-[#050b16] border border-sky-400/25 pl-9 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-400"
              />
            </div>

            {/* ELENCO NUMERATO DI TUTTI I FORNITORI ATTIVI E BLOCCATI */}
            <div className="space-y-1.5 max-h-96 overflow-y-auto pr-1">
              {filteredProviders.map((p, idx) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-[#050b16] border border-white/10 text-xs"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-6 h-6 rounded-lg bg-sky-500/15 border border-sky-400/30 font-mono text-[10px] font-black text-sky-300 flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="font-bold text-white truncate">{p.name}</div>
                      <div className="text-[10px] font-mono text-slate-400 truncate">
                        {p.currencies} • {p.payoutInfo}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {p.isLocked ? (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-400/40 font-mono text-[10px] font-black text-amber-300 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>BLOCCATO</span>
                      </span>
                    ) : p.isServiceOnly ? (
                      <span className="px-2 py-0.5 rounded-md bg-sky-500/20 border border-sky-400/40 font-mono text-[10px] font-black text-sky-300">
                        SERVIZIO DIRETTO
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-400/40 font-mono text-[10px] font-black text-emerald-300 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>+{p.userPoints >= 100 ? Math.round(p.userPoints / 10) : p.userPoints} PT</span>
                      </span>
                    )}
                    <a
                      href={p.directUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-sky-500/20 text-sky-300"
                      title="Apri URL Fornitore"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 5 CASELLE MAIL COMPARTIMENTATE */}
      {activeTab === 'mail_hub' && (
        <div className="grid grid-cols-1 gap-2">
          {MAIL_COMPARTMENTS_REGISTRY.map((mail) => (
            <div
              key={mail.id}
              className="rounded-2xl bg-[#090F1E] border border-indigo-500/30 p-3 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center font-mono text-xs font-black text-indigo-300 shrink-0">
                  #{mail.compartmentNumber}
                </span>
                <div className="min-w-0">
                  <div className="text-sm font-black text-white">{mail.domain}</div>
                  <div className="text-[11px] text-slate-300 truncate">{mail.scope}</div>
                </div>
              </div>
              <a
                href={mail.portalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-indigo-600/30 border border-indigo-400/40 text-xs font-bold text-indigo-200 flex items-center gap-1.5 shrink-0"
              >
                <span>Apri</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: PANORAMICA & LOG TRANSAZIONI REALI */}
      {activeTab === 'overview' && (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-2xl bg-[#091324] border border-sky-400/25 p-3 text-center">
              <Activity className="w-4 h-4 text-sky-400 mx-auto mb-1" />
              <div className="text-lg font-black text-white">{stats.totalDirectProviders}</div>
              <div className="text-[10px] font-mono uppercase text-slate-400">Fornitori</div>
            </div>
            <div className="rounded-2xl bg-[#091324] border border-emerald-400/25 p-3 text-center">
              <TrendingUp className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
              <div className="text-lg font-black text-emerald-300">{stats.totalPoints} PT</div>
              <div className="text-[10px] font-mono uppercase text-slate-400">Punti</div>
            </div>
            <div className="rounded-2xl bg-[#091324] border border-amber-400/25 p-3 text-center">
              <DollarSign className="w-4 h-4 text-amber-400 mx-auto mb-1" />
              <div className="text-lg font-black text-amber-300">{stats.totalWithdrawn} TON</div>
              <div className="text-[10px] font-mono uppercase text-slate-400">Prelevati</div>
            </div>
          </div>

          <div className="rounded-2xl bg-[#0A1122] border border-sky-500/20 p-3.5 space-y-2">
            <h3 className="text-xs font-mono font-black uppercase tracking-wider text-sky-300">
              Transazioni ({transactions.length})
            </h3>
            {transactions.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">
                Nessuna transazione in questa sessione.
              </p>
            ) : (
              <div className="space-y-1.5 max-h-72 overflow-y-auto">
                {transactions.slice(0, 30).map((tx) => (
                  <div
                    key={tx.id}
                    className="p-2 rounded-xl bg-[#060c18] border border-white/10 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-bold text-white truncate">{tx.details || `${tx.type} (${tx.amountPoints} PT)`}</div>
                        <div className="text-[10px] font-mono text-slate-400">
                          {new Date(tx.timestamp).toLocaleString('it-IT')}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                            tx.status === 'COMPLETED'
                              ? 'text-teal-300 bg-teal-500/20 border border-teal-500/30'
                              : tx.status === 'APPROVED'
                              ? 'text-sky-300 bg-sky-500/20 border border-sky-500/30'
                              : tx.status === 'FAILED' || tx.status === 'CANCELLED'
                              ? 'text-rose-300 bg-rose-500/20 border border-rose-500/30'
                              : 'text-amber-300 bg-amber-500/20 border border-amber-500/30'
                          }`}
                        >
                          {tx.status}
                        </span>
                        <span className="font-mono font-black text-emerald-300">
                          {tx.amountPoints > 0 ? `+${tx.amountPoints} PT` : `${tx.amountPoints} PT`}
                        </span>
                      </div>
                    </div>

                    {tx.type === 'WITHDRAWAL' && (tx.status === 'PENDING' || tx.status === 'APPROVED') && onUpdateTransactionStatus && (
                      <div className="pt-1 flex items-center gap-1.5 border-t border-white/5">
                        {tx.status === 'PENDING' && (
                          <button
                            type="button"
                            onClick={() => onUpdateTransactionStatus(tx.id, 'APPROVED')}
                            className="px-2 py-0.5 rounded bg-sky-600/30 hover:bg-sky-600/50 border border-sky-400/40 text-[10px] font-bold text-sky-200"
                          >
                            Approva
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            const hash = `tx_onchain_${Date.now()}`;
                            onUpdateTransactionStatus(tx.id, 'COMPLETED', hash);
                          }}
                          className="px-2 py-0.5 rounded bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-400/40 text-[10px] font-bold text-emerald-200"
                        >
                          Salda & Completa
                        </button>
                        <button
                          type="button"
                          onClick={() => onUpdateTransactionStatus(tx.id, 'REJECTED')}
                          className="px-2 py-0.5 rounded bg-rose-600/30 hover:bg-rose-600/50 border border-rose-400/40 text-[10px] font-bold text-rose-200"
                        >
                          Rifiuta & Rimborsa
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: IMPOSTAZIONI SOGLIE PRELIEVO */}
      {activeTab === 'settings' && (
        <div className="rounded-2xl bg-[#0A1122] p-4 border border-sky-500/20 space-y-3">
          {[
            {
              key: 'minWithdrawalPoints' as const,
              label: 'Minimo Punti Prelievo',
              value: settings.minWithdrawalPoints,
            },
            {
              key: 'minWithdrawalTon' as const,
              label: 'Minimo TON Prelievo',
              value: settings.minWithdrawalTon,
            },
            {
              key: 'minWithdrawalUsdt' as const,
              label: 'Minimo USDT Prelievo',
              value: settings.minWithdrawalUsdt,
            },
            {
              key: 'dailyWithdrawalLimitPoints' as const,
              label: 'Limite Giornaliero Punti',
              value: settings.dailyWithdrawalLimitPoints,
            },
          ].map((s) => (
            <div key={s.key} className="flex items-center justify-between gap-3">
              <label className="text-xs font-bold text-slate-200">{s.label}</label>
              <input
                type="number"
                value={s.value}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    [s.key]: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-32 px-3 py-1.5 rounded-xl bg-[#050b16] border border-sky-500/30 text-white text-xs font-mono focus:outline-none focus:border-sky-400"
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminView;
