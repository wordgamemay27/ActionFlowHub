// ============================================================================
// PERSISTENT STORAGE — Persistenza permanente locale e PostgreSQL
// Garantisce la resilienza a riavvii del server, crash o disconnessioni
// ============================================================================

import fs from 'fs';
import path from 'path';

export interface StoredSession {
  sessionId: string;
  telegramUserId: number;
  startedAtMs: number;
  sessionMinutes: number;
  blockNumber: number;
  dateKey: string;
  timeZone: string;
  completed: boolean;
  completedResult?: {
    creditedBlock: number;
    creditedPoints: number;
    completedBlocksToday: number;
    nextRewardPoints: number;
    totalPoints: number;
  };
}

export interface StoredUserDailyState {
  lastResetDate: string;
  timeZone: string;
  completedBlocksToday: number;
  totalPoints: number;
}

export interface StoredPayoutRequest {
  requestId: string;
  userId: string;
  points: number;
  amountUsd: number;
  amountTon: number;
  cryptoAsset: string;
  walletAddress: string;
  status: 'PENDING' | 'APPROVED' | 'COMPLETED' | 'REJECTED';
  payoutStatus: string;
  txHash?: string;
  note?: string;
  createdAt: number;
  updatedAt: number;
}

export interface StoredWebhookConversion {
  txId: string;
  provider: string;
  userId: string;
  payoutUsd: number;
  pointsCredited: number;
  timestamp: number;
}

export interface StoredUserStrike {
  telegramUserId: number;
  strikes: 0 | 1 | 2 | 3;
  verdict: string;
  blockedForVerification: boolean;
  lastAnomalyReason: string | null;
  updatedAt: string;
}

interface StorageData {
  sessions: Record<string, StoredSession>;
  userDailyState: Record<string, StoredUserDailyState>;
  userStrikes: Record<string, StoredUserStrike>;
  payoutRequests: Record<string, StoredPayoutRequest>;
  webhookConversions: Record<string, StoredWebhookConversion>;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'persistent_ledger_state.json');

class PersistentStorageManager {
  private data: StorageData = {
    sessions: {},
    userDailyState: {},
    userStrikes: {},
    payoutRequests: {},
    webhookConversions: {},
  };
  private isLoaded = false;

  constructor() {
    this.ensureLoaded();
  }

  private ensureLoaded(): void {
    if (this.isLoaded) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.data = {
          sessions: parsed.sessions || {},
          userDailyState: parsed.userDailyState || {},
          userStrikes: parsed.userStrikes || {},
          payoutRequests: parsed.payoutRequests || {},
          webhookConversions: parsed.webhookConversions || {},
        };
      }
      this.isLoaded = true;
    } catch (err: any) {
      console.warn('[PERSISTENCE] Inizializzazione fallback:', err.message);
      this.isLoaded = true;
    }
  }

  private save(): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err: any) {
      console.error('[PERSISTENCE ERROR] Impossibile salvare su disco:', err.message);
    }
  }

  // --- SESSIONI ---
  getSession(sessionId: string): StoredSession | undefined {
    this.ensureLoaded();
    return this.data.sessions[sessionId];
  }

  getActiveSessionForUser(telegramUserId: number, maxAgeSeconds = 1800): StoredSession | undefined {
    this.ensureLoaded();
    const now = Date.now();
    for (const s of Object.values(this.data.sessions)) {
      if (s.telegramUserId === telegramUserId && !s.completed) {
        const ageSec = (now - s.startedAtMs) / 1000;
        if (ageSec <= maxAgeSeconds) {
          return s;
        }
      }
    }
    return undefined;
  }

  saveSession(session: StoredSession): void {
    this.ensureLoaded();
    this.data.sessions[session.sessionId] = session;
    this.save();
  }

  getAllSessions(): StoredSession[] {
    this.ensureLoaded();
    return Object.values(this.data.sessions);
  }

  // --- STATO GIORNALIERO UTENTI ---
  getUserDailyState(uid: number): StoredUserDailyState | undefined {
    this.ensureLoaded();
    return this.data.userDailyState[String(uid)];
  }

  saveUserDailyState(uid: number, state: StoredUserDailyState): void {
    this.ensureLoaded();
    this.data.userDailyState[String(uid)] = state;
    this.save();
  }

  // --- STRIKE ANTIFRODE ---
  getUserStrike(uid: number): StoredUserStrike | undefined {
    this.ensureLoaded();
    return this.data.userStrikes[String(uid)];
  }

  saveUserStrike(uid: number, strike: StoredUserStrike): void {
    this.ensureLoaded();
    this.data.userStrikes[String(uid)] = strike;
    this.save();
  }

  // --- PRELIEVI ---
  savePayoutRequest(payout: StoredPayoutRequest): void {
    this.ensureLoaded();
    this.data.payoutRequests[payout.requestId] = payout;
    this.save();
  }

  getPayoutRequest(requestId: string): StoredPayoutRequest | undefined {
    this.ensureLoaded();
    return this.data.payoutRequests[requestId];
  }

  getAllPayoutRequests(): StoredPayoutRequest[] {
    this.ensureLoaded();
    return Object.values(this.data.payoutRequests).sort((a, b) => b.createdAt - a.createdAt);
  }

  // --- WEBHOOK CONVERSIONI S2S ---
  isWebhookProcessed(txId: string): boolean {
    this.ensureLoaded();
    return Boolean(this.data.webhookConversions[txId]);
  }

  saveWebhookConversion(conversion: StoredWebhookConversion): void {
    this.ensureLoaded();
    this.data.webhookConversions[conversion.txId] = conversion;
    this.save();
  }

  getAllWebhookConversions(): StoredWebhookConversion[] {
    this.ensureLoaded();
    return Object.values(this.data.webhookConversions).sort((a, b) => b.timestamp - a.timestamp);
  }
}

export const persistentStorage = new PersistentStorageManager();
