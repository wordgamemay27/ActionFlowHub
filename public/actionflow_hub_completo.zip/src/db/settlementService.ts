import { dbPool, LedgerService } from './ledgerService';
import { ProviderReputationService } from '../services/providerReputation';

export interface BatchSettlementParams {
  batchId: string;
  partnerId: string;
  periodStart: number;
  periodEnd: number;
  expectedGrossUsd: number;
  actualNetReceivedUsd: number;
  haircutRatio?: number;
  onchainTxHash: string;
}

export interface BatchSettlementResult {
  success: boolean;
  batchId: string;
  partnerId: string;
  haircutRatio: number;
  settledUsersCount: number;
  totalPointsSettled: number;
  providerReputationStatus?: string;
  error?: string;
}

export class SettlementService {
  static async executeBatchSettlement(params: BatchSettlementParams): Promise<BatchSettlementResult> {
    const expected = Math.max(0, Number(params.expectedGrossUsd) || 0);
    const actual = Math.max(0, Number(params.actualNetReceivedUsd) || 0);
    const computedRatio =
      typeof params.haircutRatio === 'number' && params.haircutRatio > 0
        ? params.haircutRatio
        : expected > 0
        ? Number((actual / expected).toFixed(4))
        : 1.0;

    try {
      const repResult = await ProviderReputationService.recordPayment({
        providerId: params.partnerId,
        batchId: params.batchId,
        promisedUsd: expected,
        paidUsd: actual,
        txHash: params.onchainTxHash,
        notes: `Batch settlement period ${params.periodStart}-${params.periodEnd}`,
      });

      if (dbPool) {
        const client = await dbPool.connect();
        try {
          await client.query('BEGIN');
          const sqlRes = await client.query(
            'SELECT core.execute_batch_settlement($1, $2, $3, $4, $5, $6, $7, $8) AS result',
            [
              params.batchId,
              params.partnerId,
              params.periodStart,
              params.periodEnd,
              expected,
              actual,
              computedRatio,
              params.onchainTxHash,
            ]
          );
          await client.query('COMMIT');
          const row = sqlRes.rows[0]?.result || {};
          return {
            success: row.success !== false,
            batchId: params.batchId,
            partnerId: params.partnerId,
            haircutRatio: computedRatio,
            settledUsersCount: Number(row.settled_users_count) || 0,
            totalPointsSettled: Number(row.total_points_settled) || 0,
            providerReputationStatus: repResult.status,
          };
        } catch (dbErr: any) {
          await client.query('ROLLBACK');
          console.error('[SETTLEMENT SERVICE] SQL batch error:', dbErr.message);
        } finally {
          client.release();
        }
      }

      // Fallback in-memory treasury capacity credit (100 PT = $1.00)
      const pointsCapacity = Math.round(actual * 100);
      LedgerService.creditVaultCapacity('USDT', actual, pointsCapacity);

      return {
        success: true,
        batchId: params.batchId,
        partnerId: params.partnerId,
        haircutRatio: computedRatio,
        settledUsersCount: 1,
        totalPointsSettled: pointsCapacity,
        providerReputationStatus: repResult.status,
      };
    } catch (err: any) {
      return {
        success: false,
        batchId: params.batchId,
        partnerId: params.partnerId,
        haircutRatio: computedRatio,
        settledUsersCount: 0,
        totalPointsSettled: 0,
        error: err.message || 'SETTLEMENT_ERROR',
      };
    }
  }
}
