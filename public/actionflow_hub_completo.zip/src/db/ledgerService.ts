// ============================================================================
// LEDGER SERVICE — Contabilità a 4 Bucket (Pending, Settled, Withdrawable, Reserved)
// ============================================================================
// Double-entry con zero-sum constraint, idempotenza, fail-closed in produzione,
// fallback in-memory per sviluppo. Timer 10-min usa orologio SERVER.
// Reset giornaliero per fuso orario utente (atomico, anti-cambio-fuso).
// ============================================================================

import pg from 'pg';
import fs from 'fs';
import path from 'path';
import {
  localDateKey,
  normalizeTimeZone,
  resolveSessionMinutes,
  rewardForBlock,
  shouldResetDaily,
} from '../lib/entryProfile';

const { Pool } = pg;

export interface UserBalances {
  pending_points: number;
  settled_points: number;
  withdrawable_points: number;
  reserved_points: number;
}

export interface UserLedgerProfile {
  user_id: string;
  username: string;
  tier_zone: 'ZONE_A' | 'ZONE_B' | 'ZONE_C';
  ppp_multiplier: number;
  current_block: number;
  last_claim_time: number;
  /** Fuso orario IANA dell'utente: governa il confine del reset giornaliero. */
  timezone: string;
  /** Ultimo giorno locale (YYYY-MM-DD) in cui e' stato applicato il reset. */
  last_reset_date: string | null;
  balances: UserBalances;
}

const isProduction = process.env.NODE_ENV === 'production';
const databaseUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL || '';

// In produzione, se manca DATABASE_URL, fail-closed: il sistema NON opera in memoria volatile
if (isProduction && !databaseUrl) {
  console.error('[CRITICAL SECURITY WARNING] DATABASE_URL assente in ambiente production! Il backend opera in modalita FAIL-CLOSED per prevenire discrepanze finanziarie.');
}

export const dbPool = databaseUrl
  ? new Pool({
      connectionString: databaseUrl,
      ssl: isProduction ? { rejectUnauthorized: false } : false,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    })
  : null;

/**
 * Esegue automaticamente la migrazione DDL iniziale su PostgreSQL se connesso.
 * Applica TUTTE le migrazioni presenti nella cartella, in ordine alfabetico:
 * ogni file e' idempotente, quindi un riavvio non duplica nulla.
 */
export async function bootstrapDatabaseSchema(): Promise<boolean> {
  if (!dbPool) return false;
  try {
    const migrationsDir = path.join(process.cwd(), 'migrations');
    if (!fs.existsSync(migrationsDir)) return false;

    const files = fs
      .readdirSync(migrationsDir)
      .filter((f) => f.toLowerCase().endsWith('.sql'))
      .sort();

    const client = await dbPool.connect();
    try {
      for (const file of files) {
        const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
        await client.query(sql);
        console.log(`[POSTGRES MIGRATION OK] ${file} applicata con successo.`);
      }
      return true;
    } finally {
      client.release();
    }
  } catch (err: any) {
    console.error('[POSTGRES MIGRATION ERROR]', err.message);
  }
  return false;
}

// Avvia bootstrap al caricamento del modulo se dbPool è configurato
if (dbPool) {
  bootstrapDatabaseSchema().catch(() => {});
}

// Fallback in-memory USABILE ESCLUSIVAMENTE in development/testing locale
const inMemoryUsers = new Map<string, UserLedgerProfile>();
const inMemoryIdempotency = new Map<string, { status: string; payload: any; timestamp: number }>();

// Tesoreria in-memory separata per asset (solo mock dev)
const inMemoryVault: Record<'TON' | 'USDT', { actualCash: number; pointsCapacity: number; reservedBuffer: number }> = {
  TON: { actualCash: 100.0, pointsCapacity: 100_000, reservedBuffer: 0.15 },
  USDT: { actualCash: 500.0, pointsCapacity: 500_000, reservedBuffer: 0.15 },
};

export class LedgerService {
  /**
   * Incrementa la capienza del vault in-memory quando viene riconciliato un incasso
   */
  static creditVaultCapacity(asset: 'TON' | 'USDT', cashAmount: number, pointsCapacity: number): void {
    if (inMemoryVault[asset]) {
      inMemoryVault[asset].actualCash += cashAmount;
      inMemoryVault[asset].pointsCapacity += pointsCapacity;
    }
  }

  /**
   * Restituisce lo stato corrente della tesoreria per l'asset specificato
   */
  static getVaultStatus(asset: 'TON' | 'USDT') {
    return inMemoryVault[asset];
  }

  /**
   * Assicura l'esistenza del profilo e dei 4 bucket contabili.
   * Se il fuso orario cambia, riancora last_reset_date al giorno locale del nuovo fuso
   * (cambiare fuso non concede bonus extra).
   */
  static async getOrCreateUser(
    userId: string,
    username: string = 'User',
    tierZone: 'ZONE_A' | 'ZONE_B' | 'ZONE_C' = 'ZONE_C',
    pppMultiplier: number = 0.2,
    timezone?: string
  ): Promise<UserLedgerProfile> {
    const uid = String(userId).trim();
    const requestedTz = timezone ? normalizeTimeZone(timezone) : null;

    if (dbPool) {
      const client = await dbPool.connect();
      try {
        await client.query('BEGIN');
        await client.query(
          'SELECT core.ensure_user_accounts($1, $2, $3, $4, $5)',
          [
            uid,
            username,
            tierZone,
            pppMultiplier,
            requestedTz, // NULL = mantieni il fuso memorizzato
          ]
        );

        const userRes = await client.query('SELECT * FROM core.users WHERE user_id = $1', [uid]);
        const balRes = await client.query(
          `SELECT account_id, balance FROM core.balances 
           WHERE account_id IN (
             'USER_' || $1 || ':PENDING',
             'USER_' || $1 || ':SETTLED',
             'USER_' || $1 || ':WITHDRAWABLE',
             'USER_' || $1 || ':RESERVED'
           )`,
          [uid]
        );
        await client.query('COMMIT');

        const u = userRes.rows[0];
        const balMap = new Map<string, number>();
        balRes.rows.forEach((r: any) => balMap.set(r.account_id, Number(r.balance) || 0));

        return {
          user_id: uid,
          username: u?.username || username,
          tier_zone: u?.tier_zone || tierZone,
          ppp_multiplier: Number(u?.ppp_multiplier) || pppMultiplier,
          current_block: Number(u?.current_block) || 1,
          last_claim_time: Number(u?.last_claim_time) || 0,
          timezone: u?.timezone || 'UTC',
          last_reset_date: u?.last_reset_date ? String(u.last_reset_date).slice(0, 10) : null,
          balances: {
            pending_points: balMap.get(`USER_${uid}:PENDING`) || 0,
            settled_points: balMap.get(`USER_${uid}:SETTLED`) || 0,
            withdrawable_points: balMap.get(`USER_${uid}:WITHDRAWABLE`) || 0,
            reserved_points: balMap.get(`USER_${uid}:RESERVED`) || 0,
          },
        };
      } catch (err) {
        await client.query('ROLLBACK');
        console.error('[LEDGER SERVICE] Errore DB getOrCreateUser:', err);
        if (isProduction) {
          throw new Error('DATABASE_CONNECTION_ERROR_PRODUCTION');
        }
      } finally {
        client.release();
      }
    }

    if (isProduction) {
      throw new Error('FAIL_CLOSED_NO_DATABASE_CONFIGURED_IN_PROD');
    }

    // Fallback locale memory (Consentito solo in DEV)
    let local = inMemoryUsers.get(uid);
    if (!local) {
      local = {
        user_id: uid,
        username,
        tier_zone: tierZone,
        ppp_multiplier: pppMultiplier,
        current_block: 1,
        last_claim_time: 0,
        timezone: requestedTz || 'UTC',
        last_reset_date: null,
        balances: {
          pending_points: 0,
          settled_points: 0,
          withdrawable_points: 0,
          reserved_points: 0,
        },
      };
      inMemoryUsers.set(uid, local);
    } else if (requestedTz && requestedTz !== local.timezone) {
      local.timezone = requestedTz;
      local.last_reset_date = localDateKey(Date.now(), requestedTz);
    }
    return local;
  }

  /**
   * Salva il profilo d'ingresso (lingua, mercato, categorie, durata, fuso).
   */
  static async upsertEntryProfile(
    userId: string,
    profile: {
      timezone?: string;
      language?: string;
      marketCountry?: string;
      sessionMinutes?: number;
      selectedCategories?: string[];
    }
  ): Promise<{ success: boolean; timezone?: string }> {
    const uid = String(userId).trim();
    const tz = normalizeTimeZone(profile.timezone);
    const language = (profile.language || 'it').slice(0, 5);
    const marketCountry = (profile.marketCountry || 'OTHER').toUpperCase().slice(0, 8);
    const sessionMinutes = resolveSessionMinutes(profile.sessionMinutes ?? 20);
    const categories = (profile.selectedCategories || []).slice(0, 20);

    if (dbPool) {
      const client = await dbPool.connect();
      try {
        await client.query('BEGIN');
        const res = await client.query(
          'SELECT core.upsert_entry_profile($1, $2, $3, $4, $5, $6) as result',
          [uid, tz, language, marketCountry, sessionMinutes, categories]
        );
        await client.query('COMMIT');
        return res.rows[0]?.result || { success: true, timezone: tz };
      } catch (err: any) {
        await client.query('ROLLBACK');
        console.error('[LEDGER SERVICE] Errore upsertEntryProfile:', err.message);
        return { success: false };
      } finally {
        client.release();
      }
    }

    await this.getOrCreateUser(uid, 'User', 'ZONE_C', 0.2, tz);
    return { success: true, timezone: tz };
  }

  /**
   * Avvia la sessione di lavoro lato server
   */
  static async startSession(
    userId: string,
    sessionMinutes?: number,
    nowMs: number = Date.now()
  ): Promise<{ success: boolean; session_minutes?: number; session_started_at?: number; session_ends_at?: number }> {
    const uid = String(userId).trim();
    const minutes = resolveSessionMinutes(sessionMinutes ?? 20);

    if (dbPool) {
      const client = await dbPool.connect();
      try {
        await client.query('BEGIN');
        const res = await client.query(
          'SELECT core.start_session($1, $2, $3) as result',
          [uid, minutes, nowMs]
        );
        await client.query('COMMIT');
        return res.rows[0]?.result || { success: true, session_minutes: minutes };
      } catch (err: any) {
        await client.query('ROLLBACK');
        console.error('[LEDGER SERVICE] Errore startSession:', err.message);
        return { success: false, session_minutes: minutes };
      } finally {
        client.release();
      }
    }

    return {
      success: true,
      session_minutes: minutes,
      session_started_at: nowMs,
      session_ends_at: nowMs + minutes * 60000,
    };
  }

  /**
   * Riscatta il blocco dei 10 minuti accreditando SOLO punti PENDING.
   */
  static async claimBlock(
    userId: string,
    idempotencyKey: string,
    partnerId: string = 'internal_relay',
    clientNowMs: number = Date.now(),
    options?: { nowMs?: number; timezone?: string }
  ): Promise<{ success: boolean; error?: string; remaining_seconds?: number; added_pending_points?: number; next_block?: number; reset_applied?: boolean; profile?: UserLedgerProfile }> {
    const uid = String(userId).trim();
    const nowMs = options?.nowMs ?? Date.now();

    if (dbPool) {
      const client = await dbPool.connect();
      try {
        await client.query('BEGIN');
        const res = await client.query(
          'SELECT core.claim_block_atomic($1, $2, $3, $4, $5, $6) as result',
          [
            uid,
            idempotencyKey,
            partnerId,
            clientNowMs,
            options?.timezone || null,
            options?.nowMs || null,
          ]
        );
        await client.query('COMMIT');
        return res.rows[0]?.result;
      } catch (err: any) {
        await client.query('ROLLBACK');
        console.error('[LEDGER SERVICE] Errore claimBlock SQL:', err);
        return { success: false, error: 'DB_ERROR' };
      } finally {
        client.release();
      }
    }

    if (isProduction) {
      return { success: false, error: 'FAIL_CLOSED_NO_DATABASE_IN_PRODUCTION' };
    }

    // Memory Fallback DEV
    const user = await this.getOrCreateUser(uid, 'User', 'ZONE_C', 0.2, options?.timezone);
    const tenMinMs = 600000;

    if (user.last_claim_time > 0 && nowMs - user.last_claim_time < tenMinMs) {
      const remainingSeconds = Math.ceil((tenMinMs - (nowMs - user.last_claim_time)) / 1000);
      inMemoryIdempotency.set(idempotencyKey, { status: 'FAILED', payload: null, timestamp: Date.now() });
      return { success: false, error: 'BLOCK_NOT_EXPIRED', remaining_seconds: remainingSeconds };
    }

    const tz = normalizeTimeZone(user.timezone);
    const todayKey = localDateKey(nowMs, tz);
    let block = user.current_block;
    let resetApplied = false;
    if (shouldResetDaily(user.last_reset_date, todayKey)) {
      block = 1;
      user.current_block = 1;
      user.last_reset_date = todayKey;
      resetApplied = true;
    }

    const points = rewardForBlock(block);

    user.balances.pending_points += points;
    user.last_claim_time = nowMs;
    user.current_block = Math.min(4, block + 1);

    const result = {
      success: true,
      added_pending_points: points,
      next_block: user.current_block,
      reset_applied: resetApplied,
      profile: user,
    };
    inMemoryIdempotency.set(idempotencyKey, { status: 'COMPLETED', payload: result, timestamp: Date.now() });
    return result;
  }

  /**
   * Scala i punti dal ledger quando un payout viene APPROVATO.
   * Sposta withdrawable_points -> reserved_points (in attesa di erogazione).
   */
  static async reservePayout(userId: string, points: number): Promise<{ ok: boolean; error?: string }> {
    const uid = String(userId).trim();
    const pts = Math.floor(Number(points));
    if (!uid || !Number.isFinite(pts) || pts <= 0) {
      return { ok: false, error: 'INVALID_INPUT' };
    }

    if (dbPool) {
      const client = await dbPool.connect();
      try {
        await client.query('BEGIN');
        const userRes = await client.query(
          `SELECT balance FROM core.balances WHERE account_id = 'USER_' || $1 || ':WITHDRAWABLE' FOR UPDATE`,
          [uid]
        );
        const current = Number(userRes.rows[0]?.balance || 0);
        if (current < pts) {
          await client.query('ROLLBACK');
          return { ok: false, error: 'INSUFFICIENT_WITHDRAWABLE' };
        }
        await client.query(
          `UPDATE core.balances SET balance = balance - $2, updated_at = NOW() WHERE account_id = 'USER_' || $1 || ':WITHDRAWABLE'`,
          [uid, pts]
        );
        await client.query(
          `UPDATE core.balances SET balance = balance + $2, updated_at = NOW() WHERE account_id = 'USER_' || $1 || ':RESERVED'`,
          [uid, pts]
        );
        await client.query('COMMIT');
        return { ok: true };
      } catch (err: any) {
        await client.query('ROLLBACK');
        return { ok: false, error: err.message };
      } finally {
        client.release();
      }
    }

    return { ok: true };
  }
}
