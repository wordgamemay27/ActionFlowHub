// ============================================================================
// ACTIONFLOW HUB — FULL-STACK EXPRESS SERVER
// ============================================================================

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import {
  resolveSessionMinutes,
  rewardForBlock,
  localDateKey,
  shouldResetDaily,
  normalizeTimeZone,
} from './lib/entryProfile';
import { LedgerService, dbPool } from './db/ledgerService';
import { SettlementService } from './db/settlementService';
import providerAdminRouter from './routes/providerAdmin';
import { WALLET_CONFIG } from './config/wallets';
import { workers } from './workers';
import { persistentStorage, StoredPayoutRequest } from './db/persistentStorage';

interface ServerSessionRecord {
  sessionId: string;
  telegramUserId: number;
  startedAtMs: number;
  sessionMinutes: number;
  blockNumber: number;
  dateKey: string;
  timeZone: string;
  completed: boolean;
  completedResult?: {
    creditedBlock: number;
    creditedPoints: number;
    completedBlocksToday: number;
    nextRewardPoints: number;
    totalPoints: number;
  };
}

const userDailyState = new Map<
  number,
  { lastResetDate: string; timeZone: string; completedBlocksToday: number; totalPoints: number }
>();
const activeSessions = new Map<string, ServerSessionRecord>();

// Idratazione iniziale da memoria persistente su disco
for (const s of persistentStorage.getAllSessions()) {
  activeSessions.set(s.sessionId, s);
}

export type StrikeVerdict = '0_REGOLARE' | '1_OK_TOLLERATO' | '2_NON_BENE_WARNING' | '3_VERIFICA_E_BLOCCO';

export interface UserStrikeRecord {
  telegramUserId: number;
  strikes: 0 | 1 | 2 | 3;
  verdict: StrikeVerdict;
  blockedForVerification: boolean;
  lastAnomalyReason: string | null;
  updatedAt: string;
}

const userStrikes = new Map<number, UserStrikeRecord>();

/**
 * Validazione Crittografica Telegram WebApp (HMAC-SHA256).
 * - In Produzione (o quando TELEGRAM_BOT_TOKEN è impostato): la firma initData è obbligatoria e verificata.
 * - In Sviluppo/Anteprima Locale: se botToken non è configurato, consente l'accesso demo protetto.
 */
export function verifyTelegramWebAppData(rawInitData: string | undefined): {
  valid: boolean;
  isPreview: boolean;
  userData?: any;
} {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd || botToken) {
    if (!botToken || !rawInitData) {
      return { valid: false, isPreview: false };
    }
  } else {
    if (!rawInitData) {
      return { valid: true, isPreview: true };
    }
  }

  try {
    const params = new URLSearchParams(rawInitData);
    const hash = params.get('hash');
    if (!hash) return { valid: false, isPreview: false };

    params.delete('hash');
    const sortedKeys = Array.from(params.keys()).sort();
    const dataCheckString = sortedKeys.map((key) => `${key}=${params.get(key)}`).join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken || '').digest();
    const computedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex');

    if (computedHash === hash) {
      const userRaw = params.get('user');
      const userData = userRaw ? JSON.parse(userRaw) : undefined;
      return { valid: true, isPreview: false, userData };
    }
    return { valid: false, isPreview: false };
  } catch {
    return { valid: false, isPreview: false };
  }
}

function getOrInitUserStrike(uid: number): UserStrikeRecord {
  const existing = userStrikes.get(uid);
  if (existing) return existing;
  const stored = persistentStorage.getUserStrike(uid);
  if (stored) {
    const rec: UserStrikeRecord = {
      telegramUserId: stored.telegramUserId,
      strikes: stored.strikes,
      verdict: stored.verdict as StrikeVerdict,
      blockedForVerification: stored.blockedForVerification,
      lastAnomalyReason: stored.lastAnomalyReason,
      updatedAt: stored.updatedAt,
    };
    userStrikes.set(uid, rec);
    return rec;
  }
  const fresh: UserStrikeRecord = {
    telegramUserId: uid,
    strikes: 0,
    verdict: '0_REGOLARE',
    blockedForVerification: false,
    lastAnomalyReason: null,
    updatedAt: new Date().toISOString(),
  };
  userStrikes.set(uid, fresh);
  persistentStorage.saveUserStrike(uid, fresh);
  return fresh;
}

function recordUserStrike(uid: number, reason: string): UserStrikeRecord {
  const rec = getOrInitUserStrike(uid);
  const nextStrikes = Math.min(3, rec.strikes + 1) as 0 | 1 | 2 | 3;
  rec.strikes = nextStrikes;
  rec.lastAnomalyReason = reason;
  rec.updatedAt = new Date().toISOString();

  if (nextStrikes === 1) {
    rec.verdict = '1_OK_TOLLERATO';
    rec.blockedForVerification = false;
  } else if (nextStrikes === 2) {
    rec.verdict = '2_NON_BENE_WARNING';
    rec.blockedForVerification = false;
  } else {
    rec.verdict = '3_VERIFICA_E_BLOCCO';
    rec.blockedForVerification = true;
    // Sincronizzazione atomica persistente su database PostgreSQL (core.users) se connesso
    if (dbPool) {
      dbPool
        .query('UPDATE core.users SET is_blocked = TRUE WHERE user_id = $1', [uid])
        .catch(() => {});
    }
  }
  userStrikes.set(uid, rec);
  persistentStorage.saveUserStrike(uid, rec);
  return rec;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createExpressApp() {
  const app = express();
  app.use(express.json());
  app.use(express.static(path.resolve(process.cwd(), 'public')));

  // ============================================================================
  // ADMIN AUTH MIDDLEWARE (HMAC condiviso o header X-Admin-Token)
  // ============================================================================
  function requireAdmin(req: Request, res: Response, next: () => void) {
    const token = req.header('x-admin-token') || '';
    const expected = process.env.ADMIN_API_TOKEN || '';
    if (!expected || token !== expected) {
      return res.status(401).json({ ok: false, error: 'ADMIN_AUTH_REQUIRED' });
    }
    return next();
  }

  // ============================================================================
  // ADMIN VERIFY (per il long-press segreto)
  // ============================================================================
  app.post('/api/admin/verify', (req: Request, res: Response) => {
    const { telegramUserId } = req.body || {};
    const admins = (process.env.ADMIN_TELEGRAM_IDS || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const isAdmin = admins.includes(String(telegramUserId));
    return res.json({ ok: true, isAdmin });
  });

  // ============================================================================
  // SYSTEM HEALTH & METRICS
  // ============================================================================
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'OK',
      service: 'ActionFlow Hub Backend',
      uptimeSeconds: Math.floor(process.uptime()),
      workers: {
        tonPayout: workers.tonPayout.getMetrics(),
        settlement: workers.settlement.getStatus(),
        blockchain: workers.blockchain.getStatus(),
      },
      timestamp: new Date().toISOString(),
    });
  });

  // ============================================================================
  // PROVIDER REPUTATION ADMIN ROUTES
  // ============================================================================
  app.use('/api/admin/providers', requireAdmin, providerAdminRouter);

  // ============================================================================
  // WALLETS & SETTLEMENT ROUTES
  // ============================================================================
  app.get('/api/wallets/config', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      wallets: {
        TON: {
          receiveAddress: WALLET_CONFIG.TON.receiveAddress,
          payoutAddresses: WALLET_CONFIG.TON.payoutAddresses,
          network: WALLET_CONFIG.TON.network,
        },
        SOL: {
          receiveAddress: WALLET_CONFIG.SOL.receiveAddress,
          payoutAddresses: WALLET_CONFIG.SOL.payoutAddresses,
          network: WALLET_CONFIG.SOL.network,
        },
        PI: {
          receiveAddress: WALLET_CONFIG.PI.receiveAddress,
          payoutAddresses: WALLET_CONFIG.PI.payoutAddresses,
          network: WALLET_CONFIG.PI.network,
        },
      },
      workers: {
        tonPayout: workers.tonPayout.getMetrics(),
        settlement: workers.settlement.getStatus(),
        blockchain: workers.blockchain.getStatus(),
      },
    });
  });

  // Endpoint per validazione crittografica Telegram Mini App InitData
  app.post('/api/init', (req: Request, res: Response) => {
    const { initData } = req.body || {};
    const result = verifyTelegramWebAppData(initData);
    if (result.valid) {
      return res.json({ success: true, user: result.userData, isPreview: result.isPreview });
    }
    return res.status(401).json({ success: false, error: 'Invalid HMAC signature' });
  });

  app.post('/api/settlement/execute', requireAdmin, async (req: Request, res: Response) => {
    try {
      const {
        batchId,
        partnerId,
        periodStart = Date.now() - 86400_000,
        periodEnd = Date.now(),
        expectedGrossUsd = 0,
        actualNetReceivedUsd = 0,
        haircutRatio = 1.0,
        onchainTxHash = '',
      } = req.body || {};

      if (!batchId || !partnerId) {
        return res.status(400).json({ ok: false, error: 'batchId e partnerId richiesti' });
      }

      const result = await SettlementService.executeBatchSettlement({
        batchId: String(batchId),
        partnerId: String(partnerId),
        periodStart: Number(periodStart),
        periodEnd: Number(periodEnd),
        expectedGrossUsd: Number(expectedGrossUsd),
        actualNetReceivedUsd: Number(actualNetReceivedUsd),
        haircutRatio: Number(haircutRatio),
        onchainTxHash: String(onchainTxHash),
      });

      return res.json(result);
    } catch (e: any) {
      return res.status(500).json({ ok: false, error: e.message });
    }
  });

  // ============================================================================
  // STATO 3-STRIKE UTENTE (1 = OK • 2 = NON BENE • 3 = VERIFICA E BLOCCO)
  // ============================================================================
  app.get('/api/user/strikes', (req: Request, res: Response) => {
    const uid = Number(req.query.telegramUserId) || 0;
    const strikeRecord = getOrInitUserStrike(uid);
    res.json({
      ok: true,
      policy: '1 = OK (Tollerato) • 2 = NON BENE (Avviso Severo) • 3 = VERIFICA E BLOCCO IMMEDIATO',
      strikeRecord,
    });
  });

  // ============================================================================
  // PULIZIA MEMORIA SERVER (RESET MAPPE IN-MEMORY)
  // ============================================================================
  app.post('/api/system/purge-memory', requireAdmin, (_req: Request, res: Response) => {
    userDailyState.clear();
    activeSessions.clear();
    userStrikes.clear();
    res.json({ ok: true, purgedAt: new Date().toISOString() });
  });

  // ============================================================================
  // SESSION TIMER (10 MIN SERVER)
  // ============================================================================
  app.post('/api/session/start', async (req: Request, res: Response) => {
    const {
      telegramUserId = 0,
      sessionMinutes = 20,
      timeZone = 'UTC',
      initData,
    } = req.body || {};

    const rawInitData = (req.headers['x-telegram-init-data'] as string | undefined) || initData;
    const authCheck = verifyTelegramWebAppData(rawInitData);
    if (!authCheck.valid) {
      return res.status(401).json({
        ok: false,
        error: 'TELEGRAM_AUTH_INVALID: Firma crittografica initData non valida.',
      });
    }

    const uid = Number(telegramUserId) || (authCheck.userData?.id ? Number(authCheck.userData.id) : 0);
    const strikeRecord = getOrInitUserStrike(uid);
    if (strikeRecord.blockedForVerification) {
      return res.status(403).json({
        ok: false,
        error: 'STRIKE_3_VERIFICA_E_BLOCCO: Account temporaneamente bloccato per 3 anomalie rilevate.',
        strikeRecord,
      });
    }

    const tz = normalizeTimeZone(timeZone);
    const nowMs = Date.now();
    const todayKey = localDateKey(nowMs, tz);

    await LedgerService.startSession(String(uid), sessionMinutes, nowMs).catch(() => {});

    let state = userDailyState.get(uid);
    if (!state || shouldResetDaily(state.lastResetDate, todayKey)) {
      state = {
        lastResetDate: todayKey,
        timeZone: tz,
        completedBlocksToday: 0,
        totalPoints: state?.totalPoints || 0,
      };
      userDailyState.set(uid, state);
    }

    const nextBlock = state.completedBlocksToday + 1;
    const expectedReward = rewardForBlock(nextBlock);
    const validMinutes = resolveSessionMinutes(sessionMinutes);
    const sessionId = `sess_${uid}_${nowMs.toString(36)}`;

    const record: ServerSessionRecord = {
      sessionId,
      telegramUserId: uid,
      startedAtMs: nowMs,
      sessionMinutes: validMinutes,
      blockNumber: nextBlock,
      dateKey: todayKey,
      timeZone: tz,
      completed: false,
    };
    activeSessions.set(sessionId, record);
    persistentStorage.saveSession(record);
    persistentStorage.saveUserDailyState(uid, state);

    res.json({
      ok: true,
      sessionId,
      blockNumber: nextBlock,
      expectedRewardPoints: expectedReward,
      sessionMinutes: validMinutes,
      serverBlockDurationSeconds: 600,
      startedAtMs: nowMs,
      todayKey,
      strikeRecord,
    });
  });

  app.get('/api/session/status', (req: Request, res: Response) => {
    const uid = Number(req.query.telegramUserId) || 0;
    const tz = normalizeTimeZone(req.query.timeZone || 'UTC');
    const todayKey = localDateKey(Date.now(), tz);
    let state = userDailyState.get(uid);
    if (!state) {
      const stored = persistentStorage.getUserDailyState(uid);
      if (stored) {
        state = stored;
        userDailyState.set(uid, state);
      }
    }
    const completedBlocksToday =
      state && !shouldResetDaily(state.lastResetDate, todayKey) ? state.completedBlocksToday : 0;
    const nextBlock = completedBlocksToday + 1;

    // Controllo recupero sessione attiva non completata (entro 1800s)
    const activeSess = persistentStorage.getActiveSessionForUser(uid, 1800);
    let activeSessionPayload = null;
    if (activeSess) {
      const now = Date.now();
      const elapsed = Math.floor((now - activeSess.startedAtMs) / 1000);
      activeSessionPayload = {
        sessionId: activeSess.sessionId,
        blockNumber: activeSess.blockNumber,
        startedAtMs: activeSess.startedAtMs,
        elapsedSeconds: Math.min(600, elapsed),
        remainingSeconds: Math.max(0, 600 - elapsed),
        canComplete: elapsed >= 600,
      };
    }

    res.json({
      ok: true,
      completedBlocksToday,
      nextBlock,
      nextRewardPoints: rewardForBlock(nextBlock),
      pointsPerUsdt: 100,
      todayKey,
      strikeRecord: getOrInitUserStrike(uid),
      activeSession: activeSessionPayload,
    });
  });

  app.post('/api/session/complete', (req: Request, res: Response) => {
    const {
      sessionId,
      telegramUserId = 0,
      blockNumber = 1,
      timeZone = 'UTC',
    } = req.body || {};

    const uid = Number(telegramUserId) || 0;
    const currentStrike = getOrInitUserStrike(uid);
    if (currentStrike.blockedForVerification) {
      return res.status(403).json({
        ok: false,
        error: 'STRIKE_3_VERIFICA_E_BLOCCO: Account e riscatti bloccati alla 3ª anomalia per verifica automatica.',
        strikeRecord: currentStrike,
      });
    }

    const tz = normalizeTimeZone(timeZone);
    const todayKey = localDateKey(Date.now(), tz);

    let state = userDailyState.get(uid);
    if (!state) {
      const stored = persistentStorage.getUserDailyState(uid);
      if (stored) {
        state = stored;
      }
    }
    if (!state || shouldResetDaily(state.lastResetDate, todayKey)) {
      state = {
        lastResetDate: todayKey,
        timeZone: tz,
        completedBlocksToday: 0,
        totalPoints: state?.totalPoints || 0,
      };
    }

    let session = sessionId ? activeSessions.get(String(sessionId)) : undefined;
    if (!session && sessionId) {
      const storedSess = persistentStorage.getSession(String(sessionId));
      if (storedSess) {
        session = storedSess;
        activeSessions.set(session.sessionId, session);
      }
    }

    if (!session) {
      return res.status(404).json({
        ok: false,
        error: 'SESSIONE_NON_TROVATA: SessionId non valido o inesistente.',
      });
    }

    if (session.telegramUserId !== uid) {
      return res.status(403).json({
        ok: false,
        error: 'SESSIONE_NON_AUTORIZZATA: La sessione appartiene a un altro utente.',
      });
    }

    // REGOLA 2: Idempotenza trasparente (stessa sessione e stesso utente)
    // Restituisce il risultato già registrato senza duplicare i punti e senza assegnare Strike
    if (session.completed && session.completedResult) {
      return res.json({
        ok: true,
        idempotent: true,
        sessionId: session.sessionId,
        ...session.completedResult,
        strikeRecord: currentStrike,
      });
    }

    // REGOLA 1: Rispetto di tutti i 600 secondi effettivi del server.
    // Nessuna tolleranza che permetta di accreditare punti in anticipo.
    const nowMs = Date.now();
    const elapsedSeconds = Math.floor((nowMs - session.startedAtMs) / 1000);
    if (elapsedSeconds < 600) {
      return res.status(400).json({
        ok: false,
        error: 'TEMPO_INSUFFICIENTE: Il blocco richiede tutti i 600 secondi effettivi di visualizzazione.',
        elapsedSeconds,
        requiredSeconds: 600,
        remainingSeconds: 600 - elapsedSeconds,
      });
    }

    session.completed = true;
    state.completedBlocksToday += 1;
    const creditedBlock = Number(blockNumber) || state.completedBlocksToday;
    const creditedPoints = rewardForBlock(creditedBlock);
    state.totalPoints += creditedPoints;
    userDailyState.set(uid, state);
    persistentStorage.saveUserDailyState(uid, state);

    const resultPayload = {
      creditedBlock,
      creditedPoints,
      completedBlocksToday: state.completedBlocksToday,
      nextRewardPoints: rewardForBlock(state.completedBlocksToday + 1),
      totalPoints: state.totalPoints,
    };
    session.completedResult = resultPayload;
    persistentStorage.saveSession(session);

    res.json({
      ok: true,
      sessionId: session.sessionId,
      ...resultPayload,
      strikeRecord: currentStrike,
    });
  });

  app.post('/api/affiliate/click', (req: Request, res: Response) => {
    res.json({ ok: true, clickId: req.body?.clickId || null, recordedAt: Date.now() });
  });

  app.post('/api/rewards/record', (req: Request, res: Response) => {
    res.json({ ok: true, rewardId: req.body?.id || null, status: 'RECORDED' });
  });

  app.post('/api/payout/request', async (req: Request, res: Response) => {
    const {
      telegram_user_id = 0,
      points = 0,
      wallet_address = '',
      crypto_asset = 'TON',
    } = req.body || {};
    const uid = Number(telegram_user_id) || 0;
    const strikeRecord = getOrInitUserStrike(uid);

    if (strikeRecord.blockedForVerification) {
      return res.status(403).json({
        ok: false,
        error: 'STRIKE 3 (VERIFICA E BLOCCO): Prelievi sospesi automaticamente per 3 anomalie rilevate.',
        strikeRecord,
      });
    }

    const cleanAddress = String(wallet_address || '').trim();
    const numericPoints = Number(points) || 0;

    if (numericPoints < 500 || cleanAddress.length < 4) {
      const updatedStrike = recordUserStrike(uid, 'TENTATIVO_PRELIEVO_PARAMETRI_FORZATI');
      return res.status(400).json({
        ok: false,
        error: `Minimo 500 punti e recapito valido richiesti [Stato Strike: ${updatedStrike.verdict}]`,
        strikeRecord: updatedStrike,
      });
    }

    // Validazione Automatica Aiuto Interno: controlla capienza Vault prima di autorizzare
    const rawAsset = String(crypto_asset || 'TON').toUpperCase();
    const vaultKey =
      rawAsset === 'USDT' || rawAsset.startsWith('CASH_') || rawAsset === 'SOL'
        ? 'USDT'
        : 'TON';
    const vaultStatus = LedgerService.getVaultStatus(vaultKey);
    if (vaultStatus && numericPoints > vaultStatus.pointsCapacity) {
      return res.status(409).json({
        ok: false,
        error: 'SCUDO_SOLVIBILITA_ATTIVO: In attesa di riconciliazione automatica incasso fornitori',
      });
    }

    const reserve = await LedgerService.reservePayout(String(uid), numericPoints);
    if (!reserve.ok) {
      return res.status(409).json({
        ok: false,
        error: reserve.error || 'RESERVE_FAILED',
      });
    }

    const amountUsd = Number((numericPoints * 0.01).toFixed(2));
    const amountTon = Number((numericPoints * 0.002).toFixed(4));
    const reqId = `payout_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    workers.tonPayout.start();

    const tonPrivateKey = WALLET_CONFIG.TON.privateKey;
    const isLiveOnChain = Boolean(tonPrivateKey && tonPrivateKey.length > 32);

    const storedPayout: StoredPayoutRequest = {
      requestId: reqId,
      userId: String(telegram_user_id),
      points: numericPoints,
      amountUsd,
      amountTon,
      cryptoAsset: rawAsset,
      walletAddress: cleanAddress,
      status: 'PENDING',
      payoutStatus: isLiveOnChain ? 'PROCESSING' : 'PENDING_ADMIN_DISBURSEMENT',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    persistentStorage.savePayoutRequest(storedPayout);

    res.json({
      ok: true,
      requestId: reqId,
      userId: String(telegram_user_id),
      points: numericPoints,
      amountUsd,
      amountTon,
      cryptoAsset: rawAsset,
      walletAddress: cleanAddress,
      verifiedByInternalGuardian: true,
      strikeRecord,
      status: 'PENDING',
      payoutStatus: isLiveOnChain ? 'PROCESSING' : 'PENDING_ADMIN_DISBURSEMENT',
      message: isLiveOnChain
        ? 'Richiesta di prelievo registrata e inviata per elaborazione on-chain.'
        : 'Richiesta registrata in coda. Erogazione programmata previa verifica amministrativa.',
    });
  });

  // ============================================================================
  // PRELIEVI: GESTIONE CICLO PENDING -> APPROVED -> COMPLETED / REJECTED
  // ============================================================================
  app.get('/api/payout/list', (_req: Request, res: Response) => {
    const list = persistentStorage.getAllPayoutRequests();
    res.json({ ok: true, count: list.length, payouts: list });
  });

  app.post('/api/payout/disburse', requireAdmin, async (req: Request, res: Response) => {
    const {
      requestId,
      status, // 'APPROVED' | 'COMPLETED' | 'REJECTED'
      txHash,
      note,
    } = req.body || {};

    if (!requestId || !status) {
      return res.status(400).json({ ok: false, error: 'requestId e status sono obbligatori' });
    }

    const payout = persistentStorage.getPayoutRequest(String(requestId));
    if (!payout) {
      return res.status(404).json({ ok: false, error: 'Richiesta di prelievo non trovata' });
    }

    if (status === 'REJECTED') {
      payout.status = 'REJECTED';
      payout.payoutStatus = 'REJECTED_REFUNDED';
      payout.note = note || 'Prelievo rifiutato e punti rimborsati';
      payout.updatedAt = Date.now();
      // Refund atomico: RESERVED -> WITHDRAWABLE
      if (dbPool) {
        const uid = Number(payout.userId) || 0;
        await dbPool.query(
          `UPDATE core.balances SET balance = balance - $2 WHERE account_id = 'USER_' || $1 || ':RESERVED'`,
          [uid, payout.points]
        );
        await dbPool.query(
          `UPDATE core.balances SET balance = balance + $2 WHERE account_id = 'USER_' || $1 || ':WITHDRAWABLE'`,
          [uid, payout.points]
        );
      }
      // Rimborso atomico punti all'utente nello stato persistente
      const uid = Number(payout.userId) || 0;
      let state = userDailyState.get(uid);
      if (!state) {
        state = persistentStorage.getUserDailyState(uid);
      }
      if (state) {
        state.totalPoints += payout.points;
        userDailyState.set(uid, state);
        persistentStorage.saveUserDailyState(uid, state);
      }
    } else if (status === 'APPROVED') {
      payout.status = 'APPROVED';
      payout.payoutStatus = 'APPROVED_READY_FOR_DISBURSEMENT';
      payout.note = note || 'Prelievo approvato, in attesa di firma ed erogazione';
      payout.updatedAt = Date.now();
    } else if (status === 'COMPLETED') {
      payout.status = 'COMPLETED';
      payout.payoutStatus = 'COMPLETED_ONCHAIN';
      payout.txHash = txHash || `tx_confirmed_${Date.now()}`;
      payout.note = note || 'Liquidazione confermata con successo';
      payout.updatedAt = Date.now();
    } else {
      return res.status(400).json({ ok: false, error: 'Stato prelievo non valido' });
    }

    persistentStorage.savePayoutRequest(payout);
    res.json({ ok: true, payout });
  });

  // ============================================================================
  // WEBHOOK S2S POSTBACK FORNITORI (Adsterra, Monetag, CPA Grip, Offertoro, etc.)
  // Regola Unica 70/30: Payout $1.00 USD -> $0.70 piattaforma / $0.30 utente (30 PT)
  // Idempotenza nativa per txId
  // ============================================================================
  const handlePostback = (req: Request, res: Response) => {
    const webhookSecret = process.env.WEBHOOK_SECRET || '';
    const providedSecret = req.header('x-webhook-secret') || String(req.query.secret || '');
    if (!webhookSecret || providedSecret !== webhookSecret) {
      return res.status(401).json({ ok: false, error: 'WEBHOOK_AUTH_REQUIRED' });
    }

    const provider = String(req.query.provider || req.body?.provider || 'generic').toLowerCase();
    const userId = String(req.query.userId || req.query.subId || req.body?.userId || req.body?.subId || '0');
    const payoutRaw = Number(req.query.payout || req.query.revenue || req.body?.payout || req.body?.revenue || 0);
    const txId = String(
      req.query.txId ||
        req.query.conversionId ||
        req.body?.txId ||
        req.body?.conversionId ||
        `conv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    );

    if (payoutRaw <= 0 || !userId || userId === '0') {
      return res.status(400).json({
        ok: false,
        error: 'PARAMETRI_POSTBACK_INVALIDI: payout > 0 e userId sono obbligatori.',
      });
    }

    // Idempotenza S2S: se la conversione è già stata registrata, restituisce 200 OK senza duplicare
    if (persistentStorage.isWebhookProcessed(txId)) {
      return res.json({
        ok: true,
        idempotent: true,
        message: 'CONVERSIONE_GIA_PROCESSATA',
        txId,
      });
    }

    // Ripartizione 70% piattaforma / 30% utente su scala 100 PT = $1.00 USD
    const userRevenueUsd = Number((payoutRaw * 0.30).toFixed(4));
    const platformRevenueUsd = Number((payoutRaw * 0.70).toFixed(4));
    const pointsToCredit = Math.round(userRevenueUsd * 100);

    const uid = Number(userId) || 0;
    const tz = 'UTC';
    const todayKey = localDateKey(Date.now(), tz);

    let state = userDailyState.get(uid);
    if (!state) {
      state = persistentStorage.getUserDailyState(uid);
    }
    if (!state || shouldResetDaily(state.lastResetDate, todayKey)) {
      state = {
        lastResetDate: todayKey,
        timeZone: tz,
        completedBlocksToday: 0,
        totalPoints: state?.totalPoints || 0,
      };
    }
    state.totalPoints += pointsToCredit;
    userDailyState.set(uid, state);
    persistentStorage.saveUserDailyState(uid, state);

    // Salva conversione certificata su disco
    persistentStorage.saveWebhookConversion({
      txId,
      provider,
      userId,
      payoutUsd: payoutRaw,
      pointsCredited: pointsToCredit,
      timestamp: Date.now(),
    });

    res.json({
      ok: true,
      provider,
      txId,
      payoutUsd: payoutRaw,
      platformRevenueUsd,
      userRevenueUsd,
      pointsCredited: pointsToCredit,
      newTotalPoints: state.totalPoints,
    });
  };

  app.get('/api/webhook/postback', handlePostback);
  app.post('/api/webhook/postback', handlePostback);

  // ============================================================================
  // AIUTO INTERNO AUTOMATICO (GUARDIANO 24/7 — REGOLA RIGIDA 1-2-3 STRIKE)
  // ============================================================================
  app.get('/api/audit/guardian', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      autonomousMode: true,
      manualVerificationRequired: false,
      strictThreeStrikePolicy: {
        strike1: '1 = OK (1° Episodio tollerato come errore tecnico: azione non pagata / haircut applicato, account resta attivo)',
        strike2: '2 = NON BENE (2° Episodio: avviso severo + penalità priorità, tolleranza esaurita)',
        strike3: '3 = VERIFICA E BLOCCO IMMEDIATO (3° Episodio: blocco automatico prelievi utente o quarantena + failover fornitore)',
      },
      modules: {
        userAntiFraud: {
          status: 'ACTIVE_24_7',
          rules: [
            'Protocollo 3-Strike Utente: 1 = OK • 2 = NON BENE (Avviso) • 3 = VERIFICA E BLOCCO Prelievi',
            'Orologio Server 10m anti-accelerazione',
            'Idempotenza anti-doppio clic su sessioni e prelievi',
            'Revoca automatica punti PENDING se il fornitore storna (core.partner_confirm_reward)',
          ],
        },
        providerDishonestyShield: {
          status: 'ACTIVE_24_7',
          rules: [
            'Protocollo 3-Strike Fornitore: 1 = OK (Haircut applicato) • 2 = NON BENE (WARNING) • 3 = VERIFICA E BLOCCO (QUARANTINE)',
            'Calcolo automatico Haircut Ratio su ogni batch < 95% promesso',
            'Failover Chain automatica: sostituzione istantanea fornitore al 3° Strike',
          ],
        },
        treasuryAutoReconciliation: {
          status: 'ACTIVE_24_7',
          tonVault: LedgerService.getVaultStatus('TON'),
          usdtVault: LedgerService.getVaultStatus('USDT'),
          workers: {
            blockchainListener: workers.blockchain.getStatus(),
            settlementWorker: workers.settlement.getStatus(),
            tonPayoutWorker: workers.tonPayout.getMetrics(),
          },
        },
      },
      timestamp: new Date().toISOString(),
    });
  });

  return app;
}

let serverStarted = false;

export async function startServer() {
  if (serverStarted) return;
  serverStarted = true;
  const app = createExpressApp();
  const PORT = 3000;

  workers.tonPayout.start();
  workers.settlement.start();
  workers.blockchain.start();

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, '../dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ActionFlow Hub Server listening on http://0.0.0.0:${PORT}`);
  });
}

const isDirectEntry = process.argv[1] && (process.argv[1].endsWith('/src/server.ts') || process.argv[1].endsWith('/src/server.js'));
if (isDirectEntry) {
  void startServer();
}
