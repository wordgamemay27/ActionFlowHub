import { SUPPORTED_LANGS, computeBalancedLocalTaskPoints } from '../src/lib/i18n';
import { PROJECTS_CATALOG, GLOBAL_CRYPTO_BRAND_CARDS } from '../src/lib/catalogData';

if (SUPPORTED_LANGS.length !== 14) {
  throw new Error(`Expected 14 languages, found ${SUPPORTED_LANGS.length}`);
}

const pts = computeBalancedLocalTaskPoints(30, 'it', 1);
if (pts !== 30) {
  throw new Error('Invalid computed task points');
}

console.log(
  `[verify-e2e-flow] OK — ${SUPPORTED_LANGS.length} lingue, ${PROJECTS_CATALOG.length} progetti catalogo, ${GLOBAL_CRYPTO_BRAND_CARDS.length} crypto brand cards.`
);
