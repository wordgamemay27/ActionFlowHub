import {
  SUPPORTED_LANGS,
  ENTRY_FLOW_TEXT,
  resolveSessionMinutes,
  rewardForBlock,
  localDateKey,
  shouldResetDaily,
} from '../src/lib/entryProfile';

if (SUPPORTED_LANGS.length !== 14) {
  throw new Error(`Expected 14 languages, got ${SUPPORTED_LANGS.length}`);
}

for (const lang of SUPPORTED_LANGS) {
  if (!ENTRY_FLOW_TEXT[lang]?.langTitle || !ENTRY_FLOW_TEXT[lang]?.marketTitle) {
    throw new Error(`Missing ENTRY_FLOW_TEXT for ${lang}`);
  }
}

if (resolveSessionMinutes(10) !== 10 || resolveSessionMinutes(30) !== 30 || resolveSessionMinutes(45) !== 20) {
  throw new Error('resolveSessionMinutes failed');
}

if (
  rewardForBlock(1, 1.0) !== 30 ||
  rewardForBlock(2, 1.0) !== 30 ||
  rewardForBlock(1, 2.0) !== 60
) {
  throw new Error('rewardForBlock 30% per action rule (1 USDT = 30 PT / $0.30 on 100 PT = $1.00 scale) failed');
}

const today = localDateKey(Date.now(), 'Europe/Rome');
if (!shouldResetDaily(null, today)) {
  throw new Error('shouldResetDaily failed');
}

console.log('[verify-entry-profile] OK — 14 lingue, regola 30% su scala 100 PT = $1.00 (1 USDT = 30 PT / $0.30), durate 10/20/30m e reset giornaliero verificati.');
