import { recordRealReward, summarizeRealRewards } from '../src/lib/affiliate';

async function main() {
  const r1 = await recordRealReward({
    kind: 'AIRDROP',
    project: 'Binance',
    tokenSymbol: 'BNB',
    amount: 1,
    network: 'BSC',
    source: 'binance_task',
  });

  const r2 = await recordRealReward({
    kind: 'TOKEN',
    project: 'AdsGram',
    tokenSymbol: 'TON',
    amount: 0.25,
    network: 'TON',
    source: 'adsgram_task',
    status: 'VERIFIED',
  });

  if (!r1 || !r2) {
    throw new Error('Failed to create real rewards');
  }

  const summary = summarizeRealRewards([r1, r2]);
  if (summary.total !== 2 || summary.airdrop !== 1 || summary.token !== 1) {
    throw new Error('Bucket summary mismatch');
  }

  console.log('[verify-ledger] OK — 3-Bucket Ledger & Affiliate RealReward (AIRDROP/TOKEN/MINING) verificati.');
}

main();
