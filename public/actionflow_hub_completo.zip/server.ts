import { createExpressApp, startServer } from './src/server';

startServer();

export { createExpressApp, startServer };
