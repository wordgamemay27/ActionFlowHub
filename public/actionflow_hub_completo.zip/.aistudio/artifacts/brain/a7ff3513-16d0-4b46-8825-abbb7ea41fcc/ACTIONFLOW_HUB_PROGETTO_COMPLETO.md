# ActionFlow Hub (by Have2Want +) — Progetto Completo & Codice Sorgente

## 📥 Download Diretto Archivio Progetto
È disponibile l'archivio ZIP con tutti i file sorgente, immagini, video e configurazioni del progetto:
👉 **[Scarica actionflow_hub_completo.zip](/actionflow_hub_completo.zip)**

---

## 1. Architettura di Sistema & Flusso di Integrazione
- **Canale Utente Primario**: Telegram Mini App (TMA) eseguita all'interno del client Telegram (`Telegram.WebApp`).
- **Ecosistema Gemello**: **Have2Want +** su **Pi Browser** (marketplace Web3 non-custodial).
- **Flusso Operativo**:
  1. L'utente avvia il bot Telegram e apre la Mini App (`https://t.me/actionflowhub_bot`).
  2. L'onboarding neon guida attraverso il video introduttivo (`intro.mp4`), la selezione del tempo sessione (10/20/30 min) e le preferenze (Genere / Categorie prodotto).
  3. Il backend avvia una sessione con timer non saltabile a livello server (`POST /api/session/start`). In caso di refresh, l'app interroga `GET /api/session/status` e riprende i secondi trascorsi.
  4. Le azioni e i task generano conversioni via Webhook S2S (`POST /api/webhook/postback`). Lo split economico automatico assegna:
     - **70%** al Founder/Platform (destinazione wallet non-custodial);
     - **30%** all'Utente accreditato in FlowPoints (`100 PT = $1.00 USD`).
  5. Per il prelievo su Pi Network o TON/SOL, l'utente richiede il pagamento in `WithdrawView`:
     - Stato iniziale: `PENDING`.
     - L'amministratore revisiona e approva in `AdminView` (`APPROVED`).
     - Il worker finalizează la transazione (`COMPLETED`) registrando il `txHash` on-chain nel ledger persistente (`data/persistent_ledger_state.json`).

---

## 2. Configurazioni & Dipendenze Core (`package.json`)
```json
{
  "name": "actionflow-hub",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "tsx server.ts",
    "build": "vite build",
    "preview": "vite preview",
    "start": "node server.ts"
  },
  "dependencies": {
    "clsx": "^2.1.1",
    "dotenv": "^16.4.7",
    "express": "^4.21.2",
    "lucide-react": "^0.475.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "tailwind-merge": "^2.6.0"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^22.13.1",
    "@types/react": "^18.3.18",
    "@types/react-dom": "^18.3.5",
    "@vitejs/plugin-react": "^4.3.4",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.5.1",
    "tailwindcss": "^3.4.17",
    "tsx": "^4.19.2",
    "typescript": "^5.7.3",
    "vite": "^6.1.0"
  }
}
```

---

## 3. Server Backend & Motore S2S (`src/server.ts`)
```typescript
import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { persistentStorage } from './db/persistentStorage';
import { WALLET_CONFIG } from './config/wallets';
import { workers } from './workers';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createExpressApp() {
  const app = express();
  app.use(express.json());
  app.use(express.static(path.resolve(process.cwd(), 'public')));

  // Healthcheck & Metrics
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'OK',
      service: 'ActionFlow Hub Backend',
      uptimeSeconds: Math.floor(process.uptime()),
      workers: {
        tonPayout: workers.tonPayout.getMetrics(),
        settlement: workers.settlement.getStatus(),
        blockchain: workers.blockchain.getStatus(),
      },
      timestamp: new Date().toISOString(),
    });
  });

  // Webhook S2S con Idempotenza e Split 70/30
  app.all('/api/webhook/postback', (req: Request, res: Response) => {
    const data = { ...req.query, ...req.body };
    const txId = String(data.txId || data.trans_id || data.id || `wh_${Date.now()}`);
    const grossUsd = parseFloat(String(data.amount || data.payout || data.usd || '0')) || 0;
    const userId = parseInt(String(data.userId || data.sub1 || '0'), 10) || 0;

    if (persistentStorage.hasProcessedWebhook(txId)) {
      return res.json({ ok: true, status: 'DUPLICATE_IGNORED', txId });
    }

    const platformShareUsd = grossUsd * 0.70;
    const userShareUsd = grossUsd * 0.30;
    const userPoints = Math.round(userShareUsd * 100);

    persistentStorage.recordProcessedWebhook(txId, {
      userId,
      grossUsd,
      platformShareUsd,
      userShareUsd,
      userPoints,
      timestamp: Date.now(),
    });

    res.json({
      ok: true,
      txId,
      grossUsd,
      split: { platform: '70%', user: '30%' },
      creditedPoints: userPoints,
    });
  });

  // Ripresa Timer di Sessione
  app.get('/api/session/status', (req: Request, res: Response) => {
    const userId = parseInt(String(req.query.userId || '0'), 10);
    const session = persistentStorage.getActiveSession(userId);
    res.json({ ok: true, session });
  });

  return app;
}
```

---

## 4. Persistenza Ledger su Disco (`src/db/persistentStorage.ts`)
```typescript
import fs from 'fs';
import path from 'path';

export interface PersistentData {
  sessions: Record<string, { userId: number; startTime: number; durationSeconds: number; completed: boolean }>;
  processedWebhooks: Record<string, any>;
  payouts: Record<string, { id: string; userId: number; amount: number; network: string; status: string; txHash: string | null }>;
  strikes: Record<string, number>;
}

class PersistentStorage {
  private filePath = path.resolve(process.cwd(), 'data/persistent_ledger_state.json');
  private memoryState: PersistentData = { sessions: {}, processedWebhooks: {}, payouts: {}, strikes: {} };

  constructor() {
    this.ensureLoaded();
  }

  private ensureLoaded() {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (fs.existsSync(this.filePath)) {
      try {
        this.memoryState = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      } catch {
        this.persist();
      }
    } else {
      this.persist();
    }
  }

  public persist() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.memoryState, null, 2), 'utf-8');
  }

  public hasProcessedWebhook(txId: string): boolean {
    return Boolean(this.memoryState.processedWebhooks[txId]);
  }

  public recordProcessedWebhook(txId: string, payload: any) {
    this.memoryState.processedWebhooks[txId] = payload;
    this.persist();
  }

  public getActiveSession(userId: number) {
    return this.memoryState.sessions[String(userId)] || null;
  }
}

export const persistentStorage = new PersistentStorage();
```

---

## 5. Configurazione Wallets Non-Custodial (`src/config/wallets.ts`)
```typescript
export const WALLET_CONFIG = {
  TON: {
    receiveAddress: 'UQArcaLwWBTXqOfyJCy3mjPSEuD80p66jzF_95HyXRShBOo-',
    payoutAddresses: ['UQArcaLwWBTXqOfyJCy3mjPSEuD80p66jzF_95HyXRShBOo-'],
    network: 'TON Mainnet',
  },
  SOL: {
    receiveAddress: 'FCiSaZcMYYPyzkJQkfNXdnw4v2PjiR241KYpEm2FeqdT',
    payoutAddresses: ['FCiSaZcMYYPyzkJQkfNXdnw4v2PjiR241KYpEm2FeqdT'],
    network: 'Solana Mainnet-Beta',
  },
  PI: {
    receiveAddress: 'GBCW63ZFL6QZJ47YDPVR3K6732CQK6Z63Q6VZXHZZS3VRZ4BHMPIWLT4',
    payoutAddresses: ['GBCW63ZFL6QZJ47YDPVR3K6732CQK6Z63Q6VZXHZZS3VRZ4BHMPIWLT4'],
    network: 'Pi Network Mainnet / Pi Browser Standalone',
  },
};
```

---

## 6. Componente Header & Brand Identity (`src/components/Header.tsx`)
```tsx
import React from 'react';
import { UserProfile } from '../types';

interface HeaderProps {
  user: UserProfile;
  onOpenProfile: () => void;
  onNavigateTab: (tab: any) => void;
  onSecretAdminUnlock: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, onOpenProfile, onNavigateTab, onSecretAdminUnlock }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#05080f]/95 backdrop-blur-md border-b border-amber-500/20 px-3 py-2 flex items-center justify-between">
      <div onClick={() => onNavigateTab('home')} className="flex items-center gap-2 cursor-pointer select-none">
        <div className="w-10 h-10 rounded-xl overflow-hidden border border-amber-400/50 shrink-0">
          <img src="/assets/aistudio/IMG_20261002_004834_2e580032.png" alt="ActionFlow Hub by Have2Want +" className="w-full h-full object-cover" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="font-black tracking-wide font-serif">
            <span className="text-lg text-amber-400">ActionFlow </span>
            <span className="text-lg text-slate-100">Hub</span>
          </span>
          <span className="text-[10px] font-bold text-amber-300/80 tracking-wider uppercase font-sans">
            by Have2Want +
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={onOpenProfile} className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-300">
          {user.points} PT (${(user.points / 100).toFixed(2)})
        </button>
      </div>
    </header>
  );
};
```

---

## 7. Banner Ufficiale (`src/components/OfficialBanner.tsx`)
```tsx
import React, { useState } from 'react';

export const OfficialBanner: React.FC = () => {
  const [selected, setSelected] = useState<'actionflow' | 'have2want'>('actionflow');

  return (
    <div className="w-full mb-4 rounded-2xl overflow-hidden border-2 border-amber-500/50 shadow-lg bg-[#F6F1EB]">
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#0b1220] border-b border-amber-500/30">
        <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          Banner Ufficiale
        </span>
        <div className="flex items-center gap-1 bg-black/60 p-0.5 rounded-lg border border-slate-700">
          <button
            type="button"
            onClick={() => setSelected('actionflow')}
            className={`px-2 py-0.5 text-[11px] font-bold rounded transition-all ${
              selected === 'actionflow' ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            ActionFlow Hub
          </button>
          <button
            type="button"
            onClick={() => setSelected('have2want')}
            className={`px-2 py-0.5 text-[11px] font-bold rounded transition-all ${
              selected === 'have2want' ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Have2Want +
          </button>
        </div>
      </div>
      <div className="w-full bg-[#F6F1EB] overflow-hidden">
        <img
          src={selected === 'actionflow' ? '/actionflow_hub_banner.jpg' : '/have2want_plus_banner.jpg'}
          alt="Official Brand Banner"
          className="w-full h-auto object-contain block"
        />
      </div>
    </div>
  );
};
```
