-- ============================================================================
-- MIGRATION: 006_execute_batch_settlement.sql
-- DESCRIZIONE: Funzione SQL atomica core.execute_batch_settlement
--             per settlement batch con haircut contabile e accredito tesoreria.
-- ============================================================================

BEGIN;

CREATE SCHEMA IF NOT EXISTS core;

CREATE OR REPLACE FUNCTION core.execute_batch_settlement(
    p_batch_id TEXT,
    p_partner_id TEXT,
    p_period_start BIGINT,
    p_period_end BIGINT,
    p_expected_gross_usd NUMERIC,
    p_actual_net_usd NUMERIC,
    p_haircut_ratio NUMERIC,
    p_onchain_tx_hash TEXT
) RETURNS JSONB AS $$
DECLARE
    v_actual_net NUMERIC := GREATEST(0, COALESCE(p_actual_net_usd, 0));
    v_points_capacity BIGINT := ROUND(v_actual_net * 100);
    v_settled_count INT := 0;
    v_total_points_settled BIGINT := 0;
    v_tx_id UUID;
BEGIN
    -- 1. Aggiorna o incrementa la cassa reale di tesoreria USDT
    INSERT INTO core.treasury_vault (asset, actual_cash_on_chain, points_equivalent_capacity, reserved_buffer_percent)
    VALUES ('USDT', v_actual_net, v_points_capacity, 0.15)
    ON CONFLICT (asset) DO UPDATE
    SET actual_cash_on_chain = core.treasury_vault.actual_cash_on_chain + EXCLUDED.actual_cash_on_chain,
        points_equivalent_capacity = core.treasury_vault.points_equivalent_capacity + EXCLUDED.points_equivalent_capacity,
        updated_at = NOW();

    -- 2. Decrementa l'esposizione del partner per l'importo saldato
    UPDATE core.partner_exposure
       SET pending_points_exposure = GREATEST(0, pending_points_exposure - v_points_capacity),
           updated_at = NOW()
     WHERE partner_id = p_partner_id;

    -- 3. Registra transazione Double-Entry se ci sono punti saldati
    IF v_points_capacity > 0 THEN
        INSERT INTO core.ledger_transactions (reference_type, reference_id, description)
        VALUES ('SETTLEMENT', p_batch_id, 'Liquidazione Batch ' || p_partner_id || ' con ratio ' || p_haircut_ratio)
        RETURNING tx_id INTO v_tx_id;

        INSERT INTO core.ledger_entries (tx_id, account_id, amount)
        VALUES
            (v_tx_id, 'SYSTEM:TREASURY_CASH', v_points_capacity),
            (v_tx_id, 'SYSTEM:UNEARNED_REVENUE', -v_points_capacity);

        UPDATE core.balances SET balance = balance + v_points_capacity, updated_at = NOW()
         WHERE account_id = 'SYSTEM:TREASURY_CASH';

        UPDATE core.balances SET balance = balance - v_points_capacity, updated_at = NOW()
         WHERE account_id = 'SYSTEM:UNEARNED_REVENUE';

        v_settled_count := 1;
        v_total_points_settled := v_points_capacity;
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'batch_id', p_batch_id,
        'partner_id', p_partner_id,
        'settled_users_count', v_settled_count,
        'total_points_settled', v_total_points_settled,
        'haircut_ratio', p_haircut_ratio,
        'onchain_tx_hash', p_onchain_tx_hash
    );
END;
$$ LANGUAGE plpgsql;

COMMIT;
