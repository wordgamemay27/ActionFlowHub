-- ============================================================================
-- MIGRATION: 004_pending_reward_verified.sql
-- DESCRIZIONE: Chiude il ciclo ricompense: PENDING -> VERIFIED/CLAIMED
--             + trigger VERIFIED/CLAIMED -> WITHDRAWABLE / tonBalance
-- ============================================================================

BEGIN;

-- 1. RICOMPENSA REALE UTENTE: verifica transizione di stato
CREATE OR REPLACE FUNCTION core.verify_user_reward(
    p_reward_id TEXT
) RETURNS JSONB AS $$
DECLARE
    v_reward core.user_rewards%ROWTYPE;
    v_user core.users%ROWTYPE;
    v_points BIGINT;
BEGIN
    SELECT * INTO v_reward FROM core.user_rewards WHERE reward_id = p_reward_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'REWARD_NOT_FOUND');
    END IF;

    IF v_reward.status NOT IN ('VERIFIED', 'CLAIMED') THEN
        RETURN jsonb_build_object('success', false, 'error', 'INVALID_STATUS_TRANSITION');
    END IF;

    SELECT * INTO v_user FROM core.users WHERE user_id = v_reward.user_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'USER_NOT_FOUND');
    END IF;

    -- Accredita nel bucket appropriato in base al token
    IF v_reward.token_symbol = 'TON' THEN
        UPDATE core.balances SET balance = balance + v_reward.amount, updated_at = NOW()
         WHERE account_id = 'USER_' || v_reward.user_id || ':WITHDRAWABLE';
        -- Aggiorna anche tonBalance utente (denormalizzato per UI)
        UPDATE core.users SET ton_balance = ton_balance + v_reward.amount, updated_at = NOW()
         WHERE user_id = v_reward.user_id;
    ELSIF v_reward.token_symbol = 'GRAM' THEN
        UPDATE core.balances SET balance = balance + v_reward.amount, updated_at = NOW()
         WHERE account_id = 'USER_' || v_reward.user_id || ':WITHDRAWABLE';
        UPDATE core.users SET gram_balance = gram_balance + v_reward.amount, updated_at = NOW()
         WHERE user_id = v_reward.user_id;
    ELSIF v_reward.token_symbol = 'USDT' THEN
        UPDATE core.balances SET balance = balance + v_reward.amount, updated_at = NOW()
         WHERE account_id = 'USER_' || v_reward.user_id || ':WITHDRAWABLE';
    ELSE
        -- Default: punti in withdrawable
        UPDATE core.balances SET balance = balance + v_reward.amount, updated_at = NOW()
         WHERE account_id = 'USER_' || v_reward.user_id || ':WITHDRAWABLE';
    END IF;

    -- Marca ricompensa come CLAIMED
    UPDATE core.user_rewards
       SET status = 'CLAIMED',
           updated_at = NOW()
     WHERE reward_id = p_reward_id;

    RETURN jsonb_build_object('success', true, 'reward_id', p_reward_id);
END;
$$ LANGUAGE plpgsql;

-- 2. AUTO-VERIFICA: quando un partner conferma via postback, sposta PENDING -> VERIFIED
CREATE OR REPLACE FUNCTION core.partner_confirm_reward(
    p_event_id TEXT,
    p_status TEXT DEFAULT 'VERIFIED' -- 'VERIFIED' | 'REVOKED'
) RETURNS JSONB AS $$
DECLARE
    v_event core.reward_events%ROWTYPE;
    v_reward_id TEXT;
BEGIN
    SELECT * INTO v_event FROM core.reward_events WHERE event_id = p_event_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'EVENT_NOT_FOUND');
    END IF.

    IF v_event.status = 'SETTLED' OR v_event.status = 'REVOKED' THEN
        RETURN jsonb_build_object('success', false, 'error', 'ALREADY_PROCESSED');
    END IF.

    IF p_status = 'REVOKED' THEN
        -- Revoca: rimuovi punti da PENDING
        UPDATE core.balances SET balance = balance - v_event.raw_points, updated_at = NOW()
         WHERE account_id = 'USER_' || v_event.user_id || ':PENDING'.
        UPDATE core.reward_events SET status = 'REVOKED', updated_at = NOW() WHERE event_id = p_event_id.
        -- Decrementa esposizione partner
        UPDATE core.partner_exposure
           SET pending_points_exposure = pending_points_exposure - v_event.raw_points,
               updated_at = NOW()
         WHERE partner_id = v_event.partner_id.
        RETURN jsonb_build_object('success', true, 'action', 'REVOKED').
    END IF.

    -- Approva: PENDING -> SETTLED (evento) + crea/aggiorna user_rewards
    UPDATE core.reward_events SET status = 'SETTLED', updated_at = NOW() WHERE event_id = p_event_id.

    -- Crea/aggiorna user_rewards come VERIFIED
    INSERT INTO core.user_rewards (
        reward_id, user_id, kind, project, token_symbol, amount, network, status, source, tx_hash
    ) VALUES (
        'rw_' || p_event_id || '_' || floor(extract(epoch from now()) * 1000)::text,
        v_event.user_id,
        'TOKEN', -- default, il partner puo' specificare nel payload
        v_event.payload_json->>'project',
        v_event.payload_json->>'tokenSymbol',
        (v_event.payload_json->>'amount')::numeric,
        COALESCE(NULLIF(v_event.payload_json->>'network', ''), 'TON'),
        'VERIFIED',
        v_event.source,
        NULL
    )
    ON CONFLICT (reward_id) DO UPDATE SET
        status = 'VERIFIED',
        updated_at = NOW();

    RETURN jsonb_build_object('success', true, 'action', 'VERIFIED').
END;
$$ LANGUAGE plpgsql;

COMMIT;
