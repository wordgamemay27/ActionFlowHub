# ActionFlow Hub

Telegram Mini App (TMA) per task, airdrop e interazioni automatizzate, con monetizzazione
in affiliazione **TON** e ricompense **reali** per l'utente.

Stack: **React 19 · Vite 8 · TypeScript 7 · Tailwind 4 · Express · PostgreSQL**.

---

## Avvio rapido


| Script | Cosa fa |
|---|---|
| `npm run dev` | Express con Vite in middleware mode (porta 3000) |
| `npm run build` | Build di produzione in `dist/` |
| `npm start` | Server in produzione (serve `dist/`) |
| `npm run lint` | `tsc --noEmit` (type-check) |
| `npm test` | Tutte e 4 le suite di verifica (37 check) |
| `npm run test:ledger` | 6 check — ledger a 4 bucket, timer, idempotenza |
| `npm run test:e2e` | 8 check — ciclo completo PENDING → WITHDRAWABLE → TON |
| `npm run test:entry` | 19 check — lingua, categorie, durata, reset giornaliero |
| `npm run test:brands` | 4 check — loghi ufficiali dei brand (HTTP 200) |

> Richiede **Node ≥ 20**. I test usano `node --import tsx` (nessun binario `tsx` da installare).

---

## Architettura dell'interfaccia

**Una sola barra di navigazione**, orizzontale e scorrevole col dito
(`src/components/CyberNav.tsx`), con tutte le viste. Nessuna sotto-barra di filtri
interna alle pagine.

Regola strutturale: **1 Categoria = 1 Pagina Dedicata**.

| Tab | Pagina | Contenuto |
|---|---|---|
| ⌂ HOME | `views/HomeView.tsx` | nucleo geometrico, card attività, boost |
| ◉ GIOCHI & BOT | `views/GamesView.tsx` + `TelegramBotView` | giochi, playtest, bot operativi |
| ▤ SOAP OPERA | `views/MicroDramaView.tsx` | mini-serie e soap |
| ♪ MUSICA | `views/MusicAudioView.tsx` | video musicali e audio |
| ◈ AI & OCR | `views/AiWorkView.tsx` + `ReceiptOcrView` | task AI, scontrini |
| ◉ AIRDROP | `views/AirdropHubView.tsx` | campagne verificate, referral tracciati |
| ▣ SHOPPING & PREMI | `views/ShoppingView.tsx` | gift card, voucher, carte, brand |
| ◐ WALLET | `views/WithdrawView.tsx` | saldo, TON, prelievi |
| ▦ MATRIX S2S | `views/MasterMatrixView.tsx` | monetizzazione B2B (lato piattaforma) |

### Stile

`src/design/glass.css` — glassmorphism su fondo metallico scuro, dettagli nero
lucido, neon blu elettrico.

* `components/Glass.tsx` → `GlassPanel`, `GlassCard`, `GlassButton`, `GlassPlaceholder`, `BrandLogo`
* `components/GeoCore.tsx` → nucleo geometrico interattivo (al tocco si illumina di blu neon e apre il menu)
* Le foto stock non esistenti sono sostituite da `assets/glassPlaceholder.ts` (segnaposto in vetro, già dimensionato)

### Loghi ufficiali

`src/lib/brands.ts` mappa ogni brand/token al **logo ufficiale** (simpleicons CDN /
Wikimedia). `public/logos/` ne contiene il mirror locale (serve alle WebView senza
accesso a Internet). Se un marchio non ha un logo ufficiale, l'interfaccia mostra
il segnaposto in vetro: nessuna immagine "quasi ufficiale" o inventata.

---

## Modello di business

**Per la piattaforma.** Ogni avvio di compito, iscrizione o referral transita dai
link di affiliazione ufficiali con un `click_id` (`src/lib/affiliate.ts`).
Il provento è denominato in **TON** ed entra nella cassa TON del ledger.

| Endpoint | Funzione |
|---|---|
| `POST /api/affiliate/click` | registra il click e accredita il provento TON |
| `POST /api/rewards/record` | registra la ricompensa reale dell'utente |
| `GET /api/rewards` | elenco delle ricompense reali dell'utente |

**Per l'utente.** Nessun punto fittizio: le ricompense sono reali e verificabili —
`AIRDROP` (partecipazione al progetto), `TOKEN` (token ufficiale del partner),
`MINING` (mining certificato). Ogni ricompensa porta progetto, token,
rete e stato.

---

## Backend

* `migrations/001_core_ledger_3buckets.sql` — schema `core`, double-entry a 4 bucket
  (Pending / Settled / Withdrawable / Reserved), trigger deferred di zero-sum
* `migrations/002_daily_reset_timezone.sql` — reset giornaliero atomico nel fuso
  IANA dell'utente, riancoraggio al cambio di fuso (nessun bonus extra)
* `migrations/003_affiliate_ton_rewards.sql` — click di affiliazione (cassa TON) e
  ricompense reali dell'utente
* `src/db/ledgerService.ts` — servizio ledger con fallback in-memory (solo dev)

Il **timer dei 10 minuti e il confine di giornata usano l'orologio del server**:
il timestamp dichiarato dal client non può abbreviare il blocco né innescare
reset anticipati.

---

## Note operative

* Su storage condiviso i binari nativi non sono eseguibili: `npm install` va
  eseguito in una cartella exec-capable (es. `$HARNESS_SCRATCH`).
* `dist/` non va committato; `.env` è già in `.gitignore`.

---
